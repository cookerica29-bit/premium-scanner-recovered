# Trading Screener — Upgrade TODO

- [x] Initialize web-static project with stock/forex screener and journal
- [x] Stock screener with calls/puts premium setups
- [x] Forex screener with min 2:1 RR
- [x] Trade journal with auto-push and localStorage persistence
- [x] Upgrade to web-db-user (database + auth)
- [x] Create journal_entries table in drizzle schema
- [x] Push schema to database
- [x] Add journal CRUD tRPC procedures (list, create, update, delete)
- [x] Update App.tsx to restore custom layout and integrate auth
- [x] Update Journal page to use tRPC instead of localStorage
- [x] Update Stock/Forex screeners to use cloud-synced pushedIds
- [x] Add login gate — redirect to login if unauthenticated
- [x] Write vitest for journal procedures

## Live Data Integration
- [x] Add OANDA_API_KEY and OANDA_ACCOUNT_TYPE secrets
- [x] Build server-side Oanda candle fetcher (tRPC procedure)
- [x] Build server-side Yahoo Finance stock candle fetcher (tRPC procedure)
- [x] Build supply/demand zone detection engine (server-side)
- [x] Build price action signal detector (rejection wicks, engulfing, inside bars)
- [x] Build setup quality scorer (PREMIUM/STRONG/DEVELOPING)
- [x] Replace forex screener with real Oanda data + S&D engine
- [x] Replace stock screener with real Yahoo Finance data + S&D engine
- [x] Add loading states and error handling for live data
- [x] Fix Yahoo Finance rate limiting with batched requests + host rotation
- [x] Fix TypeScript errors (ScreenerSetup type unification)
- [x] All 7 vitest tests passing

## New Features (Round 3)
- [x] TradingView chart modal — clicking any setup symbol opens embedded TradingView chart
- [x] Price alerts system — set entry proximity alerts, browser notifications + DB storage
- [x] Performance analytics tab — win rate, equity curve, RR analysis, pattern breakdown
- [x] Add alerts DB table and tRPC procedures (create, list, delete, toggle)
- [x] Add analytics tRPC procedure that aggregates journal data
- [x] Integrate all 3 features into App.tsx navigation

## New Features (Round 4)
- [x] Position size calculator — account size, risk %, lot size, dollar risk per setup
- [x] Position size calculator integrated into setup cards (inline calc per setup)
- [x] Watchlist page — pinned symbols with manual key levels, chart access, notes
- [x] Watchlist DB table and tRPC CRUD procedures (create, list, update, delete)
- [x] Add Calculator and Watchlist tabs to sidebar navigation
- [x] Write vitest tests for watchlist procedures

## New Features (Round 5)
- [x] Add "Calculate" button on each setup card (Stock + Forex screeners) — opens inline calculator pre-filled with entry/SL/TP
- [x] Add "Add to Watchlist" button on each setup card (Stock + Forex screeners) — pins symbol with bias and timeframe pre-filled

## New Features (Round 6)
- [x] Watchlist duplicate guard — warn user when same symbol+timeframe already exists before creating
- [x] Backend: check for existing symbol+timeframe in watchlist.create procedure
- [x] Frontend: show "already watching" toast with option to view existing entry
- [x] Wire "View" action on duplicate watchlist toast to navigate to Watch tab

## New Features (Round 7)
- [x] Calc tab: full lot size calculation (standard/mini/micro lots, pip value, dollar risk per pip)
- [x] Calc tab: forex-specific fields (pair, pip size, account currency)
- [x] Calc tab: stock-specific fields (share count, dollar risk, commission estimate)
- [x] Add/remove stocks from Stock Screener symbol list (DB-backed per user)
- [x] Add/remove forex pairs from Forex Screener pair list (DB-backed per user)
- [x] Default symbol lists seeded for new users
- [x] Wire custom symbol lists into screener scan procedures
- [x] SymbolManager component with add/remove/toggle/duplicate-guard UI
- [x] Write vitest tests for symbols procedures and scan integration (25 new tests, 51 total passing)
- [x] Fix toggleDefault behavior: default symbols without DB row now create a disabled override row immediately

## New Features (Round 8)
- [x] Replace stock screener supply/demand engine with EMA Pullback + Momentum strategy
- [x] Build emaPullback.ts analysis engine: 20/50 EMA trend filter, pullback detection, momentum confirmation candle
- [x] Calculate clean entry/SL/TP levels: entry at EMA touch candle close, SL below/above pullback low/high, TP at prior swing for 2:1+ RR
- [x] Wire new engine into screener.stocks procedure
- [x] Update stock screener UI labels (pattern names, confluence tags) to reflect new strategy
- [x] Write vitest tests for EMA pullback engine (15 tests, 66 total passing)

## New Features (Round 9)
- [x] Show 20 EMA and 50 EMA values on stock setup card expanded view
- [x] Return ema20 and ema50 values from screener.stocks procedure
- [x] Add backtesting summary panel to Stats page (timeframe breakdown + strategy breakdown)
- [x] Fix iPad login button sticky/unresponsive issue (use window.location.assign + native <a> tags)
- [x] Ensure journal syncs correctly after login (invalidate journal/analytics on auth transition in useAuth)

## Bug Fixes (Round 10)
- [x] Fix stock screener returning zero setups — relaxed trend filter (EMA alignment only), pullback tolerance 3%, slope threshold 0.05%, momentum candle thresholds, swing detection n=2
- [x] Add integration tests validating engine produces setups on deterministic LONG/SHORT fixtures (7 integration tests, 73 total passing)

## New Features (Round 11)
- [x] Add volume confirmation filter to EMA pullback engine (1.2x avg volume on momentum candle)
- [x] Surface "Volume Surge" confluence tag on setup cards when volume condition is met
- [x] Volume Surge boosts quality score by +2 (can push STRONG → PREMIUM)
- [x] Update integration tests to cover volume confirmation (2 new tests, 75 total passing)

## New Features (Round 12)
- [x] Add "Push to Journal" button (book icon) on each watchlist item in the Watch tab
- [x] Show a quick-entry modal (symbol, direction CALL/PUT/LONG/SHORT, quality, timeframe, entry/SL/TP, notes) pre-filled from watchlist data
- [x] Create journal entry on submit via trpc.journal.create, invalidate journal list on success

## New Features (Round 13)
- [x] Add live RR ratio display in Push to Journal modal (updates as user types entry/SL/TP, color-coded: green ≥2:1, amber 1-2:1, red <1:1)

## Bug Fixes (Round 14)
- [x] Fix Symbol Manager UX: replaced confusing eye-icon toggle with a clear Switch component so users don't accidentally disable stocks by clicking what looked like a "view" button
- [x] Improve Symbol Manager disabled state: added ON/OFF text label next to toggle (green ON, grey OFF), full-size switch

## New Features (Round 15)
- [x] Build priceAction.ts engine: momentum candles, key level tests, inside bar/breakout, trend strength (ADX proxy)
- [x] Add screener.stocksPriceAction tRPC procedure using the new engine
- [x] Add scan mode toggle (EMA Pullback | Price Action) in StockScreener header
- [x] Price Action results show signal type, strength, and key level context instead of CALL/PUT framing
- [x] PaResultCard with signal pills, expanded detail view, ATR display, chart button
- [x] PA stats bar (Total, Strong, Bullish, Bearish)
- [x] Write dedicated vitest tests for priceAction.ts engine (9 tests covering edge cases, shape, signals)
- [x] 85 vitest tests passing, 0 TypeScript errors

## Bug Fixes (Round 16)
- [x] Diagnose and fix EMA Pullback stock screener returning zero setups — root cause: Yahoo Finance 429 rate limiting
- [x] Build Polygon.io candle fetcher (polygonData.ts) to replace Yahoo Finance
- [x] Validate POLYGON_API_KEY — confirmed working (250 candles for AAPL)
- [x] Wire Polygon.io fetcher into screener.stocks and screener.stocksPriceAction procedures
- [x] Add 15-minute in-memory candle cache to polygonData.ts (keyed by symbol+timeframe, 13s sequential queue)
- [x] Expose cacheAgeMs and cacheWarm from screener.stocks procedure
- [x] Show cache freshness indicator in StockScreener UI (green "Live data"/"Data Xm old", amber "Warming cache…")
- [x] Fix symbols.test.ts mock path from stockData → polygonData, add getCacheAge/isCacheWarm mocks
- [x] 85 vitest tests passing, 0 TypeScript errors

## Bug Fixes (Round 17)
- [x] Fix 504 Gateway Timeout on screener.stocks — cold scan blocks for 4+ minutes waiting for Polygon.io rate-limited fetches
- [x] Add fetchStockCandlesCached() — returns only already-cached symbols instantly, triggers background warm for uncached ones
- [x] Update screener.stocks and screener.stocksPriceAction to use cached-only path, return partial results with warming status
- [x] Add warmCacheInBackground() export to polygonData.ts so the router can kick off background fetching without blocking
- [x] Update StockScreener UI to show "Partial results — warming cache" message when cacheWarm is false

## Quality Improvements (Round 18)

### HTF Regime Filter
- [x] Add fetchHTFCandles() to polygonData.ts — fetches the next-higher timeframe for a given symbol (15m→1H, 1H→4H, 4H→Daily, Daily→Weekly)
- [x] Add evaluateHTFTrend() helper to emaPullback.ts — returns "BULL" | "BEAR" | "NEUTRAL" based on 20/50 EMA alignment on HTF candles
- [x] Wire HTF filter into evaluateEmaPullback(): skip setup if HTF trend opposes direction
- [x] Add "HTF Trend Aligned" confluence tag and +2 quality score when HTF agrees
- [x] Update screener.stocks procedure to fetch HTF candles alongside primary timeframe
- [x] Update tests to cover HTF filter behavior (agree → setup fires, oppose → setup blocked)

### Outcome-Based Quality Calibration
- [x] Add getPatternWinRates() to server/db.ts — aggregates journal WIN/LOSS outcomes by pattern name for a given user
- [x] Add patternWinRates optional param to evaluateEmaPullback() — adjusts quality score based on historical win rate (>60% win rate = +2, <40% = -2)
- [x] Wire win rate lookup into screener.stocks procedure (fetch once, pass to each evaluateEmaPullback call)
- [x] Add "%Win Rate" / "Low Win Rate" confluence tags
- [x] Write vitest tests for quality adjustment logic

### Relative Strength Filter
- [x] Fetch SPY candles using existing Polygon cache
- [x] Compute 20-bar RS score (symbol % change − SPY % change)
- [x] Wire RS filter into screener.stocks: CALL setups require RS > 0, PUT setups require RS < 0
- [x] Add "Relative Strength Leader" / "Relative Weakness" confluence tag and +1 quality score
- [x] Write vitest tests for RS filter behavior

### Pullback Depth Scoring
- [x] Enhance detectPullback() to return pullbackDepthPct (how close the wick got to the EMA)
- [x] Add depth scoring to quality scorer: tight touch (<0.5%) = +2, moderate (0.5-1.5%) = +1, loose (>1.5%) = 0
- [x] Add "Precise EMA Touch" confluence tag for tight pullbacks

### 2-Bar Confirmation
- [x] Add hasTwoBarConfirmation check — checks if the last 2 candles both confirm direction
- [x] Wire into quality scorer: 2-bar confirmation = +2 quality score, "2-Bar Confirmation" confluence tag

### Earnings Blackout Filter
- [x] Add fetchNextEarningsDate() to polygonData.ts — fetches upcoming earnings dates from Polygon /vX/reference/financials, 24h cache
- [x] Add isNearEarnings() helper — checks if earnings is within 3 days
- [x] Wire into screener.stocks: flag setups within 3 days of earnings with "Near Earnings (YYYY-MM-DD)" tag, downgrade quality by 1 tier
- [x] Add amber ⚠ EARNINGS badge to setup card header when earningsDate is present
- [x] Update symbols.test.ts mock to include fetchNextEarningsDate and isNearEarnings

## New Features (Round 19) — One-Click Outcome Marking

- [x] Add `journal.markOutcome` tRPC mutation — finds existing journal entry by setupId or creates one, then sets outcome (WIN/LOSS/BREAKEVEN)
- [x] Add `journal.outcomes` tRPC query — returns a map of setupId → outcome for the current user (used to show current state on cards)
- [x] Add WIN / LOSS / BREAKEVEN outcome buttons row to each SetupCard in StockScreener
- [x] Outcome buttons are only shown when user is authenticated (hide for unauthenticated users)
- [x] Active outcome is highlighted (green for WIN, red for LOSS, amber for BREAKEVEN), clicking again clears it (toggles back to PENDING)
- [x] Invalidate journal and analytics queries on outcome change so Stats page stays in sync
- [x] Write vitest tests for markOutcome procedure (create new entry, update existing, toggle back to PENDING)

## Critical Bug Fixes (Round 20) — Wrong-Direction Setups

### Root Causes Identified
- Forex engine (supplyDemand.ts) sets entry at historical zone price, not current price — fires setups when price has already moved away from the zone
- HTF trend filter in supplyDemand.ts uses weak 5-candle vs 20-candle comparison (0.5% threshold) — calls strong uptrends "NEUTRAL" and allows SHORT setups to fire
- Stock EMA engine does not verify price is pulling back INTO the EMA from the correct side — can fire SHORT when price is above both EMAs

### Fixes
- [x] Fix 1 (stocks): Add price-relative-to-EMA check in evaluateEmaPullback — LONG setups require current price to be at or below 20 EMA (pulling back from above), SHORT setups require current price to be at or above 20 EMA (pulling back from below)
- [x] Fix 2 (stocks): Price-relative-to-EMA check also covers this — if price is within 4% of EMA, the pullback is genuine
- [x] Fix 3 (forex): Replace supplyDemand.ts engine with evaluateEmaPullback in scanForexPair() — same proven engine as stocks
- [x] Fix 4 (forex): Wire HTF candles (already fetched) into evaluateEmaPullback htfCandles option for forex pairs
- [x] Fix 5 (forex): Update ForexScreener UI labels to reflect EMA Pullback strategy instead of Supply/Demand
- [x] Fix 6: Add regression tests for price-relative-to-EMA check (price above EMA should not fire SHORT, price below EMA should not fire LONG)
- [x] Fix 7: No mock changes needed — forex scan tests pass empty candle arrays so evaluateEmaPullback returns hasSetup:false correctly

## Round 32 — Final Build: Enhanced Stock Scan Engine
- [x] Add getStructureBias() to emaPullback.ts (recent vs prior 5 bars → Bullish/Bearish/Mixed Structure + score)
- [x] Add getLocationTag() to emaPullback.ts (Near Support/Near Resistance/Mid Range/Tight Range + score)
- [x] Add getRoom() to emaPullback.ts (Good Room/Limited Room/Poor Room/Range + score)
- [x] Add getTimingState() to emaPullback.ts (READY/WATCH/EARLY/AVOID)
- [x] Add getSetupQuality() to emaPullback.ts (A/B/C grade)
- [x] Add finalTradeScore composite (bestScore 55% + structure 15% + location 15% + room 10% + timing 5%)
- [x] Add reason string builder to emaPullback.ts
- [x] Update EmaSetupResult and ScreenerSetup types to include all new fields
- [x] Update StockScreener.tsx to show structureBias, locationTag, roomToMove, timingState, setupQuality, finalTradeScore, reason in expanded card
- [x] Add inline badges (timingState, setupQuality, finalTradeScore) to collapsed card header
- [x] Update stockScan.scan tRPC procedure to return all new fields
- [x] Verify 0 TypeScript errors
- [x] Verify all tests pass (118 tests)

## Round 33 — Part 2 Upgrade: PDH/PDL, Displacement, Session Labels, Enhanced Timing
- [ ] Add getPDHL() helper to emaPullback.ts — returns previousDayHigh, previousDayLow from daily candles
- [ ] Add getLiquidityContext() — classifies price vs PDH/PDL as AbovePDH/BelowPDL/WithinPDRange/NearPDH/NearPDL
- [ ] Add detectDisplacement() — detects large single-candle moves (>1.5x ATR body) as bullish/bearish displacement
- [ ] Add getSessionLabel() — labels current bar as PreMarket/London/NewYork/Overlap/AsiaLate/AfterHours based on UTC hour
- [ ] Update getTimingState() to incorporate liquidityContext and displacement into READY/WATCH/EARLY/AVOID logic
- [ ] Add new fields to EmaSetupResult: previousDayHigh, previousDayLow, liquidityContext, displacementDetected, displacementDirection, sessionLabel
- [ ] Update ScreenerSetup interface in routers.ts with new fields
- [ ] Pass new fields from evaluateEmaPullback to ScreenerSetup in screener.stocks
- [ ] Update ScreenerSetup interface in StockScreener.tsx with new fields
- [ ] Display PDH/PDL levels, liquidity context, displacement badge, and session label in SetupCard expanded view
- [ ] Write vitest tests for getPDHL, getLiquidityContext, detectDisplacement, getSessionLabel
- [ ] Verify 0 TypeScript errors
- [ ] Verify all tests pass

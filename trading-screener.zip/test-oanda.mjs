import 'dotenv/config';

const apiKey = process.env.OANDA_API_KEY;
const accountType = process.env.OANDA_ACCOUNT_TYPE || 'live';
const accountId = process.env.OANDA_ACCOUNT_ID;

const baseUrl = accountType === 'live'
  ? 'https://api-fxtrade.oanda.com'
  : 'https://api-fxpractice.oanda.com';

console.log(`Testing Oanda API (${accountType}) at ${baseUrl}`);
console.log(`Account ID: ${accountId}`);
console.log(`API Key set: ${apiKey ? 'YES (' + apiKey.substring(0, 8) + '...)' : 'NO'}`);

try {
  // Test 1: Fetch account info
  const accountRes = await fetch(`${baseUrl}/v3/accounts/${accountId}`, {
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    }
  });

  if (!accountRes.ok) {
    const err = await accountRes.text();
    console.error(`❌ Account fetch failed: ${accountRes.status} ${err}`);
    process.exit(1);
  }

  const accountData = await accountRes.json();
  console.log(`✅ Account connected: ${accountData.account?.alias || accountData.account?.id}`);

  // Test 2: Fetch EUR/USD candles
  const candleRes = await fetch(
    `${baseUrl}/v3/instruments/EUR_USD/candles?count=5&granularity=H4&price=M`,
    {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      }
    }
  );

  if (!candleRes.ok) {
    const err = await candleRes.text();
    console.error(`❌ Candles fetch failed: ${candleRes.status} ${err}`);
    process.exit(1);
  }

  const candleData = await candleRes.json();
  const candles = candleData.candles || [];
  console.log(`✅ EUR/USD H4 candles fetched: ${candles.length} candles`);
  if (candles.length > 0) {
    const last = candles[candles.length - 1];
    console.log(`   Last candle: O=${last.mid.o} H=${last.mid.h} L=${last.mid.l} C=${last.mid.c} Vol=${last.volume}`);
  }

  console.log('\n✅ All Oanda API tests passed!');
} catch (err) {
  console.error('❌ Error:', err.message);
  process.exit(1);
}

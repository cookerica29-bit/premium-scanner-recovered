import mysql from 'mysql2/promise';

const url = process.env.DATABASE_URL;
if (!url) {
  console.error('No DATABASE_URL found');
  process.exit(1);
}

const conn = await mysql.createConnection(url);

const sql = `CREATE TABLE IF NOT EXISTS \`journal_entries\` (
  \`id\` int AUTO_INCREMENT NOT NULL,
  \`userId\` int NOT NULL,
  \`setupId\` varchar(64) NOT NULL,
  \`symbol\` varchar(20) NOT NULL,
  \`assetClass\` enum('STOCK','FOREX') NOT NULL,
  \`setupType\` enum('CALL','PUT','LONG','SHORT') NOT NULL,
  \`quality\` enum('PREMIUM','STRONG','DEVELOPING') NOT NULL,
  \`pattern\` varchar(120) NOT NULL,
  \`timeframe\` varchar(10) NOT NULL,
  \`levels\` json NOT NULL,
  \`rrRatio\` float NOT NULL,
  \`confluences\` json NOT NULL,
  \`notes\` text,
  \`outcome\` enum('WIN','LOSS','BREAKEVEN','PENDING') DEFAULT 'PENDING',
  \`pnl\` float,
  \`tags\` json NOT NULL,
  \`sector\` varchar(80),
  \`ivRank\` int,
  \`session\` varchar(60),
  \`pushedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  \`entryDate\` timestamp NULL,
  \`exitDate\` timestamp NULL,
  PRIMARY KEY (\`id\`)
)`;

try {
  await conn.execute(sql);
  console.log('journal_entries table created (or already exists)');
  const [rows] = await conn.execute('SHOW TABLES');
  console.log('Tables now:', rows.map(r => Object.values(r)[0]));
} catch (e) {
  console.error('Error:', e.message);
} finally {
  await conn.end();
}

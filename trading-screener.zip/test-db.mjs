import mysql from 'mysql2/promise';

const url = process.env.DATABASE_URL;
console.log('DB URL present:', !!url);

if (!url) {
  console.error('No DATABASE_URL found in environment');
  process.exit(1);
}

try {
  const conn = await mysql.createConnection(url);
  console.log('Connected!');
  const [rows] = await conn.execute('SHOW TABLES');
  console.log('Tables:', rows);
  await conn.end();
} catch (e) {
  console.error('Error:', e.message);
}

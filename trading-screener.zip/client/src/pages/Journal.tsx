// ============================================================
// TRADE JOURNAL PAGE — Cloud-synced via tRPC
// Full journal with auto-push, notes, outcomes, and stats
// Design: Dark Terminal / Bloomberg-Inspired
// ============================================================

import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  BookOpen,
  TrendingUp,
  TrendingDown,
  Search,
  Trash2,
  Edit3,
  Check,
  X,
  ChevronDown,
  ChevronUp,
  Trophy,
  Target,
  BarChart3,
  Clock,
  Zap,
  Filter,
  StickyNote,
  CheckCircle,
  XCircle,
  MinusCircle,
  AlertCircle,
  LogIn,
  RefreshCw,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
// Use a local type that mirrors the DB row shape
type JournalEntryRow = {
  id: number;
  userId: number;
  setupId: string;
  symbol: string;
  assetClass: "STOCK" | "FOREX";
  setupType: "CALL" | "PUT" | "LONG" | "SHORT";
  quality: "PREMIUM" | "STRONG" | "DEVELOPING";
  pattern: string;
  timeframe: string;
  levels: unknown;
  rrRatio: number;
  confluences: unknown;
  notes: string | null;
  outcome: "WIN" | "LOSS" | "BREAKEVEN" | "PENDING" | null;
  pnl: number | null;
  tags: unknown;
  sector: string | null;
  ivRank: number | null;
  session: string | null;
  pushedAt: Date;
  entryDate: Date | null;
  exitDate: Date | null;
};

interface JournalProps {
  entries: JournalEntryRow[];
  onRefetch: () => void;
  isAuthenticated: boolean;
  onLoginClick: () => void;
}

type OutcomeFilter = "ALL" | "WIN" | "LOSS" | "BREAKEVEN" | "PENDING";
type AssetFilter = "ALL" | "STOCK" | "FOREX";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatTimeAgo(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  const diff = Date.now() - d.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function formatPrice(price: number): string {
  if (price >= 100) return price.toFixed(2);
  if (price >= 1) return price.toFixed(4);
  return price.toFixed(5);
}

function getJournalStats(entries: JournalEntryRow[]) {
  const resolved = entries.filter((e) => e.outcome && e.outcome !== "PENDING");
  const wins = entries.filter((e) => e.outcome === "WIN").length;
  const losses = entries.filter((e) => e.outcome === "LOSS").length;
  const breakevens = entries.filter((e) => e.outcome === "BREAKEVEN").length;
  const pending = entries.filter((e) => !e.outcome || e.outcome === "PENDING").length;
  const winRate = resolved.length > 0 ? ((wins / resolved.length) * 100).toFixed(1) : "0.0";
  const totalPnl = entries.reduce((sum, e) => sum + (e.pnl ?? 0), 0).toFixed(2);
  return { total: entries.length, wins, losses, breakevens, pending, winRate, totalPnl };
}

// ─── Entry Card ───────────────────────────────────────────────────────────────

function JournalEntryCard({ entry, onRefetch }: { entry: JournalEntryRow; onRefetch: () => void }) {
  const utils = trpc.useUtils();
  const [expanded, setExpanded] = useState(false);
  const [editingNotes, setEditingNotes] = useState(false);
  const [notes, setNotes] = useState(entry.notes ?? "");
  const [editingPnl, setEditingPnl] = useState(false);
  const [pnlInput, setPnlInput] = useState(entry.pnl?.toString() ?? "");

  const updateEntry = trpc.journal.update.useMutation({
    onSuccess: () => { utils.journal.list.invalidate(); },
  });
  const deleteEntry = trpc.journal.delete.useMutation({
    onSuccess: () => { utils.journal.list.invalidate(); utils.journal.pushedIds.invalidate(); onRefetch(); },
  });

  const isBullish = entry.setupType === "CALL" || entry.setupType === "LONG";
  const signalColor = isBullish ? "text-[#00FF88]" : "text-[#FF3B5C]";
  const signalBg = isBullish ? "bg-[#00FF88]/8 border-[#00FF88]/15" : "bg-[#FF3B5C]/8 border-[#FF3B5C]/15";

  const outcomeConfig = {
    WIN: { color: "text-[#00FF88]", bg: "bg-[#00FF88]/10 border-[#00FF88]/30", icon: <CheckCircle className="w-3.5 h-3.5" />, label: "WIN" },
    LOSS: { color: "text-[#FF3B5C]", bg: "bg-[#FF3B5C]/10 border-[#FF3B5C]/30", icon: <XCircle className="w-3.5 h-3.5" />, label: "LOSS" },
    BREAKEVEN: { color: "text-[#F5A623]", bg: "bg-[#F5A623]/10 border-[#F5A623]/30", icon: <MinusCircle className="w-3.5 h-3.5" />, label: "BE" },
    PENDING: { color: "text-slate-400", bg: "bg-slate-400/10 border-slate-400/30", icon: <AlertCircle className="w-3.5 h-3.5" />, label: "PENDING" },
  };

  const qualityConfig = {
    PREMIUM: { color: "text-[#F5A623]", label: "PREMIUM" },
    STRONG: { color: "text-[#60A5FA]", label: "STRONG" },
    DEVELOPING: { color: "text-slate-400", label: "DEVELOPING" },
  };

  const outcome = (entry.outcome ?? "PENDING") as "WIN" | "LOSS" | "BREAKEVEN" | "PENDING";
  const oConfig = outcomeConfig[outcome];
  const levels = entry.levels as { entry: number; stopLoss: number; takeProfit: number; takeProfit2?: number; takeProfit3?: number };
  const confluences = (entry.confluences as string[]) ?? [];
  const tags = (entry.tags as string[]) ?? [];

  const saveNotes = () => {
    updateEntry.mutate({ id: entry.id, notes }, {
      onSuccess: () => { setEditingNotes(false); toast.success("Notes saved"); },
    });
  };

  const savePnl = () => {
    const val = parseFloat(pnlInput);
    if (!isNaN(val)) {
      updateEntry.mutate({ id: entry.id, pnl: val }, {
        onSuccess: () => { setEditingPnl(false); },
      });
    } else {
      setEditingPnl(false);
    }
  };

  const handleOutcome = (o: "WIN" | "LOSS" | "BREAKEVEN" | "PENDING") => {
    updateEntry.mutate({ id: entry.id, outcome: o }, {
      onSuccess: () => toast.success(`Outcome updated to ${o}`),
    });
  };

  const handleDelete = () => {
    if (confirm("Delete this journal entry?")) {
      deleteEntry.mutate({ id: entry.id }, {
        onSuccess: () => toast.success("Entry deleted"),
      });
    }
  };

  return (
    <div className={cn("rounded-lg border bg-[#0D1117] overflow-hidden transition-all", signalBg)}>
      {/* Header */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 min-w-0">
            <div className={cn("flex items-center justify-center w-9 h-9 rounded-lg border flex-shrink-0", signalBg)}>
              {isBullish ? <TrendingUp className={cn("w-4 h-4", signalColor)} /> : <TrendingDown className={cn("w-4 h-4", signalColor)} />}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-mono font-bold text-white">{entry.symbol}</span>
                <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border", oConfig.bg, oConfig.color)}>
                  {oConfig.icon}<span className="ml-1">{oConfig.label}</span>
                </Badge>
                <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border-slate-700", qualityConfig[entry.quality as keyof typeof qualityConfig]?.color)}>
                  {qualityConfig[entry.quality as keyof typeof qualityConfig]?.label}
                </Badge>
                <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border-slate-700", isBullish ? "text-[#00FF88]" : "text-[#FF3B5C]")}>
                  {entry.setupType}
                </Badge>
                <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-slate-700 text-slate-400">{entry.timeframe}</Badge>
                <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-slate-700 text-slate-500">{entry.assetClass}</Badge>
              </div>
              <p className="text-slate-400 text-xs mt-1">{entry.pattern}</p>
              <div className="flex items-center gap-1 text-[10px] text-slate-600 mt-0.5">
                <Clock className="w-3 h-3" />
                Pushed {formatTimeAgo(entry.pushedAt)}
              </div>
            </div>
          </div>

          <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
            <div className={cn("font-mono font-bold text-base", signalColor)}>{entry.rrRatio.toFixed(1)}:1</div>
            {entry.pnl != null && (
              <div className={cn("font-mono text-sm font-semibold", entry.pnl >= 0 ? "text-[#00FF88]" : "text-[#FF3B5C]")}>
                {entry.pnl >= 0 ? "+" : ""}{entry.pnl.toFixed(2)}
              </div>
            )}
          </div>
        </div>

        {/* Price Levels */}
        <div className="mt-3 grid grid-cols-3 gap-2">
          <div className="bg-[#0A0D12] rounded-md p-2 border border-slate-800">
            <div className="text-[10px] text-slate-500 mb-0.5 uppercase tracking-wide">Entry</div>
            <div className="font-mono text-xs font-semibold text-white">{formatPrice(levels.entry)}</div>
          </div>
          <div className="bg-[#0A0D12] rounded-md p-2 border border-[#FF3B5C]/15">
            <div className="text-[10px] text-[#FF3B5C]/60 mb-0.5 uppercase tracking-wide">Stop Loss</div>
            <div className="font-mono text-xs font-semibold text-[#FF3B5C]">{formatPrice(levels.stopLoss)}</div>
          </div>
          <div className="bg-[#0A0D12] rounded-md p-2 border border-[#00FF88]/15">
            <div className="text-[10px] text-[#00FF88]/60 mb-0.5 uppercase tracking-wide">TP1</div>
            <div className="font-mono text-xs font-semibold text-[#00FF88]">{formatPrice(levels.takeProfit)}</div>
          </div>
        </div>

        {/* Outcome Buttons + Actions */}
        <div className="mt-3 flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-1">
            <span className="text-[10px] text-slate-600 mr-1">Outcome:</span>
            {(["WIN", "LOSS", "BREAKEVEN", "PENDING"] as const).map((o) => (
              <button
                key={o}
                onClick={() => handleOutcome(o)}
                disabled={updateEntry.isPending}
                className={cn(
                  "px-2 py-0.5 rounded text-[10px] font-medium border transition-all",
                  outcome === o
                    ? outcomeConfig[o].bg + " " + outcomeConfig[o].color
                    : "bg-transparent border-slate-800 text-slate-600 hover:border-slate-700 hover:text-slate-400"
                )}
              >
                {o === "BREAKEVEN" ? "BE" : o}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setExpanded(!expanded)}
              className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-300 transition-colors"
            >
              {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              {expanded ? "Less" : "Details"}
            </button>
            <button
              onClick={handleDelete}
              disabled={deleteEntry.isPending}
              className="p-1 text-slate-600 hover:text-[#FF3B5C] transition-colors rounded"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Expanded Details */}
      {expanded && (
        <div className="border-t border-slate-800/50 bg-[#080B10] px-4 pb-4 pt-3 space-y-3">
          {/* Extended TPs */}
          {(levels.takeProfit2 || levels.takeProfit3) && (
            <div>
              <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-2">Extended Targets</div>
              <div className="grid grid-cols-2 gap-2">
                {levels.takeProfit2 && (
                  <div className="bg-[#0A0D12] rounded-md p-2 border border-[#00FF88]/10">
                    <div className="text-[10px] text-[#00FF88]/50 mb-0.5">TP2</div>
                    <div className="font-mono text-xs text-[#00FF88]/70">{formatPrice(levels.takeProfit2)}</div>
                  </div>
                )}
                {levels.takeProfit3 && (
                  <div className="bg-[#0A0D12] rounded-md p-2 border border-[#00FF88]/8">
                    <div className="text-[10px] text-[#00FF88]/40 mb-0.5">TP3</div>
                    <div className="font-mono text-xs text-[#00FF88]/50">{formatPrice(levels.takeProfit3)}</div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Confluences */}
          {confluences.length > 0 && (
            <div>
              <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-2">Confluences</div>
              <div className="flex flex-wrap gap-1.5">
                {confluences.map((c, i) => (
                  <span key={i} className="text-[11px] px-2 py-0.5 rounded-full bg-slate-800/60 text-slate-300 border border-slate-700/50">{c}</span>
                ))}
              </div>
            </div>
          )}

          {/* PnL Input */}
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-500 uppercase tracking-wider">P&L ($):</span>
            {editingPnl ? (
              <div className="flex items-center gap-1">
                <Input
                  value={pnlInput}
                  onChange={(e) => setPnlInput(e.target.value)}
                  className="h-6 w-24 text-xs bg-[#0A0D12] border-slate-700 text-white font-mono"
                  placeholder="e.g. 250"
                  autoFocus
                />
                <button onClick={savePnl} className="text-[#00FF88] hover:text-[#00FF88]/80"><Check className="w-3.5 h-3.5" /></button>
                <button onClick={() => setEditingPnl(false)} className="text-slate-500 hover:text-slate-300"><X className="w-3.5 h-3.5" /></button>
              </div>
            ) : (
              <button
                onClick={() => setEditingPnl(true)}
                className="flex items-center gap-1 text-xs font-mono text-slate-400 hover:text-white transition-colors"
              >
                {entry.pnl != null ? (
                  <span className={entry.pnl >= 0 ? "text-[#00FF88]" : "text-[#FF3B5C]"}>
                    {entry.pnl >= 0 ? "+" : ""}{entry.pnl.toFixed(2)}
                  </span>
                ) : (
                  <span className="text-slate-600">Click to add P&L</span>
                )}
                <Edit3 className="w-3 h-3 text-slate-600" />
              </button>
            )}
          </div>

          {/* Notes */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <div className="text-[10px] text-slate-500 uppercase tracking-wider flex items-center gap-1">
                <StickyNote className="w-3 h-3" />
                Notes
              </div>
              {!editingNotes && (
                <button onClick={() => setEditingNotes(true)} className="text-[10px] text-slate-500 hover:text-slate-300 flex items-center gap-1">
                  <Edit3 className="w-3 h-3" />Edit
                </button>
              )}
            </div>
            {editingNotes ? (
              <div className="space-y-2">
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full h-20 text-xs bg-[#0A0D12] border border-slate-700 text-white rounded-md p-2 resize-none focus:outline-none focus:border-slate-500 font-mono"
                  placeholder="Add your trade notes, observations, lessons learned..."
                  autoFocus
                />
                <div className="flex gap-2">
                  <Button size="sm" onClick={saveNotes} disabled={updateEntry.isPending} className="h-6 text-xs bg-[#00FF88]/10 border border-[#00FF88]/30 text-[#00FF88] hover:bg-[#00FF88]/20">
                    <Check className="w-3 h-3 mr-1" />Save
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => { setNotes(entry.notes ?? ""); setEditingNotes(false); }} className="h-6 text-xs border-slate-700 text-slate-400">
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div
                onClick={() => setEditingNotes(true)}
                className={cn(
                  "text-xs rounded-md p-2 border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors min-h-[36px]",
                  entry.notes ? "text-slate-300 bg-[#0A0D12]" : "text-slate-600 bg-[#0A0D12]/50"
                )}
              >
                {entry.notes || "Click to add notes..."}
              </div>
            )}
          </div>

          {/* Tags */}
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {tags.map((tag, i) => (
                <span key={i} className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-500 border border-slate-700/50">
                  #{tag.toLowerCase()}
                </span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Main Journal Page ─────────────────────────────────────────────────────────

export default function Journal({ entries, onRefetch, isAuthenticated, onLoginClick }: JournalProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [outcomeFilter, setOutcomeFilter] = useState<OutcomeFilter>("ALL");
  const [assetFilter, setAssetFilter] = useState<AssetFilter>("ALL");

  const stats = getJournalStats(entries);

  const filteredEntries = entries.filter((e) => {
    if (searchQuery && !e.symbol.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !e.pattern.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    if (outcomeFilter !== "ALL" && e.outcome !== outcomeFilter) return false;
    if (assetFilter !== "ALL" && e.assetClass !== assetFilter) return false;
    return true;
  });

  // Not authenticated — show login prompt
  if (!isAuthenticated) {
    return (
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="relative overflow-hidden rounded-xl mb-5 border border-slate-800" style={{ minHeight: 110 }}>
          <div className="absolute inset-0 bg-gradient-to-r from-[#0A0D12] via-[#0A0D12]/85 to-transparent" />
          <div className="relative z-10 p-5">
            <div className="flex items-center gap-2 mb-1">
              <BookOpen className="w-4 h-4 text-[#F5A623]" />
              <span className="text-[11px] text-[#F5A623] font-mono uppercase tracking-widest">Trade Journal</span>
            </div>
            <h2 className="text-xl font-bold text-white">My Trading Journal</h2>
            <p className="text-slate-400 text-sm mt-0.5">Track, review, and improve your trading performance</p>
          </div>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center py-20 text-center">
          <div className="w-16 h-16 rounded-full bg-[#0D1117] border border-slate-800 flex items-center justify-center mb-4">
            <LogIn className="w-7 h-7 text-[#F5A623]" />
          </div>
          <p className="text-white font-semibold text-lg">Log in to access your journal</p>
          <p className="text-slate-500 text-sm mt-2 max-w-sm">
            Your trade journal syncs across all devices. Log in to push setups, track outcomes, and review your performance from anywhere.
          </p>
          <button
            onClick={onLoginClick}
            className="mt-6 flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00FF88]/10 border border-[#00FF88]/30 text-[#00FF88] hover:bg-[#00FF88]/20 transition-all font-medium"
          >
            <LogIn className="w-4 h-4" />
            Log In to Sync Journal
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl mb-5 border border-slate-800" style={{ minHeight: 110 }}>
        <div
          className="absolute inset-0 bg-cover bg-center opacity-15"
          style={{ backgroundImage: `url(https://d2xsxph8kpxj0f.cloudfront.net/310519663485819244/6HDX6MZMMiuXiLTEXJkkHb/trading-hero-bg-F8aDhDZCjf85e96erk3nrr.webp)` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A0D12] via-[#0A0D12]/85 to-transparent" />
        <div className="relative z-10 p-5 flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <BookOpen className="w-4 h-4 text-[#F5A623]" />
              <span className="text-[11px] text-[#F5A623] font-mono uppercase tracking-widest">Trade Journal</span>
            </div>
            <h2 className="text-xl font-bold text-white">My Trading Journal</h2>
            <p className="text-slate-400 text-sm mt-0.5">Track, review, and improve your trading performance</p>
          </div>
          <button
            onClick={onRefetch}
            className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-300 border border-slate-800 rounded-md px-2.5 py-1.5 transition-all"
          >
            <RefreshCw className="w-3 h-3" />
            Refresh
          </button>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 mb-4">
        {[
          { label: "Total", value: stats.total, color: "text-white", icon: <BookOpen className="w-3 h-3" /> },
          { label: "Wins", value: stats.wins, color: "text-[#00FF88]", icon: <Trophy className="w-3 h-3" /> },
          { label: "Losses", value: stats.losses, color: "text-[#FF3B5C]", icon: <XCircle className="w-3 h-3" /> },
          { label: "BE", value: stats.breakevens, color: "text-[#F5A623]", icon: <MinusCircle className="w-3 h-3" /> },
          { label: "Pending", value: stats.pending, color: "text-slate-400", icon: <Clock className="w-3 h-3" /> },
          { label: "Win Rate", value: `${stats.winRate}%`, color: parseFloat(stats.winRate) >= 50 ? "text-[#00FF88]" : "text-[#FF3B5C]", icon: <BarChart3 className="w-3 h-3" /> },
          { label: "Total P&L", value: `$${stats.totalPnl}`, color: parseFloat(stats.totalPnl) >= 0 ? "text-[#00FF88]" : "text-[#FF3B5C]", icon: <Target className="w-3 h-3" /> },
        ].map((stat) => (
          <div key={stat.label} className="bg-[#0D1117] border border-slate-800 rounded-lg p-3 text-center">
            <div className={cn("text-lg font-bold font-mono", stat.color)}>{stat.value}</div>
            <div className="text-[10px] text-slate-500 flex items-center justify-center gap-1 mt-0.5">
              {stat.icon}{stat.label}
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2 mb-4">
        <div className="relative flex-1 min-w-[180px] max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
          <Input
            placeholder="Search symbol or pattern..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8 h-8 text-xs bg-[#0D1117] border-slate-800 text-white placeholder:text-slate-600 focus:border-slate-600"
          />
        </div>

        <div className="flex items-center gap-1.5">
          <Filter className="w-3.5 h-3.5 text-slate-500" />
          {(["ALL", "WIN", "LOSS", "BREAKEVEN", "PENDING"] as OutcomeFilter[]).map((f) => (
            <button
              key={f}
              onClick={() => setOutcomeFilter(f)}
              className={cn(
                "px-2.5 py-1 rounded-md text-xs font-medium border transition-all",
                outcomeFilter === f
                  ? f === "WIN" ? "bg-[#00FF88]/15 border-[#00FF88]/40 text-[#00FF88]"
                    : f === "LOSS" ? "bg-[#FF3B5C]/15 border-[#FF3B5C]/40 text-[#FF3B5C]"
                    : f === "BREAKEVEN" ? "bg-[#F5A623]/15 border-[#F5A623]/40 text-[#F5A623]"
                    : f === "PENDING" ? "bg-slate-700 border-slate-600 text-slate-300"
                    : "bg-slate-700 border-slate-600 text-white"
                  : "bg-transparent border-slate-800 text-slate-500 hover:border-slate-700 hover:text-slate-400"
              )}
            >
              {f === "BREAKEVEN" ? "BE" : f}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5">
          {(["ALL", "STOCK", "FOREX"] as AssetFilter[]).map((f) => (
            <button
              key={f}
              onClick={() => setAssetFilter(f)}
              className={cn(
                "px-2.5 py-1 rounded-md text-xs font-medium border transition-all",
                assetFilter === f
                  ? "bg-slate-700 border-slate-600 text-white"
                  : "bg-transparent border-slate-800 text-slate-500 hover:border-slate-700 hover:text-slate-400"
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Entries */}
      {entries.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center py-20 text-center">
          <div className="w-16 h-16 rounded-full bg-[#0D1117] border border-slate-800 flex items-center justify-center mb-4">
            <BookOpen className="w-7 h-7 text-slate-600" />
          </div>
          <p className="text-slate-400 font-medium text-lg">Your journal is empty</p>
          <p className="text-slate-600 text-sm mt-2 max-w-sm">
            Push setups from the Stock or Forex screener to start tracking your trades. Enable Auto-Push to automatically add premium setups.
          </p>
          <div className="mt-4 flex items-center gap-2 text-xs text-slate-600">
            <Zap className="w-3.5 h-3.5 text-[#F5A623]" />
            <span>Enable Auto-Push in the sidebar to automatically journal premium setups</span>
          </div>
        </div>
      ) : filteredEntries.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center py-16 text-center">
          <Search className="w-10 h-10 text-slate-700 mb-3" />
          <p className="text-slate-400 font-medium">No entries match your filters</p>
          <p className="text-slate-600 text-sm mt-1">Try adjusting your search or filter criteria</p>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-slate-500">
              Showing <span className="text-white font-mono">{filteredEntries.length}</span> of{" "}
              <span className="text-white font-mono">{entries.length}</span> entries
            </span>
          </div>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-3 pb-4">
            {filteredEntries.map((entry) => (
              <JournalEntryCard key={entry.id} entry={entry} onRefetch={onRefetch} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

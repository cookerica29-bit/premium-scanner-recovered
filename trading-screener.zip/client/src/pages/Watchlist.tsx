import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  Eye,
  Plus,
  Trash2,
  Edit3,
  BarChart2,
  TrendingUp,
  TrendingDown,
  Minus,
  ChevronDown,
  ChevronUp,
  Tag,
  BookOpen,
  Globe,
  X,
  Check,
  Lock,
  Send,
} from "lucide-react";
import { cn } from "@/lib/utils";
import TradingViewModal from "@/components/TradingViewModal";
import { getLoginUrl } from "@/const";

// ─── Types ────────────────────────────────────────────────────────────────────

type WatchlistItem = {
  id: number;
  symbol: string;
  displaySymbol: string;
  assetClass: "STOCK" | "FOREX";
  timeframe: string;
  notes: string | null;
  keyLevel1: string | null;
  keyLevel1Label: string | null;
  keyLevel2: string | null;
  keyLevel2Label: string | null;
  keyLevel3: string | null;
  keyLevel3Label: string | null;
  bias: "BULLISH" | "BEARISH" | "NEUTRAL" | null;
  tags: string | null;
  createdAt: Date;
  updatedAt: Date;
};

type BiasType = "BULLISH" | "BEARISH" | "NEUTRAL";

// ─── Add Symbol Form ──────────────────────────────────────────────────────────

function AddSymbolForm({ onClose }: { onClose: () => void }) {
  const utils = trpc.useUtils();
  const [form, setForm] = useState({
    displaySymbol: "",
    assetClass: "FOREX" as "STOCK" | "FOREX",
    timeframe: "4H",
    bias: "NEUTRAL" as BiasType,
    notes: "",
    keyLevel1: "",
    keyLevel1Label: "Supply Zone",
    keyLevel2: "",
    keyLevel2Label: "Demand Zone",
    keyLevel3: "",
    keyLevel3Label: "Key Level",
    tags: "",
  });

  const createMutation = trpc.watchlist.create.useMutation({
    onSuccess: (result) => {
      if (result.duplicate) {
        toast.warning(`${form.displaySymbol.toUpperCase()} already on Watchlist`, {
          description: `${form.displaySymbol.toUpperCase()} (${form.timeframe}) is already being watched. Scroll down to find and update it.`,
        });
        onClose();
      } else {
        utils.watchlist.list.invalidate();
        toast.success(`${form.displaySymbol.toUpperCase()} added to watchlist`);
        onClose();
      }
    },
    onError: (err) => toast.error(`Failed to add: ${err.message}`),
  });

  const handleSubmit = () => {
    if (!form.displaySymbol.trim()) {
      toast.error("Symbol is required");
      return;
    }
    const symbol = form.assetClass === "FOREX"
      ? form.displaySymbol.replace("/", "_").toUpperCase()
      : form.displaySymbol.toUpperCase();

    createMutation.mutate({
      symbol,
      displaySymbol: form.displaySymbol.toUpperCase(),
      assetClass: form.assetClass,
      timeframe: form.timeframe,
      bias: form.bias,
      notes: form.notes || undefined,
      keyLevel1: form.keyLevel1 || undefined,
      keyLevel1Label: form.keyLevel1Label || undefined,
      keyLevel2: form.keyLevel2 || undefined,
      keyLevel2Label: form.keyLevel2Label || undefined,
      keyLevel3: form.keyLevel3 || undefined,
      keyLevel3Label: form.keyLevel3Label || undefined,
      tags: form.tags ? form.tags.split(",").map((t) => t.trim()).filter(Boolean) : [],
    });
  };

  return (
    <div className="bg-[#0D1117] rounded-xl border border-[#60A5FA]/20 p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-white flex items-center gap-2">
          <Plus className="w-4 h-4 text-[#60A5FA]" />
          Add to Watchlist
        </h3>
        <button onClick={onClose} className="text-slate-500 hover:text-slate-300">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs text-slate-400 mb-1 block">Symbol *</Label>
          <Input
            value={form.displaySymbol}
            onChange={(e) => setForm({ ...form, displaySymbol: e.target.value })}
            placeholder="e.g. EUR/USD or AAPL"
            className="h-8 text-sm bg-[#080B10] border-slate-700 text-white"
          />
        </div>
        <div>
          <Label className="text-xs text-slate-400 mb-1 block">Asset Class</Label>
          <div className="flex gap-1">
            {(["FOREX", "STOCK"] as const).map((ac) => (
              <button
                key={ac}
                onClick={() => setForm({ ...form, assetClass: ac })}
                className={cn(
                  "flex-1 h-8 text-xs rounded border transition-all",
                  form.assetClass === ac
                    ? "bg-[#60A5FA]/10 border-[#60A5FA]/30 text-[#60A5FA]"
                    : "border-slate-700 text-slate-500 hover:text-slate-300"
                )}
              >
                {ac}
              </button>
            ))}
          </div>
        </div>
        <div>
          <Label className="text-xs text-slate-400 mb-1 block">Timeframe</Label>
          <div className="flex gap-1 flex-wrap">
            {["1H", "4H", "Daily"].map((tf) => (
              <button
                key={tf}
                onClick={() => setForm({ ...form, timeframe: tf })}
                className={cn(
                  "px-2 h-8 text-xs rounded border transition-all",
                  form.timeframe === tf
                    ? "bg-[#60A5FA]/10 border-[#60A5FA]/30 text-[#60A5FA]"
                    : "border-slate-700 text-slate-500 hover:text-slate-300"
                )}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>
        <div>
          <Label className="text-xs text-slate-400 mb-1 block">Bias</Label>
          <div className="flex gap-1">
            {(["BULLISH", "NEUTRAL", "BEARISH"] as BiasType[]).map((b) => (
              <button
                key={b}
                onClick={() => setForm({ ...form, bias: b })}
                className={cn(
                  "flex-1 h-8 text-[10px] rounded border transition-all",
                  form.bias === b
                    ? b === "BULLISH"
                      ? "bg-[#00FF88]/10 border-[#00FF88]/30 text-[#00FF88]"
                      : b === "BEARISH"
                      ? "bg-[#FF3B5C]/10 border-[#FF3B5C]/30 text-[#FF3B5C]"
                      : "bg-slate-700/40 border-slate-600 text-slate-300"
                    : "border-slate-700 text-slate-500 hover:text-slate-300"
                )}
              >
                {b === "BULLISH" ? "↑" : b === "BEARISH" ? "↓" : "—"}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Key Levels */}
      <div className="space-y-2">
        <div className="text-[11px] text-slate-500 uppercase tracking-wider">Key Levels (optional)</div>
        {[1, 2, 3].map((n) => (
          <div key={n} className="flex gap-2">
            <Input
              value={(form as any)[`keyLevel${n}Label`]}
              onChange={(e) => setForm({ ...form, [`keyLevel${n}Label`]: e.target.value } as any)}
              placeholder="Label"
              className="h-7 text-xs bg-[#080B10] border-slate-700 text-slate-300 w-32"
            />
            <Input
              type="number"
              step="any"
              value={(form as any)[`keyLevel${n}`]}
              onChange={(e) => setForm({ ...form, [`keyLevel${n}`]: e.target.value } as any)}
              placeholder="Price level"
              className="h-7 text-xs bg-[#080B10] border-slate-700 text-white font-mono flex-1"
            />
          </div>
        ))}
      </div>

      {/* Notes */}
      <div>
        <Label className="text-xs text-slate-400 mb-1 block">Notes</Label>
        <Input
          value={form.notes}
          onChange={(e) => setForm({ ...form, notes: e.target.value })}
          placeholder="e.g. Watching for demand zone retest on 4H"
          className="h-8 text-sm bg-[#080B10] border-slate-700 text-white"
        />
      </div>

      {/* Tags */}
      <div>
        <Label className="text-xs text-slate-400 mb-1 block">Tags (comma-separated)</Label>
        <Input
          value={form.tags}
          onChange={(e) => setForm({ ...form, tags: e.target.value })}
          placeholder="e.g. supply-demand, trending, high-priority"
          className="h-8 text-sm bg-[#080B10] border-slate-700 text-white"
        />
      </div>

      <div className="flex justify-end gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={onClose}
          className="h-8 text-xs border-slate-700 text-slate-400 hover:text-white bg-transparent"
        >
          Cancel
        </Button>
        <Button
          size="sm"
          onClick={handleSubmit}
          disabled={createMutation.isPending || !form.displaySymbol.trim()}
          className="h-8 text-xs bg-[#60A5FA]/10 border border-[#60A5FA]/30 text-[#60A5FA] hover:bg-[#60A5FA]/20"
        >
          {createMutation.isPending ? "Adding..." : "Add Symbol"}
        </Button>
      </div>
    </div>
  );
}

// ─── Watchlist Card ───────────────────────────────────────────────────────────

function WatchlistCard({ item, onSwitchToJournal }: { item: WatchlistItem; onSwitchToJournal?: () => void }) {
  const utils = trpc.useUtils();
  const [expanded, setExpanded] = useState(false);
  const [editing, setEditing] = useState(false);
  const [chartOpen, setChartOpen] = useState(false);
  const [journalModalOpen, setJournalModalOpen] = useState(false);
  const [journalForm, setJournalForm] = useState({
    setupType: (item.bias === "BULLISH" ? "CALL" : item.bias === "BEARISH" ? "PUT" : "CALL") as "CALL" | "PUT" | "LONG" | "SHORT",
    quality: "DEVELOPING" as "PREMIUM" | "STRONG" | "DEVELOPING",
    timeframe: item.timeframe,
    entry: item.keyLevel1 ?? "",
    stopLoss: item.keyLevel2 ?? "",
    takeProfit: item.keyLevel3 ?? "",
    notes: item.notes ?? "",
  });

  const createJournalEntry = trpc.journal.create.useMutation({
    onSuccess: () => {
      utils.journal.list.invalidate();
      setJournalModalOpen(false);
      toast.success(`${item.displaySymbol} pushed to journal`, {
        description: `${journalForm.setupType} setup logged · ${journalForm.timeframe}`,
        action: { label: "View Journal", onClick: () => onSwitchToJournal?.() },
      });
    },
    onError: (err) => toast.error(`Failed to push: ${err.message}`),
  });

  const handlePushToJournal = () => {
    const entry = parseFloat(journalForm.entry);
    const stopLoss = parseFloat(journalForm.stopLoss);
    const takeProfit = parseFloat(journalForm.takeProfit);
    if (isNaN(entry) || entry <= 0) {
      toast.error("Entry price is required and must be a positive number");
      return;
    }
    if (isNaN(stopLoss) || stopLoss <= 0) {
      toast.error("Stop Loss is required and must be a positive number");
      return;
    }
    if (isNaN(takeProfit) || takeProfit <= 0) {
      toast.error("Take Profit is required and must be a positive number");
      return;
    }
    if (Math.abs(entry - stopLoss) < 0.0001) {
      toast.error("Entry and Stop Loss must be different prices");
      return;
    }
    const risk = Math.abs(entry - stopLoss);
    const reward = Math.abs(takeProfit - entry);
    const rrRatio = risk > 0 ? parseFloat((reward / risk).toFixed(1)) : 1;
    createJournalEntry.mutate({
      setupId: `watchlist-${item.id}-${Date.now()}`,
      symbol: item.symbol,
      assetClass: item.assetClass,
      setupType: journalForm.setupType,
      quality: journalForm.quality,
      pattern: `Watchlist: ${item.displaySymbol}`,
      timeframe: journalForm.timeframe,
      levels: { entry, stopLoss, takeProfit, takeProfit2: takeProfit, takeProfit3: takeProfit },
      rrRatio,
      confluences: item.bias ? [`Bias: ${item.bias}`] : [],
      notes: journalForm.notes || undefined,
      tags: [],
    });
  };
  const [editForm, setEditForm] = useState({
    notes: item.notes ?? "",
    bias: (item.bias ?? "NEUTRAL") as BiasType,
    keyLevel1: item.keyLevel1 ?? "",
    keyLevel1Label: item.keyLevel1Label ?? "Supply Zone",
    keyLevel2: item.keyLevel2 ?? "",
    keyLevel2Label: item.keyLevel2Label ?? "Demand Zone",
    keyLevel3: item.keyLevel3 ?? "",
    keyLevel3Label: item.keyLevel3Label ?? "Key Level",
  });

  const parsedTags: string[] = (() => {
    try {
      return item.tags ? JSON.parse(item.tags) : [];
    } catch {
      return [];
    }
  })();

  const deleteMutation = trpc.watchlist.delete.useMutation({
    onSuccess: () => {
      utils.watchlist.list.invalidate();
      toast.success(`${item.displaySymbol} removed from watchlist`);
    },
    onError: (err) => toast.error(`Failed to remove: ${err.message}`),
  });

  const updateMutation = trpc.watchlist.update.useMutation({
    onSuccess: () => {
      utils.watchlist.list.invalidate();
      toast.success("Watchlist updated");
      setEditing(false);
    },
    onError: (err) => toast.error(`Failed to update: ${err.message}`),
  });

  const handleSave = () => {
    updateMutation.mutate({
      id: item.id,
      notes: editForm.notes || undefined,
      bias: editForm.bias,
      keyLevel1: editForm.keyLevel1 || null,
      keyLevel1Label: editForm.keyLevel1Label || null,
      keyLevel2: editForm.keyLevel2 || null,
      keyLevel2Label: editForm.keyLevel2Label || null,
      keyLevel3: editForm.keyLevel3 || null,
      keyLevel3Label: editForm.keyLevel3Label || null,
    });
  };

  const biasColor =
    item.bias === "BULLISH"
      ? "text-[#00FF88]"
      : item.bias === "BEARISH"
      ? "text-[#FF3B5C]"
      : "text-slate-400";

  const BiasIcon =
    item.bias === "BULLISH" ? TrendingUp : item.bias === "BEARISH" ? TrendingDown : Minus;

  const keyLevels = [
    { price: item.keyLevel1, label: item.keyLevel1Label },
    { price: item.keyLevel2, label: item.keyLevel2Label },
    { price: item.keyLevel3, label: item.keyLevel3Label },
  ].filter((l) => l.price);

  return (
    <div className="bg-[#0D1117] rounded-xl border border-slate-800/80 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          <div
            className={cn(
              "w-8 h-8 rounded-lg flex items-center justify-center",
              item.assetClass === "FOREX"
                ? "bg-[#60A5FA]/10 text-[#60A5FA]"
                : "bg-[#F5A623]/10 text-[#F5A623]"
            )}
          >
            {item.assetClass === "FOREX" ? (
              <Globe className="w-4 h-4" />
            ) : (
              <BarChart2 className="w-4 h-4" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setChartOpen(true)}
                className="font-bold text-white hover:text-[#60A5FA] transition-colors text-sm"
              >
                {item.displaySymbol}
              </button>
              <Badge
                variant="outline"
                className="text-[10px] px-1.5 py-0 border border-slate-700 text-slate-400"
              >
                {item.timeframe}
              </Badge>
              <Badge
                variant="outline"
                className={cn(
                  "text-[10px] px-1.5 py-0 border",
                  item.bias === "BULLISH"
                    ? "border-[#00FF88]/30 text-[#00FF88]"
                    : item.bias === "BEARISH"
                    ? "border-[#FF3B5C]/30 text-[#FF3B5C]"
                    : "border-slate-700 text-slate-400"
                )}
              >
                <BiasIcon className="w-2.5 h-2.5 mr-0.5" />
                {item.bias ?? "NEUTRAL"}
              </Badge>
            </div>
            {item.notes && (
              <p className="text-[11px] text-slate-500 mt-0.5 max-w-xs truncate">{item.notes}</p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {parsedTags.length > 0 && (
            <div className="hidden sm:flex gap-1">
              {parsedTags.slice(0, 2).map((tag) => (
                <span
                  key={tag}
                  className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-500 border border-slate-700"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
          <button
            onClick={() => setJournalModalOpen(true)}
            className="p-1.5 rounded-md text-slate-500 hover:text-[#F5A623] hover:bg-[#F5A623]/10 transition-all"
            title="Push to Journal"
          >
            <BookOpen className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setChartOpen(true)}
            className="p-1.5 rounded-md text-slate-500 hover:text-[#60A5FA] hover:bg-[#60A5FA]/10 transition-all"
            title="Open Chart"
          >
            <BarChart2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => { setExpanded(!expanded); setEditing(false); }}
            className="p-1.5 rounded-md text-slate-500 hover:text-slate-300 hover:bg-slate-800/40 transition-all"
          >
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={() => deleteMutation.mutate({ id: item.id })}
            disabled={deleteMutation.isPending}
            className="p-1.5 rounded-md text-slate-600 hover:text-[#FF3B5C] hover:bg-[#FF3B5C]/10 transition-all"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Key Levels Preview */}
      {keyLevels.length > 0 && !expanded && (
        <div className="flex gap-2 px-4 pb-3">
          {keyLevels.map((level, i) => (
            <div
              key={i}
              className="flex items-center gap-1.5 bg-slate-900/60 rounded px-2 py-1 border border-slate-800"
            >
              <span className="text-[10px] text-slate-500">{level.label}:</span>
              <span className="text-[10px] font-mono text-white">{level.price}</span>
            </div>
          ))}
        </div>
      )}

      {/* Expanded Details */}
      {expanded && (
        <div className="px-4 pb-4 border-t border-slate-800/60 pt-4 space-y-4">
          {!editing ? (
            <>
              {/* Key Levels */}
              {keyLevels.length > 0 && (
                <div>
                  <div className="text-[11px] text-slate-500 uppercase tracking-wider mb-2">Key Levels</div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {keyLevels.map((level, i) => (
                      <div
                        key={i}
                        className="bg-slate-900/60 rounded-lg border border-slate-800 p-2.5 text-center"
                      >
                        <div className="text-[10px] text-slate-500 mb-0.5">{level.label}</div>
                        <div className="text-sm font-mono text-white font-bold">{level.price}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Notes */}
              {item.notes && (
                <div>
                  <div className="text-[11px] text-slate-500 uppercase tracking-wider mb-1.5">Notes</div>
                  <p className="text-sm text-slate-300 bg-slate-900/40 rounded-lg border border-slate-800 p-3 leading-relaxed">
                    {item.notes}
                  </p>
                </div>
              )}

              {/* Tags */}
              {parsedTags.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {parsedTags.map((tag) => (
                    <span
                      key={tag}
                      className="flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700"
                    >
                      <Tag className="w-2.5 h-2.5" />
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              <div className="flex justify-end">
                <Button
                  size="sm"
                  onClick={() => setEditing(true)}
                  className="h-7 text-xs bg-slate-800/60 border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-700"
                >
                  <Edit3 className="w-3 h-3 mr-1.5" />
                  Edit
                </Button>
              </div>
            </>
          ) : (
            <div className="space-y-3">
              <div className="text-[11px] text-slate-400 uppercase tracking-wider">Edit Watchlist Item</div>

              {/* Bias */}
              <div>
                <Label className="text-xs text-slate-400 mb-1 block">Bias</Label>
                <div className="flex gap-1">
                  {(["BULLISH", "NEUTRAL", "BEARISH"] as BiasType[]).map((b) => (
                    <button
                      key={b}
                      onClick={() => setEditForm({ ...editForm, bias: b })}
                      className={cn(
                        "flex-1 h-8 text-xs rounded border transition-all",
                        editForm.bias === b
                          ? b === "BULLISH"
                            ? "bg-[#00FF88]/10 border-[#00FF88]/30 text-[#00FF88]"
                            : b === "BEARISH"
                            ? "bg-[#FF3B5C]/10 border-[#FF3B5C]/30 text-[#FF3B5C]"
                            : "bg-slate-700/40 border-slate-600 text-slate-300"
                          : "border-slate-700 text-slate-500 hover:text-slate-300"
                      )}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>

              {/* Key Levels */}
              <div className="space-y-2">
                <div className="text-[11px] text-slate-500 uppercase tracking-wider">Key Levels</div>
                {[1, 2, 3].map((n) => (
                  <div key={n} className="flex gap-2">
                    <Input
                      value={(editForm as any)[`keyLevel${n}Label`]}
                      onChange={(e) => setEditForm({ ...editForm, [`keyLevel${n}Label`]: e.target.value } as any)}
                      placeholder="Label"
                      className="h-7 text-xs bg-[#080B10] border-slate-700 text-slate-300 w-32"
                    />
                    <Input
                      type="number"
                      step="any"
                      value={(editForm as any)[`keyLevel${n}`]}
                      onChange={(e) => setEditForm({ ...editForm, [`keyLevel${n}`]: e.target.value } as any)}
                      placeholder="Price level"
                      className="h-7 text-xs bg-[#080B10] border-slate-700 text-white font-mono flex-1"
                    />
                  </div>
                ))}
              </div>

              {/* Notes */}
              <div>
                <Label className="text-xs text-slate-400 mb-1 block">Notes</Label>
                <Input
                  value={editForm.notes}
                  onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })}
                  placeholder="Trade notes..."
                  className="h-8 text-sm bg-[#080B10] border-slate-700 text-white"
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditing(false)}
                  className="h-7 text-xs border-slate-700 text-slate-400 bg-transparent hover:text-white"
                >
                  <X className="w-3 h-3 mr-1" />
                  Cancel
                </Button>
                <Button
                  size="sm"
                  onClick={handleSave}
                  disabled={updateMutation.isPending}
                  className="h-7 text-xs bg-[#00FF88]/10 border border-[#00FF88]/30 text-[#00FF88] hover:bg-[#00FF88]/20"
                >
                  <Check className="w-3 h-3 mr-1" />
                  {updateMutation.isPending ? "Saving..." : "Save"}
                </Button>
              </div>
            </div>
          )}
        </div>
      )}

      <TradingViewModal
        isOpen={chartOpen}
        symbol={item.symbol}
        displaySymbol={item.displaySymbol}
        assetClass={item.assetClass}
        timeframe={item.timeframe}
        onClose={() => setChartOpen(false)}
      />

      {/* Push to Journal Modal */}
      {journalModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
          onClick={(e) => { if (e.target === e.currentTarget) setJournalModalOpen(false); }}
        >
          <div className="bg-[#0D1117] border border-slate-700 rounded-xl w-full max-w-md shadow-2xl">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-[#F5A623]/10 border border-[#F5A623]/20 flex items-center justify-center">
                  <BookOpen className="w-3.5 h-3.5 text-[#F5A623]" />
                </div>
                <div>
                  <div className="text-sm font-bold text-white">Push to Journal</div>
                  <div className="text-[10px] text-slate-500 font-mono">{item.displaySymbol} · {item.assetClass}</div>
                </div>
              </div>
              <button
                onClick={() => setJournalModalOpen(false)}
                className="p-1.5 rounded-md text-slate-500 hover:text-white hover:bg-slate-800 transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="px-5 py-4 space-y-4">
              {/* Direction */}
              <div>
                <Label className="text-xs text-slate-400 mb-1.5 block">Direction</Label>
                <div className="grid grid-cols-4 gap-1.5">
                  {(["CALL", "PUT", "LONG", "SHORT"] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => setJournalForm({ ...journalForm, setupType: t })}
                      className={cn(
                        "h-8 text-xs rounded border font-medium transition-all",
                        journalForm.setupType === t
                          ? t === "CALL" || t === "LONG"
                            ? "bg-[#00FF88]/10 border-[#00FF88]/30 text-[#00FF88]"
                            : "bg-[#FF3B5C]/10 border-[#FF3B5C]/30 text-[#FF3B5C]"
                          : "border-slate-700 text-slate-500 hover:text-slate-300"
                      )}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quality */}
              <div>
                <Label className="text-xs text-slate-400 mb-1.5 block">Quality</Label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(["PREMIUM", "STRONG", "DEVELOPING"] as const).map((q) => (
                    <button
                      key={q}
                      onClick={() => setJournalForm({ ...journalForm, quality: q })}
                      className={cn(
                        "h-8 text-xs rounded border font-medium transition-all",
                        journalForm.quality === q
                          ? q === "PREMIUM"
                            ? "bg-[#F5A623]/10 border-[#F5A623]/30 text-[#F5A623]"
                            : q === "STRONG"
                            ? "bg-[#60A5FA]/10 border-[#60A5FA]/30 text-[#60A5FA]"
                            : "bg-slate-700/40 border-slate-600 text-slate-300"
                          : "border-slate-700 text-slate-500 hover:text-slate-300"
                      )}
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>

              {/* Timeframe */}
              <div>
                <Label className="text-xs text-slate-400 mb-1.5 block">Timeframe</Label>
                <div className="flex gap-1.5 flex-wrap">
                  {["15m", "30m", "1H", "4H", "Daily", "Weekly"].map((tf) => (
                    <button
                      key={tf}
                      onClick={() => setJournalForm({ ...journalForm, timeframe: tf })}
                      className={cn(
                        "px-3 h-7 text-xs rounded border transition-all",
                        journalForm.timeframe === tf
                          ? "bg-[#60A5FA]/10 border-[#60A5FA]/30 text-[#60A5FA]"
                          : "border-slate-700 text-slate-500 hover:text-slate-300"
                      )}
                    >
                      {tf}
                    </button>
                  ))}
                </div>
              </div>

              {/* Levels */}
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <Label className="text-xs text-slate-400 mb-1 block">Entry</Label>
                  <Input
                    type="number"
                    step="any"
                    value={journalForm.entry}
                    onChange={(e) => setJournalForm({ ...journalForm, entry: e.target.value })}
                    placeholder="0.00"
                    className="h-8 text-xs bg-[#080B10] border-slate-700 text-white font-mono"
                  />
                </div>
                <div>
                  <Label className="text-xs text-slate-400 mb-1 block">Stop Loss</Label>
                  <Input
                    type="number"
                    step="any"
                    value={journalForm.stopLoss}
                    onChange={(e) => setJournalForm({ ...journalForm, stopLoss: e.target.value })}
                    placeholder="0.00"
                    className="h-8 text-xs bg-[#080B10] border-slate-700 text-white font-mono"
                  />
                </div>
                <div>
                  <Label className="text-xs text-slate-400 mb-1 block">Take Profit</Label>
                  <Input
                    type="number"
                    step="any"
                    value={journalForm.takeProfit}
                    onChange={(e) => setJournalForm({ ...journalForm, takeProfit: e.target.value })}
                    placeholder="0.00"
                    className="h-8 text-xs bg-[#080B10] border-slate-700 text-white font-mono"
                  />
                </div>
              </div>

              {/* Live RR Display */}
              {(() => {
                const e = parseFloat(journalForm.entry);
                const sl = parseFloat(journalForm.stopLoss);
                const tp = parseFloat(journalForm.takeProfit);
                const hasValues = !isNaN(e) && !isNaN(sl) && !isNaN(tp) && e > 0 && sl > 0 && tp > 0;
                const risk = hasValues ? Math.abs(e - sl) : 0;
                const reward = hasValues ? Math.abs(tp - e) : 0;
                const rr = risk > 0 ? reward / risk : 0;
                const isGood = rr >= 2;
                const isFair = rr >= 1 && rr < 2;
                return hasValues ? (
                  <div className={cn(
                    "flex items-center justify-between rounded-lg border px-3 py-2.5 transition-all",
                    isGood ? "bg-[#00FF88]/5 border-[#00FF88]/20" : isFair ? "bg-[#F5A623]/5 border-[#F5A623]/20" : "bg-[#FF3B5C]/5 border-[#FF3B5C]/20"
                  )}>
                    <div className="flex items-center gap-4">
                      <div>
                        <div className="text-[10px] text-slate-500 uppercase tracking-wider">Risk</div>
                        <div className="text-xs font-mono text-white">{risk.toFixed(risk < 0.1 ? 5 : risk < 1 ? 4 : 2)}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-500 uppercase tracking-wider">Reward</div>
                        <div className="text-xs font-mono text-white">{reward.toFixed(reward < 0.1 ? 5 : reward < 1 ? 4 : 2)}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-slate-500 uppercase tracking-wider">R:R Ratio</div>
                      <div className={cn(
                        "text-lg font-bold font-mono",
                        isGood ? "text-[#00FF88]" : isFair ? "text-[#F5A623]" : "text-[#FF3B5C]"
                      )}>
                        1:{rr.toFixed(1)}
                      </div>
                    </div>
                  </div>
                ) : null;
              })()}

              {/* Notes */}
              <div>
                <Label className="text-xs text-slate-400 mb-1 block">Notes <span className="text-slate-600">(optional)</span></Label>
                <Textarea
                  value={journalForm.notes}
                  onChange={(e) => setJournalForm({ ...journalForm, notes: e.target.value })}
                  placeholder="Trade rationale, confluences, market context..."
                  className="text-xs bg-[#080B10] border-slate-700 text-white resize-none h-20"
                />
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex justify-end gap-2 px-5 py-4 border-t border-slate-800">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setJournalModalOpen(false)}
                className="h-8 text-xs border-slate-700 text-slate-400 bg-transparent hover:text-white"
              >
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={handlePushToJournal}
                disabled={createJournalEntry.isPending}
                className="h-8 text-xs bg-[#F5A623]/10 border border-[#F5A623]/30 text-[#F5A623] hover:bg-[#F5A623]/20"
              >
                <Send className="w-3 h-3 mr-1.5" />
                {createJournalEntry.isPending ? "Pushing..." : "Push to Journal"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Main Watchlist Page ──────────────────────────────────────────────────────

export default function WatchlistPage({ onSwitchToJournal }: { onSwitchToJournal?: () => void }) {
  const { isAuthenticated, loading } = useAuth();
  const [showAddForm, setShowAddForm] = useState(false);
  const [filterBias, setFilterBias] = useState<BiasType | "ALL">("ALL");
  const [filterAsset, setFilterAsset] = useState<"STOCK" | "FOREX" | "ALL">("ALL");
  const [search, setSearch] = useState("");

  const { data: items = [], isLoading } = trpc.watchlist.list.useQuery(undefined, {
    enabled: isAuthenticated,
    refetchOnWindowFocus: false,
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-[#60A5FA]/30 border-t-[#60A5FA] rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <Lock className="w-10 h-10 text-slate-700" />
        <div className="text-center">
          <p className="text-slate-400 font-medium">Sign in to use your Watchlist</p>
          <p className="text-slate-600 text-sm mt-1">Your watchlist is saved to your account and syncs across devices</p>
        </div>
        <a
          href={getLoginUrl()}
          className="px-4 py-2 bg-[#60A5FA]/10 border border-[#60A5FA]/30 text-[#60A5FA] rounded-lg text-sm hover:bg-[#60A5FA]/20 transition-all"
        >
          Log In
        </a>
      </div>
    );
  }

  const filtered = items.filter((item) => {
    if (filterBias !== "ALL" && item.bias !== filterBias) return false;
    if (filterAsset !== "ALL" && item.assetClass !== filterAsset) return false;
    if (search && !item.displaySymbol.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const bullishCount = items.filter((i) => i.bias === "BULLISH").length;
  const bearishCount = items.filter((i) => i.bias === "BEARISH").length;
  const neutralCount = items.filter((i) => i.bias === "NEUTRAL" || !i.bias).length;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Eye className="w-5 h-5 text-[#60A5FA]" />
            Watchlist
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Pin symbols, mark key levels, and track your bias
          </p>
        </div>
        <Button
          onClick={() => setShowAddForm(!showAddForm)}
          size="sm"
          className="h-8 text-xs bg-[#60A5FA]/10 border border-[#60A5FA]/30 text-[#60A5FA] hover:bg-[#60A5FA]/20"
        >
          <Plus className="w-3.5 h-3.5 mr-1.5" />
          Add Symbol
        </Button>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
        <div className="bg-[#0D1117] rounded-lg border border-slate-800 p-3 text-center">
          <div className="text-[10px] text-slate-500 mb-1">TOTAL</div>
          <div className="text-xl font-bold font-mono text-white">{items.length}</div>
        </div>
        <div className="bg-[#0D1117] rounded-lg border border-[#00FF88]/20 p-3 text-center">
          <div className="text-[10px] text-[#00FF88]/60 mb-1">BULLISH</div>
          <div className="text-xl font-bold font-mono text-[#00FF88]">{bullishCount}</div>
        </div>
        <div className="bg-[#0D1117] rounded-lg border border-[#FF3B5C]/20 p-3 text-center">
          <div className="text-[10px] text-[#FF3B5C]/60 mb-1">BEARISH</div>
          <div className="text-xl font-bold font-mono text-[#FF3B5C]">{bearishCount}</div>
        </div>
        <div className="bg-[#0D1117] rounded-lg border border-slate-800 p-3 text-center">
          <div className="text-[10px] text-slate-500 mb-1">NEUTRAL</div>
          <div className="text-xl font-bold font-mono text-slate-300">{neutralCount}</div>
        </div>
        <div className="bg-[#0D1117] rounded-lg border border-slate-800 p-3 text-center">
          <div className="text-[10px] text-slate-500 mb-1">FOREX</div>
          <div className="text-xl font-bold font-mono text-[#60A5FA]">
            {items.filter((i) => i.assetClass === "FOREX").length}
          </div>
        </div>
      </div>

      {/* Add Form */}
      {showAddForm && <AddSymbolForm onClose={() => setShowAddForm(false)} />}

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search symbol..."
          className="h-8 text-xs bg-[#0D1117] border-slate-700 text-white w-40"
        />
        <div className="flex gap-1">
          {(["ALL", "FOREX", "STOCK"] as const).map((ac) => (
            <button
              key={ac}
              onClick={() => setFilterAsset(ac)}
              className={cn(
                "px-3 h-8 text-xs rounded border transition-all",
                filterAsset === ac
                  ? "bg-[#60A5FA]/10 border-[#60A5FA]/30 text-[#60A5FA]"
                  : "border-slate-700 text-slate-500 hover:text-slate-300"
              )}
            >
              {ac}
            </button>
          ))}
        </div>
        <div className="flex gap-1">
          {(["ALL", "BULLISH", "NEUTRAL", "BEARISH"] as const).map((b) => (
            <button
              key={b}
              onClick={() => setFilterBias(b === "ALL" ? "ALL" : (b as BiasType))}
              className={cn(
                "px-3 h-8 text-xs rounded border transition-all",
                filterBias === b
                  ? b === "BULLISH"
                    ? "bg-[#00FF88]/10 border-[#00FF88]/30 text-[#00FF88]"
                    : b === "BEARISH"
                    ? "bg-[#FF3B5C]/10 border-[#FF3B5C]/30 text-[#FF3B5C]"
                    : "bg-slate-700/40 border-slate-600 text-slate-300"
                  : "border-slate-700 text-slate-500 hover:text-slate-300"
              )}
            >
              {b}
            </button>
          ))}
        </div>
      </div>

      {/* Watchlist Items */}
      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 bg-[#0D1117] rounded-xl border border-slate-800 animate-pulse" />
          ))}
        </div>
      ) : filtered.length > 0 ? (
        <div className="space-y-3">
          {filtered.map((item) => (
            <WatchlistCard key={item.id} item={item as WatchlistItem} onSwitchToJournal={onSwitchToJournal} />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-16 bg-[#0D1117] rounded-xl border border-slate-800">
          <Eye className="w-10 h-10 text-slate-700 mx-auto mb-3" />
          <p className="text-slate-500 text-sm font-medium">Your watchlist is empty</p>
          <p className="text-slate-600 text-xs mt-1 max-w-sm mx-auto">
            Add symbols you're monitoring — pin key supply/demand levels, set your bias, and open charts instantly.
          </p>
          <Button
            onClick={() => setShowAddForm(true)}
            size="sm"
            className="mt-4 h-8 text-xs bg-[#60A5FA]/10 border border-[#60A5FA]/30 text-[#60A5FA] hover:bg-[#60A5FA]/20"
          >
            <Plus className="w-3.5 h-3.5 mr-1.5" />
            Add Your First Symbol
          </Button>
        </div>
      ) : (
        <div className="text-center py-12 bg-[#0D1117] rounded-xl border border-slate-800">
          <BookOpen className="w-8 h-8 text-slate-700 mx-auto mb-2" />
          <p className="text-slate-500 text-sm">No symbols match your filters</p>
        </div>
      )}
    </div>
  );
}

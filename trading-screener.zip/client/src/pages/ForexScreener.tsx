import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  TrendingUp, TrendingDown, RefreshCw, BookOpen,
  ChevronDown, ChevronUp, AlertCircle, Globe,
  Search, SlidersHorizontal, Zap, Shield, BarChart2, Bell,
  Calculator as CalcIcon, Eye,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import TradingViewModal from "@/components/TradingViewModal";
import SymbolManager from "@/components/SymbolManager";
import { useCalculator } from "@/contexts/CalculatorContext";

type Direction = "ALL" | "LONG" | "SHORT";
type QualityFilter = "ALL" | "PREMIUM" | "STRONG" | "DEVELOPING";
type Timeframe = "15m" | "30m" | "1H" | "4H" | "Daily";

interface ScreenerSetup {
  id: string;
  symbol: string;
  displaySymbol: string;
  assetClass: "STOCK" | "FOREX";
  setupType: "CALL" | "PUT" | "LONG" | "SHORT";
  quality: "PREMIUM" | "STRONG" | "DEVELOPING";
  pattern: string;
  timeframe: string;
  currentPrice: number;
  levels: {
    entry: number;
    stopLoss: number;
    takeProfit: number;
    takeProfit2: number;
    takeProfit3: number;
  };
  rrRatio: number;
  confluences: string[];
  session?: string;
  keyLevel?: { price: number; type: string };
  scannedAt: string;
}

interface ForexScreenerProps {
  onPushToJournal: (setup: ScreenerSetup) => void;
  pushedIds: Set<string>;
  autoPush: boolean;
  onSwitchToWatchlist?: () => void;
}

const qualityConfig = {
  PREMIUM: { color: "text-[#F5A623]", bg: "bg-[#F5A623]/10", border: "border-[#F5A623]/30", label: "PREMIUM", glow: "shadow-[0_0_12px_rgba(245,166,35,0.15)]" },
  STRONG: { color: "text-[#60A5FA]", bg: "bg-[#60A5FA]/10", border: "border-[#60A5FA]/30", label: "STRONG", glow: "" },
  DEVELOPING: { color: "text-slate-400", bg: "bg-slate-800/40", border: "border-slate-700", label: "DEVELOPING", glow: "" },
};

function SetupCard({ setup, onPush, isPushed, onViewChart, onSetAlert, onCalculate, onAddToWatchlist }: { setup: ScreenerSetup; onPush: () => void; isPushed: boolean; onViewChart: () => void; onSetAlert: () => void; onCalculate: () => void; onAddToWatchlist: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const isLong = setup.setupType === "LONG";
  const qc = qualityConfig[setup.quality];
  const risk = Math.abs(setup.levels.entry - setup.levels.stopLoss);
  const rr2 = (risk > 0 && setup.levels.takeProfit2 != null) ? (Math.abs(setup.levels.takeProfit2 - setup.levels.entry) / risk).toFixed(1) : null;
  const rr3 = (risk > 0 && setup.levels.takeProfit3 != null) ? (Math.abs(setup.levels.takeProfit3 - setup.levels.entry) / risk).toFixed(1) : null;
  const isJpy = setup.symbol.includes("JPY") || setup.symbol.includes("XAU") || setup.symbol.includes("XAG");
  const fmt = (n: number) => isJpy ? n.toFixed(3) : n.toFixed(5);

  return (
    <div className={cn("rounded-xl border bg-[#0D1117] overflow-hidden transition-all duration-200", qc.border, qc.glow)}>
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0", isLong ? "bg-[#00FF88]/10" : "bg-[#FF3B5C]/10")}>
              {isLong ? <TrendingUp className="w-4 h-4 text-[#00FF88]" /> : <TrendingDown className="w-4 h-4 text-[#FF3B5C]" />}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={onViewChart}
                  className="font-mono font-bold text-white text-base hover:text-[#60A5FA] transition-colors hover:underline underline-offset-2"
                  title="View chart"
                >
                  {setup.displaySymbol}
                </button>
                <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border", qc.bg, qc.border, qc.color)}>⚡ {qc.label}</Badge>
                <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border", isLong ? "border-[#00FF88]/30 text-[#00FF88] bg-[#00FF88]/5" : "border-[#FF3B5C]/30 text-[#FF3B5C] bg-[#FF3B5C]/5")}>
                  {isLong ? "LONG" : "SHORT"}
                </Badge>
                <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-slate-700 text-slate-400">{setup.timeframe}</Badge>
                {setup.session && <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-slate-800 text-slate-500">{setup.session}</Badge>}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">{setup.pattern}</div>
            </div>
          </div>
          <div className="text-right flex-shrink-0">
            <div className={cn("text-lg font-mono font-bold", setup.rrRatio >= 3 ? "text-[#00FF88]" : setup.rrRatio >= 2 ? "text-[#60A5FA]" : "text-slate-400")}>{setup.rrRatio.toFixed(1)}:1</div>
            <div className="text-[10px] text-slate-600 font-mono">RR Ratio</div>
          </div>
        </div>

        <div className="mt-2 mb-3">
          <span className="text-[10px] text-slate-600 font-mono">Price: </span>
          <span className="text-xs font-mono text-slate-300">{fmt(setup.currentPrice)}</span>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-3">
          <div className="bg-[#080B10] rounded-lg p-2.5 border border-slate-800">
            <div className="text-[10px] text-slate-600 uppercase font-mono mb-1">Entry</div>
            <div className="font-mono font-semibold text-white text-sm">{fmt(setup.levels.entry)}</div>
          </div>
          <div className="bg-[#080B10] rounded-lg p-2.5 border border-[#FF3B5C]/20">
            <div className="text-[10px] text-[#FF3B5C]/60 uppercase font-mono mb-1">Stop Loss</div>
            <div className="font-mono font-semibold text-[#FF3B5C] text-sm">{fmt(setup.levels.stopLoss)}</div>
          </div>
          <div className="bg-[#080B10] rounded-lg p-2.5 border border-[#00FF88]/20">
            <div className="text-[10px] text-[#00FF88]/60 uppercase font-mono mb-1">TP1 (2:1)</div>
            <div className="font-mono font-semibold text-[#00FF88] text-sm">{fmt(setup.levels.takeProfit)}</div>
          </div>
        </div>

        <div className="flex items-center justify-between mt-3 gap-2">
          <button onClick={() => setExpanded(!expanded)} className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-300 transition-colors">
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            {expanded ? "Less" : "More details"}
          </button>
          <div className="flex items-center gap-1.5 flex-wrap">
            <Button size="sm" variant="outline" onClick={onViewChart}
              className="text-xs h-7 px-2 border border-[#60A5FA]/30 text-[#60A5FA] hover:bg-[#60A5FA]/10 transition-all">
              <BarChart2 className="w-3 h-3 mr-1" />
              Chart
            </Button>
            <Button size="sm" variant="outline" onClick={onCalculate}
              className="text-xs h-7 px-2 border border-[#34D399]/30 text-[#34D399] hover:bg-[#34D399]/10 transition-all">
              <CalcIcon className="w-3 h-3 mr-1" />
              Calc
            </Button>
            <Button size="sm" variant="outline" onClick={onAddToWatchlist}
              className="text-xs h-7 px-2 border border-[#60A5FA]/30 text-[#60A5FA] hover:bg-[#60A5FA]/10 transition-all">
              <Eye className="w-3 h-3 mr-1" />
              Watch
            </Button>
            <Button size="sm" variant="outline" onClick={onSetAlert}
              className="text-xs h-7 px-2 border border-[#F87171]/30 text-[#F87171] hover:bg-[#F87171]/10 transition-all">
              <Bell className="w-3 h-3 mr-1" />
              Alert
            </Button>
            <Button size="sm" variant="outline" onClick={onPush} disabled={isPushed}
              className={cn("text-xs h-7 px-2 border transition-all", isPushed ? "border-slate-700 text-slate-600 cursor-not-allowed" : "border-[#F5A623]/30 text-[#F5A623] hover:bg-[#F5A623]/10")}>
              <BookOpen className="w-3 h-3 mr-1" />
              {isPushed ? "Journaled" : "Push"}
            </Button>
          </div>
        </div>
      </div>

      {expanded && (
        <div className="border-t border-slate-800 p-4 space-y-3 bg-[#080B10]/50">
          {(setup.levels.takeProfit2 != null || setup.levels.takeProfit3 != null) && (
            <div className="grid grid-cols-2 gap-2">
              {setup.levels.takeProfit2 != null && (
                <div className="bg-[#080B10] rounded-lg p-2.5 border border-[#00FF88]/10">
                  <div className="text-[10px] text-[#00FF88]/50 uppercase font-mono mb-1">TP2{rr2 ? ` (${rr2}:1)` : ""}</div>
                  <div className="font-mono font-semibold text-[#00FF88]/80 text-sm">{fmt(setup.levels.takeProfit2)}</div>
                </div>
              )}
              {setup.levels.takeProfit3 != null && (
                <div className="bg-[#080B10] rounded-lg p-2.5 border border-[#00FF88]/10">
                  <div className="text-[10px] text-[#00FF88]/50 uppercase font-mono mb-1">TP3{rr3 ? ` (${rr3}:1)` : ""}</div>
                  <div className="font-mono font-semibold text-[#00FF88]/80 text-sm">{fmt(setup.levels.takeProfit3)}</div>
                </div>
              )}
            </div>
          )}
          {setup.confluences.length > 0 && (
            <div>
              <div className="text-[10px] text-slate-600 uppercase font-mono mb-2">Confluences</div>
              <div className="flex flex-wrap gap-1.5">
                {setup.confluences.map((c, i) => (
                  <span key={i} className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">{c}</span>
                ))}
              </div>
            </div>
          )}
          {setup.keyLevel && (
            <div className="flex items-center gap-2 bg-[#0D1117] rounded-lg p-2.5 border border-[#60A5FA]/20">
              <div className="w-1.5 h-1.5 rounded-full bg-[#60A5FA] flex-shrink-0" />
              <div>
                <div className="text-[10px] text-[#60A5FA]/60 uppercase font-mono">Key Level</div>
                <div className="text-xs font-mono text-[#60A5FA] font-semibold">
                  {fmt(setup.keyLevel.price)}
                  <span className="text-[10px] text-slate-500 font-normal ml-2">{setup.keyLevel.type}</span>
                </div>
              </div>
            </div>
          )}
          <div className="text-[10px] text-slate-700 font-mono">Scanned: {new Date(setup.scannedAt).toLocaleTimeString()} · Live data via Oanda v20 API</div>
        </div>
      )}
    </div>
  );
}

export default function ForexScreener({ onPushToJournal, pushedIds, autoPush, onSwitchToWatchlist }: ForexScreenerProps) {
  const [timeframe, setTimeframe] = useState<Timeframe>("4H");
  const [minRR, setMinRR] = useState(2);
  const [filterDir, setFilterDir] = useState<Direction>("ALL");
  const [filterQuality, setFilterQuality] = useState<QualityFilter>("ALL");
  const [search, setSearch] = useState("");
  const [autoPushedIds, setAutoPushedIds] = useState<Set<string>>(new Set());
  const [chartSetup, setChartSetup] = useState<ScreenerSetup | null>(null);
  const { isAuthenticated } = useAuth();

  const createAlert = trpc.alerts.create.useMutation({
    onSuccess: () => toast.success("Alert set! You'll be notified when price approaches entry."),
    onError: (e) => toast.error(e.message),
  });

  const handleSetAlert = (setup: ScreenerSetup) => {
    if (!isAuthenticated) {
      toast.error("Please log in to set alerts", {
        action: { label: "Log In", onClick: () => { window.location.assign(getLoginUrl()); } },
      });
      return;
    }
    createAlert.mutate({
      symbol: setup.symbol,
      displaySymbol: setup.displaySymbol,
      assetClass: "FOREX",
      direction: setup.setupType,
      targetPrice: setup.levels.entry,
      currentPrice: setup.currentPrice,
      proximityPct: 0.5,
      timeframe: setup.timeframe,
      pattern: setup.pattern,
    });
  };

  const { pushToCalculator } = useCalculator();

  const handleCalculate = (setup: ScreenerSetup) => {
    pushToCalculator({
      symbol: setup.symbol,
      displaySymbol: setup.displaySymbol,
      assetClass: "FOREX",
      direction: setup.setupType as "LONG" | "SHORT",
      entry: setup.levels.entry,
      stopLoss: setup.levels.stopLoss,
      takeProfit: setup.levels.takeProfit,
      takeProfit2: setup.levels.takeProfit2,
      takeProfit3: setup.levels.takeProfit3,
      rrRatio: setup.rrRatio,
      pattern: setup.pattern,
      timeframe: setup.timeframe,
    });
    toast.success(`${setup.displaySymbol} sent to Calculator`, {
      description: "Switch to the Calc tab to view position sizing",
    });
  };

  const addToWatchlist = trpc.watchlist.create.useMutation({
    onSuccess: (result, vars) => {
      if (result.duplicate) {
        toast.warning(`${vars.displaySymbol} already on Watchlist`, {
          description: `${vars.displaySymbol} (${vars.timeframe}) is already being watched.`,
          action: { label: "View in Watch tab", onClick: () => onSwitchToWatchlist?.() },
        });
      } else {
        toast.success(`${vars.displaySymbol} added to Watchlist`, {
          description: `Entry: ${vars.keyLevel1} · SL: ${vars.keyLevel2} · TP: ${vars.keyLevel3}`,
        });
      }
    },
    onError: (e) => toast.error(e.message),
  });

  const handleAddToWatchlist = (setup: ScreenerSetup) => {
    if (!isAuthenticated) {
      toast.error("Please log in to use Watchlist", {
        action: { label: "Log In", onClick: () => { window.location.assign(getLoginUrl()); } },
      });
      return;
    }
    const bias = setup.setupType === "LONG" ? "BULLISH" : "BEARISH";
    addToWatchlist.mutate({
      symbol: setup.symbol,
      displaySymbol: setup.displaySymbol,
      assetClass: "FOREX",
      timeframe: setup.timeframe,
      bias,
      notes: `${setup.pattern} — Entry: ${setup.levels.entry} | SL: ${setup.levels.stopLoss} | TP: ${setup.levels.takeProfit}`,
      keyLevel1: String(setup.levels.entry),
      keyLevel1Label: "Entry",
      keyLevel2: String(setup.levels.stopLoss),
      keyLevel2Label: "Stop Loss",
      keyLevel3: String(setup.levels.takeProfit),
      keyLevel3Label: "Take Profit",
      tags: [setup.pattern, setup.setupType, setup.quality],
    });
  };

  const { data, isLoading, error, refetch, isFetching } = trpc.screener.forex.useQuery(
    { timeframe, minRR },
    { refetchOnWindowFocus: false, staleTime: 5 * 60 * 1000 }
  );

  const setups = data?.setups ?? [];

  useEffect(() => {
    if (!autoPush || !data?.setups) return;
    const premiumSetups = data.setups.filter((s) => s.quality === "PREMIUM");
    for (const setup of premiumSetups) {
      if (!pushedIds.has(setup.id) && !autoPushedIds.has(setup.id)) {
        onPushToJournal(setup as unknown as ScreenerSetup);
        setAutoPushedIds((prev) => new Set(Array.from(prev).concat(setup.id)));
        toast.success(`Auto-pushed ${setup.displaySymbol} ${setup.setupType} to journal`);
      }
    }
  }, [autoPush, data]);

  useEffect(() => {
    if (data && !isLoading) {
      toast.success(`Forex scan complete — ${data.setups.length} setups found`, {
        description: `${data.setups.filter(s => s.quality === "PREMIUM").length} premium · ${data.totalPairs} pairs scanned via Oanda`,
      });
    }
  }, [data]);

  const filtered = setups.filter((s) => {
    if (filterDir !== "ALL" && s.setupType !== filterDir) return false;
    if (filterQuality !== "ALL" && s.quality !== filterQuality) return false;
    if (search && !s.displaySymbol.toLowerCase().includes(search.toLowerCase()) && !s.pattern.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const premiumCount = setups.filter((s) => s.quality === "PREMIUM").length;
  const strongCount = setups.filter((s) => s.quality === "STRONG").length;
  const longCount = setups.filter((s) => s.setupType === "LONG").length;
  const shortCount = setups.filter((s) => s.setupType === "SHORT").length;
  const avgRR = setups.length > 0 ? (setups.reduce((a, b) => a + b.rrRatio, 0) / setups.length).toFixed(1) : "—";

  return (
    <div className="flex flex-col h-full space-y-4">
      {/* TradingView Chart Modal */}
      {chartSetup && (
        <TradingViewModal
          symbol={chartSetup.symbol}
          displaySymbol={chartSetup.displaySymbol}
          timeframe={chartSetup.timeframe}
          assetClass={chartSetup.assetClass}
          isOpen={true}
          onClose={() => setChartSetup(null)}
        />
      )}

      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-xl border border-slate-800" style={{ minHeight: 110 }}>
        <div className="absolute inset-0 bg-cover bg-center opacity-20" style={{ backgroundImage: `url(https://d2xsxph8kpxj0f.cloudfront.net/310519663485819244/6HDX6MZMMiuXiLTEXJkkHb/trading-forex-bg-8Lsfkfq4dJNGZiCmcuQap4.webp)` }} />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A0D12] via-[#0A0D12]/80 to-transparent" />
        <div className="relative z-10 p-5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 rounded-full bg-[#60A5FA] animate-pulse" />
              <span className="text-[11px] text-[#60A5FA] font-mono uppercase tracking-widest">Live Forex Scanner · Oanda</span>
              <Badge variant="outline" className="text-[10px] border-[#F5A623]/40 text-[#F5A623] bg-[#F5A623]/5 ml-1">
                <Shield className="w-2.5 h-2.5 mr-1" />Min {minRR}:1 RR
              </Badge>
            </div>
            <h2 className="text-xl font-bold text-white">Forex Pairs Screener</h2>
            <p className="text-slate-400 text-sm mt-0.5">Price action strategy · Pin Bar, Engulfing, Inside Bar, Break &amp; Retest · Real Oanda data</p>
          </div>
          <div className="flex items-center gap-2">
            {data?.cacheAgeMs !== undefined && data.cacheAgeMs !== Infinity && (
              <span className={cn(
                "text-[10px] font-mono px-2 py-0.5 rounded-full border hidden sm:inline-flex items-center gap-1",
                data.cacheWarm
                  ? "text-[#00FF88] border-[#00FF88]/30 bg-[#00FF88]/5"
                  : "text-[#F5A623] border-[#F5A623]/30 bg-[#F5A623]/5"
              )}>
                <span className={cn("w-1.5 h-1.5 rounded-full", data.cacheWarm ? "bg-[#00FF88]" : "bg-[#F5A623] animate-pulse")} />
                {data.cacheWarm ? "Live data" : `Data ${Math.round(data.cacheAgeMs / 60000)}m old`}
              </span>
            )}
            {data?.scannedAt && <span className="text-xs text-slate-500 font-mono hidden sm:block">Last scan: {new Date(data.scannedAt).toLocaleTimeString()}</span>}
            <SymbolManager assetClass="forex" onSymbolsChanged={() => refetch()} />
            <Button onClick={() => refetch()} disabled={isFetching} variant="outline" size="sm" className="bg-[#60A5FA]/10 border border-[#60A5FA]/30 text-[#60A5FA] hover:bg-[#60A5FA]/20">
              <RefreshCw className={cn("w-4 h-4 mr-2", isFetching && "animate-spin")} />
              {isFetching ? "Scanning..." : "Rescan"}
            </Button>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
        {[
          { label: "Total", value: setups.length, color: "text-white" },
          { label: "Premium", value: premiumCount, color: "text-[#F5A623]" },
          { label: "Strong", value: strongCount, color: "text-[#60A5FA]" },
          { label: "Avg RR", value: isLoading ? "—" : `${avgRR}:1`, color: "text-[#00FF88]" },
          { label: "Long", value: longCount, color: "text-[#00FF88]" },
          { label: "Short", value: shortCount, color: "text-[#FF3B5C]" },
        ].map((stat) => (
          <div key={stat.label} className="bg-[#0D1117] border border-slate-800 rounded-lg p-3 text-center">
            <div className={cn("text-xl font-bold font-mono", stat.color)}>{isLoading ? "—" : stat.value}</div>
            <div className="text-[10px] text-slate-500 uppercase font-mono mt-0.5">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[160px] max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search pair or pattern..."
            className="w-full pl-8 h-8 text-xs bg-[#0D1117] border border-slate-800 rounded-lg text-white placeholder:text-slate-600 focus:outline-none focus:border-slate-600 pr-3" />
        </div>
        <div className="flex items-center gap-1 bg-[#0D1117] border border-slate-800 rounded-lg p-1">
          {(["15m", "30m", "1H", "4H", "Daily"] as Timeframe[]).map((tf) => (
            <button key={tf} onClick={() => setTimeframe(tf)} className={cn("px-2.5 py-1 rounded-md text-xs font-mono transition-all", timeframe === tf ? "bg-slate-700 text-white" : "text-slate-500 hover:text-slate-300")}>{tf}</button>
          ))}
        </div>
        <div className="flex items-center gap-2 bg-[#0D1117] border border-[#F5A623]/20 rounded-lg px-3 py-1.5">
          <Shield className="w-3.5 h-3.5 text-[#F5A623]" />
          <span className="text-[10px] text-slate-500 font-mono">Min RR:</span>
          {[2, 2.5, 3, 3.5, 4].map((rr) => (
            <button key={rr} onClick={() => setMinRR(rr)} className={cn("px-2 py-0.5 rounded text-xs font-mono transition-all", minRR === rr ? "bg-[#F5A623]/20 text-[#F5A623]" : "text-slate-500 hover:text-slate-300")}>{rr}:1</button>
          ))}
        </div>
        <div className="flex items-center gap-1.5">
          {(["ALL", "LONG", "SHORT"] as Direction[]).map((d) => (
            <button key={d} onClick={() => setFilterDir(d)} className={cn("px-3 py-1 rounded-md text-xs font-medium border transition-all",
              filterDir === d ? d === "LONG" ? "bg-[#00FF88]/15 border-[#00FF88]/40 text-[#00FF88]" : d === "SHORT" ? "bg-[#FF3B5C]/15 border-[#FF3B5C]/40 text-[#FF3B5C]" : "bg-slate-700 border-slate-600 text-white"
              : "bg-transparent border-slate-800 text-slate-500 hover:border-slate-700 hover:text-slate-400")}>{d}</button>
          ))}
        </div>
        <div className="flex items-center gap-1.5">
          <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500" />
          {(["ALL", "PREMIUM", "STRONG", "DEVELOPING"] as QualityFilter[]).map((q) => (
            <button key={q} onClick={() => setFilterQuality(q)} className={cn("px-3 py-1 rounded-md text-xs font-medium border transition-all",
              filterQuality === q ? q === "PREMIUM" ? "bg-[#F5A623]/15 border-[#F5A623]/40 text-[#F5A623]" : q === "STRONG" ? "bg-[#60A5FA]/15 border-[#60A5FA]/40 text-[#60A5FA]" : "bg-slate-700 border-slate-600 text-white"
              : "bg-transparent border-slate-800 text-slate-500 hover:border-slate-700 hover:text-slate-400")}>
              {q === "ALL" ? "ALL" : q.charAt(0) + q.slice(1).toLowerCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-full border-2 border-[#60A5FA]/20 animate-ping absolute inset-0" />
            <div className="w-16 h-16 rounded-full border-2 border-[#60A5FA]/40 flex items-center justify-center">
              <Globe className="w-6 h-6 text-[#60A5FA] animate-pulse" />
            </div>
          </div>
          <div className="text-center">
            <p className="text-[#60A5FA] font-mono text-sm">SCANNING FOREX MARKETS...</p>
            <p className="text-slate-500 text-xs mt-1">Fetching live Oanda data · Scanning for price action setups</p>
          </div>
        </div>
      ) : error ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <AlertCircle className="w-8 h-8 text-[#FF3B5C]" />
          <div className="text-slate-400 text-sm">Error loading Oanda data</div>
          <div className="text-slate-600 text-xs font-mono max-w-sm text-center">{error.message}</div>
          <Button onClick={() => refetch()} variant="outline" size="sm" className="border-slate-700 text-slate-400 mt-2">Retry</Button>
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <SlidersHorizontal className="w-8 h-8 text-slate-600" />
          <div className="text-slate-400 text-sm">No setups found</div>
          <div className="text-slate-600 text-xs text-center max-w-sm">
            {setups.length === 0 ? `No price action setups detected on ${timeframe} with min ${minRR}:1 RR. Try a different timeframe or lower the RR minimum.` : "No setups match your filters."}
          </div>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Showing <span className="text-white font-mono">{filtered.length}</span> setups · live Oanda data · min {minRR}:1 RR</span>
            {autoPush && <Badge variant="outline" className="text-[10px] border-[#F5A623]/30 text-[#F5A623] bg-[#F5A623]/5"><Zap className="w-2.5 h-2.5 mr-1" />Auto-push ON</Badge>}
          </div>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-3 pb-4">
            {filtered.map((setup) => (
              <SetupCard
                key={setup.id}
                setup={setup as unknown as ScreenerSetup}
                onPush={() => onPushToJournal(setup as unknown as ScreenerSetup)}
                isPushed={pushedIds.has(setup.id)}
                onViewChart={() => setChartSetup(setup as unknown as ScreenerSetup)}
                onSetAlert={() => handleSetAlert(setup as unknown as ScreenerSetup)}
                onCalculate={() => handleCalculate(setup as unknown as ScreenerSetup)}
                onAddToWatchlist={() => handleAddToWatchlist(setup as unknown as ScreenerSetup)}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

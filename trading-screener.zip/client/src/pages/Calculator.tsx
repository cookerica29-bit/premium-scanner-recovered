import { useState, useEffect, useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Calculator,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Info,
  ChevronDown,
  ChevronUp,
  BarChart2,
  AlertTriangle,
  Target,
  Shield,
  Layers,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";
import TradingViewModal from "@/components/TradingViewModal";
import { useCalculator } from "@/contexts/CalculatorContext";

// ─── Types ────────────────────────────────────────────────────────────────────

type AssetClass = "FOREX" | "STOCK" | "FUTURES";
type CalcSetup = {
  symbol: string;
  displaySymbol: string;
  assetClass: AssetClass;
  direction: "LONG" | "SHORT" | "CALL" | "PUT";
  entry: number;
  stopLoss: number;
  takeProfit: number;
  takeProfit2?: number;
  takeProfit3?: number;
  rrRatio: number;
  pattern: string;
  timeframe: string;
};

// ─── Pip Size Logic ───────────────────────────────────────────────────────────

/**
 * Returns the pip size and standard pip value (USD) for a given forex symbol.
 * JPY pairs: pip = 0.01, pip value ≈ $9.09 per standard lot
 * XAU/USD (Gold): pip = 0.01, pip value = $1 per standard lot (100 oz)
 * XAG/USD (Silver): pip = 0.001, pip value = $0.50 per standard lot
 * Standard pairs: pip = 0.0001, pip value = $10 per standard lot
 */
function getPipConfig(symbol: string): { pipSize: number; pipValueUSD: number; decimals: number } {
  const s = symbol.toUpperCase().replace("/", "_").replace("-", "_");
  if (s.includes("JPY")) {
    return { pipSize: 0.01, pipValueUSD: 9.09, decimals: 3 };
  }
  if (s.includes("XAU") || s.includes("GOLD")) {
    return { pipSize: 0.01, pipValueUSD: 1.0, decimals: 2 };
  }
  if (s.includes("XAG") || s.includes("SILVER")) {
    return { pipSize: 0.001, pipValueUSD: 0.5, decimals: 3 };
  }
  if (s.includes("XPD") || s.includes("XPT")) {
    return { pipSize: 0.01, pipValueUSD: 1.0, decimals: 2 };
  }
  // Standard 4-decimal pair
  return { pipSize: 0.0001, pipValueUSD: 10, decimals: 5 };
}

function calcForexLotSize(
  accountSize: number,
  riskPct: number,
  entry: number,
  stopLoss: number,
  symbol: string,
  customPipValue?: number
): {
  dollarRisk: number;
  pips: number;
  pipSize: number;
  pipValueUSD: number;
  standardLots: number;
  miniLots: number;
  microLots: number;
  nanolots: number;
  potentialProfit1R: number;
} {
  const dollarRisk = (accountSize * riskPct) / 100;
  const { pipSize, pipValueUSD, decimals: _d } = getPipConfig(symbol);
  const pipVal = customPipValue ?? pipValueUSD;
  const priceDiff = Math.abs(entry - stopLoss);
  const pips = priceDiff / pipSize;
  const standardLots = pips > 0 && pipVal > 0 ? dollarRisk / (pips * pipVal) : 0;

  return {
    dollarRisk: Math.round(dollarRisk * 100) / 100,
    pips: Math.round(pips * 10) / 10,
    pipSize,
    pipValueUSD: pipVal,
    standardLots: Math.round(standardLots * 10000) / 10000,
    miniLots: Math.round(standardLots * 10 * 1000) / 1000,
    microLots: Math.round(standardLots * 100 * 100) / 100,
    nanolots: Math.round(standardLots * 1000 * 10) / 10,
    potentialProfit1R: Math.round(dollarRisk * 100) / 100,
  };
}

function calcStockShares(
  accountSize: number,
  riskPct: number,
  entry: number,
  stopLoss: number
): { dollarRisk: number; riskPerShare: number; shares: number; positionValue: number; marginRequired: number } {
  const dollarRisk = (accountSize * riskPct) / 100;
  const riskPerShare = Math.abs(entry - stopLoss);
  const shares = riskPerShare > 0 ? Math.floor(dollarRisk / riskPerShare) : 0;
  const positionValue = shares * entry;
  return {
    dollarRisk: Math.round(dollarRisk * 100) / 100,
    riskPerShare: Math.round(riskPerShare * 100) / 100,
    shares,
    positionValue: Math.round(positionValue * 100) / 100,
    marginRequired: Math.round(positionValue * 0.25 * 100) / 100, // 4:1 margin estimate
  };
}

function isForexSymbol(symbol: string): boolean {
  return symbol.includes("_") || symbol.includes("/") || (symbol.length === 6 && !/\d/.test(symbol));
}

// ─── Manual Setup Input ───────────────────────────────────────────────────────

function ManualSetupInput({
  setup,
  onChange,
}: {
  setup: Partial<CalcSetup>;
  onChange: (s: Partial<CalcSetup>) => void;
}) {
  const isForex = setup.assetClass === "FOREX" || isForexSymbol(setup.symbol || "");
  const { decimals } = isForex ? getPipConfig(setup.symbol || "") : { decimals: 2 };

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
      <div>
        <Label className="text-xs text-slate-400 mb-1 block">Symbol</Label>
        <Input
          value={setup.displaySymbol ?? ""}
          onChange={(e) => onChange({ ...setup, displaySymbol: e.target.value, symbol: e.target.value })}
          placeholder="e.g. EUR/USD or AAPL"
          className="h-8 text-sm bg-[#0D1117] border-slate-700 text-white"
        />
      </div>
      <div>
        <Label className="text-xs text-slate-400 mb-1 block">Asset Class</Label>
        <div className="flex gap-1">
          {(["FOREX", "STOCK"] as AssetClass[]).map((ac) => (
            <button
              key={ac}
              onClick={() => onChange({ ...setup, assetClass: ac })}
              className={cn(
                "flex-1 h-8 text-xs rounded border transition-all",
                setup.assetClass === ac
                  ? "bg-[#00FF88]/10 border-[#00FF88]/30 text-[#00FF88]"
                  : "bg-slate-800/40 border-slate-700 text-slate-400 hover:text-slate-300"
              )}
            >
              {ac}
            </button>
          ))}
        </div>
      </div>
      <div>
        <Label className="text-xs text-slate-400 mb-1 block">Direction</Label>
        <div className="flex gap-1">
          {(["LONG", "SHORT"] as const).map((d) => (
            <button
              key={d}
              onClick={() => onChange({ ...setup, direction: d })}
              className={cn(
                "flex-1 h-8 text-xs rounded border transition-all",
                setup.direction === d
                  ? d === "LONG"
                    ? "bg-[#00FF88]/10 border-[#00FF88]/30 text-[#00FF88]"
                    : "bg-[#FF3B5C]/10 border-[#FF3B5C]/30 text-[#FF3B5C]"
                  : "bg-slate-800/40 border-slate-700 text-slate-400 hover:text-slate-300"
              )}
            >
              {d}
            </button>
          ))}
        </div>
      </div>
      <div>
        <Label className="text-xs text-slate-400 mb-1 block">Entry Price</Label>
        <Input
          type="number"
          step="any"
          value={setup.entry ?? ""}
          onChange={(e) => onChange({ ...setup, entry: parseFloat(e.target.value) || 0 })}
          placeholder={isForex ? "1.08500" : "0.00"}
          className="h-8 text-sm bg-[#0D1117] border-slate-700 text-white font-mono"
        />
      </div>
      <div>
        <Label className="text-xs text-slate-400 mb-1 block">Stop Loss</Label>
        <Input
          type="number"
          step="any"
          value={setup.stopLoss ?? ""}
          onChange={(e) => onChange({ ...setup, stopLoss: parseFloat(e.target.value) || 0 })}
          placeholder={isForex ? "1.08200" : "0.00"}
          className="h-8 text-sm bg-[#0D1117] border-slate-700 text-white font-mono"
        />
      </div>
      <div>
        <Label className="text-xs text-slate-400 mb-1 block">Take Profit 1</Label>
        <Input
          type="number"
          step="any"
          value={setup.takeProfit ?? ""}
          onChange={(e) => onChange({ ...setup, takeProfit: parseFloat(e.target.value) || 0 })}
          placeholder={isForex ? "1.09100" : "0.00"}
          className="h-8 text-sm bg-[#0D1117] border-slate-700 text-white font-mono"
        />
      </div>
      <div>
        <Label className="text-xs text-slate-400 mb-1 block">Take Profit 2 (optional)</Label>
        <Input
          type="number"
          step="any"
          value={setup.takeProfit2 ?? ""}
          onChange={(e) => onChange({ ...setup, takeProfit2: parseFloat(e.target.value) || undefined })}
          placeholder="0.00"
          className="h-8 text-sm bg-[#0D1117] border-slate-700 text-white font-mono"
        />
      </div>
      <div>
        <Label className="text-xs text-slate-400 mb-1 block">Take Profit 3 (optional)</Label>
        <Input
          type="number"
          step="any"
          value={setup.takeProfit3 ?? ""}
          onChange={(e) => onChange({ ...setup, takeProfit3: parseFloat(e.target.value) || undefined })}
          placeholder="0.00"
          className="h-8 text-sm bg-[#0D1117] border-slate-700 text-white font-mono"
        />
      </div>
    </div>
  );
}

// ─── Result Card ──────────────────────────────────────────────────────────────

function ResultCard({
  label,
  value,
  sub,
  color = "text-white",
  icon: Icon,
}: {
  label: string;
  value: string;
  sub?: string;
  color?: string;
  icon: React.ElementType;
}) {
  return (
    <div className="bg-[#0D1117] rounded-lg border border-slate-800 p-3">
      <div className="flex items-center gap-1.5 mb-1.5">
        <Icon className={cn("w-3.5 h-3.5", color)} />
        <span className="text-[11px] text-slate-500 uppercase tracking-wider">{label}</span>
      </div>
      <div className={cn("text-xl font-bold font-mono", color)}>{value}</div>
      {sub && <div className="text-[11px] text-slate-500 mt-0.5">{sub}</div>}
    </div>
  );
}

// ─── Lot Size Breakdown Panel ─────────────────────────────────────────────────

function LotSizeBreakdown({ symbol, accountSize, riskPct, entry, stopLoss, customPipValue, onPipValueChange }: {
  symbol: string;
  accountSize: number;
  riskPct: number;
  entry: number;
  stopLoss: number;
  customPipValue?: number;
  onPipValueChange: (v: number) => void;
}) {
  const calc = calcForexLotSize(accountSize, riskPct, entry, stopLoss, symbol, customPipValue);
  const { pipSize, pipValueUSD } = getPipConfig(symbol);
  const isJpy = symbol.toUpperCase().includes("JPY");
  const isGold = symbol.toUpperCase().includes("XAU") || symbol.toUpperCase().includes("GOLD");

  return (
    <div className="space-y-3">
      {/* Pip Info Banner */}
      <div className="flex items-center gap-3 bg-[#60A5FA]/5 border border-[#60A5FA]/20 rounded-lg px-3 py-2">
        <Info className="w-3.5 h-3.5 text-[#60A5FA] flex-shrink-0" />
        <div className="text-xs text-slate-400">
          <span className="text-[#60A5FA] font-medium">{symbol}</span>
          {" — "}Pip size: <span className="font-mono text-white">{pipSize}</span>
          {" · "}Pip value: <span className="font-mono text-white">${pipValueUSD.toFixed(2)}/std lot</span>
          {isJpy && <span className="ml-2 text-amber-400/80">(JPY pair)</span>}
          {isGold && <span className="ml-2 text-amber-400/80">(XAU/Gold)</span>}
        </div>
      </div>

      {/* Custom Pip Value Override */}
      <div className="flex items-center gap-3">
        <Label className="text-xs text-slate-400 whitespace-nowrap">Custom Pip Value (USD/std lot):</Label>
        <div className="relative w-32">
          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 text-xs">$</span>
          <Input
            type="number"
            step="0.01"
            value={customPipValue ?? pipValueUSD}
            onChange={(e) => onPipValueChange(parseFloat(e.target.value) || pipValueUSD)}
            className="pl-6 h-7 text-xs bg-[#0D1117] border-slate-700 text-white font-mono"
          />
        </div>
        <button
          onClick={() => onPipValueChange(pipValueUSD)}
          className="text-[10px] text-slate-500 hover:text-[#60A5FA] transition-colors"
        >
          Reset
        </button>
      </div>

      {/* Lot Size Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <div className="bg-[#0D1117] rounded-lg border border-[#60A5FA]/20 p-3 text-center">
          <div className="text-[10px] text-slate-500 mb-1 uppercase tracking-wider">Standard Lots</div>
          <div className="text-xl font-bold font-mono text-[#60A5FA]">{calc.standardLots.toFixed(2)}</div>
          <div className="text-[10px] text-slate-600 mt-0.5">100,000 units</div>
        </div>
        <div className="bg-[#0D1117] rounded-lg border border-[#60A5FA]/15 p-3 text-center">
          <div className="text-[10px] text-slate-500 mb-1 uppercase tracking-wider">Mini Lots</div>
          <div className="text-xl font-bold font-mono text-[#60A5FA]">{calc.miniLots.toFixed(2)}</div>
          <div className="text-[10px] text-slate-600 mt-0.5">10,000 units</div>
        </div>
        <div className="bg-[#0D1117] rounded-lg border border-[#60A5FA]/10 p-3 text-center">
          <div className="text-[10px] text-slate-500 mb-1 uppercase tracking-wider">Micro Lots</div>
          <div className="text-xl font-bold font-mono text-[#60A5FA]">{calc.microLots.toFixed(2)}</div>
          <div className="text-[10px] text-slate-600 mt-0.5">1,000 units</div>
        </div>
        <div className="bg-[#0D1117] rounded-lg border border-slate-800 p-3 text-center">
          <div className="text-[10px] text-slate-500 mb-1 uppercase tracking-wider">Pips at Risk</div>
          <div className="text-xl font-bold font-mono text-[#F5A623]">{calc.pips.toFixed(1)}</div>
          <div className="text-[10px] text-slate-600 mt-0.5">pip distance</div>
        </div>
      </div>

      {/* Dollar Risk + Profit */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-[#FF3B5C]/5 rounded-lg border border-[#FF3B5C]/20 p-3 text-center">
          <div className="text-[10px] text-[#FF3B5C]/70 mb-1 uppercase tracking-wider">Dollar Risk</div>
          <div className="text-lg font-bold font-mono text-[#FF3B5C]">${calc.dollarRisk.toFixed(2)}</div>
          <div className="text-[10px] text-slate-600 mt-0.5">{riskPct}% of account</div>
        </div>
        <div className="bg-[#00FF88]/5 rounded-lg border border-[#00FF88]/20 p-3 text-center">
          <div className="text-[10px] text-[#00FF88]/70 mb-1 uppercase tracking-wider">Potential Profit (1R)</div>
          <div className="text-lg font-bold font-mono text-[#00FF88]">${calc.potentialProfit1R.toFixed(2)}</div>
          <div className="text-[10px] text-slate-600 mt-0.5">at 1:1 RR</div>
        </div>
      </div>
    </div>
  );
}

// ─── Setup Calc Card ──────────────────────────────────────────────────────────

function SetupCalcCard({
  setup,
  accountSize,
  riskPct,
}: {
  setup: CalcSetup;
  accountSize: number;
  riskPct: number;
}) {
  const [expanded, setExpanded] = useState(false);
  const [chartOpen, setChartOpen] = useState(false);
  const [customPipValue, setCustomPipValue] = useState<number | undefined>(undefined);
  const isForex = setup.assetClass === "FOREX" || isForexSymbol(setup.symbol);
  const isLong = setup.direction === "LONG" || setup.direction === "CALL";

  const forexCalc = useMemo(() => {
    if (!isForex) return null;
    return calcForexLotSize(accountSize, riskPct, setup.entry, setup.stopLoss, setup.symbol, customPipValue);
  }, [accountSize, riskPct, setup.entry, setup.stopLoss, setup.symbol, isForex, customPipValue]);

  const stockCalc = useMemo(() => {
    if (isForex) return null;
    return calcStockShares(accountSize, riskPct, setup.entry, setup.stopLoss);
  }, [accountSize, riskPct, setup.entry, setup.stopLoss, isForex]);

  const reward = Math.abs(setup.takeProfit - setup.entry);
  const risk = Math.abs(setup.entry - setup.stopLoss);
  const rr = risk > 0 ? Math.round((reward / risk) * 10) / 10 : 0;

  const potentialProfit = isForex && forexCalc
    ? (() => {
        const { pipSize } = getPipConfig(setup.symbol);
        const tpPips = Math.abs(setup.takeProfit - setup.entry) / pipSize;
        return Math.round(forexCalc.standardLots * tpPips * (customPipValue ?? forexCalc.pipValueUSD) * 100) / 100;
      })()
    : stockCalc
    ? Math.round(stockCalc.shares * reward * 100) / 100
    : 0;

  const { decimals } = isForex ? getPipConfig(setup.symbol) : { decimals: 2 };

  return (
    <div className="bg-[#0D1117] rounded-xl border border-slate-800/80 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800/60">
        <div className="flex items-center gap-2.5">
          <div
            className={cn(
              "w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold",
              isLong ? "bg-[#00FF88]/10 text-[#00FF88]" : "bg-[#FF3B5C]/10 text-[#FF3B5C]"
            )}
          >
            {isLong ? "↑" : "↓"}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setChartOpen(true)}
                className="font-bold text-white hover:text-[#60A5FA] transition-colors text-sm"
              >
                {setup.displaySymbol}
              </button>
              <Badge
                variant="outline"
                className={cn(
                  "text-[10px] px-1.5 py-0 border",
                  isLong ? "border-[#00FF88]/30 text-[#00FF88]" : "border-[#FF3B5C]/30 text-[#FF3B5C]"
                )}
              >
                {setup.direction}
              </Badge>
              <Badge variant="outline" className="text-[10px] px-1.5 py-0 border border-slate-700 text-slate-400">
                {setup.timeframe}
              </Badge>
              <Badge variant="outline" className="text-[10px] px-1.5 py-0 border border-slate-700 text-slate-500">
                {isForex ? "FOREX" : "STOCK"}
              </Badge>
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">{setup.pattern}</div>
          </div>
        </div>
        <button
          onClick={() => setExpanded(!expanded)}
          className="text-slate-500 hover:text-slate-300 transition-colors"
        >
          {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-4 divide-x divide-slate-800/60 border-b border-slate-800/60">
        <div className="px-3 py-2 text-center">
          <div className="text-[10px] text-slate-500 mb-0.5">DOLLAR RISK</div>
          <div className="text-sm font-bold font-mono text-[#FF3B5C]">
            ${(isForex ? forexCalc?.dollarRisk : stockCalc?.dollarRisk)?.toFixed(2) ?? "—"}
          </div>
        </div>
        <div className="px-3 py-2 text-center">
          <div className="text-[10px] text-slate-500 mb-0.5">POTENTIAL PROFIT</div>
          <div className="text-sm font-bold font-mono text-[#00FF88]">${potentialProfit.toFixed(2)}</div>
        </div>
        <div className="px-3 py-2 text-center">
          <div className="text-[10px] text-slate-500 mb-0.5">R:R RATIO</div>
          <div className="text-sm font-bold font-mono text-[#F5A623]">{rr}:1</div>
        </div>
        <div className="px-3 py-2 text-center">
          <div className="text-[10px] text-slate-500 mb-0.5">{isForex ? "STD LOTS" : "SHARES"}</div>
          <div className="text-sm font-bold font-mono text-[#60A5FA]">
            {isForex
              ? (forexCalc?.standardLots.toFixed(2) ?? "—")
              : (stockCalc?.shares.toLocaleString() ?? "—")}
          </div>
        </div>
      </div>

      {/* Expanded Details */}
      {expanded && (
        <div className="p-4 space-y-4">
          {/* Price Levels */}
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-slate-900/60 rounded-lg p-2.5 text-center border border-slate-800">
              <div className="text-[10px] text-slate-500 mb-1">ENTRY</div>
              <div className="text-sm font-mono text-white">{setup.entry.toFixed(decimals)}</div>
            </div>
            <div className="bg-slate-900/60 rounded-lg p-2.5 text-center border border-[#FF3B5C]/20">
              <div className="text-[10px] text-[#FF3B5C]/70 mb-1">STOP LOSS</div>
              <div className="text-sm font-mono text-[#FF3B5C]">{setup.stopLoss.toFixed(decimals)}</div>
            </div>
            <div className="bg-slate-900/60 rounded-lg p-2.5 text-center border border-[#00FF88]/20">
              <div className="text-[10px] text-[#00FF88]/70 mb-1">TAKE PROFIT</div>
              <div className="text-sm font-mono text-[#00FF88]">{setup.takeProfit.toFixed(decimals)}</div>
            </div>
          </div>

          {/* Position Sizing */}
          {isForex && forexCalc ? (
            <div className="space-y-3">
              <div className="text-[11px] text-slate-400 font-medium uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-[#60A5FA]" />
                Forex Lot Size Breakdown
              </div>
              {/* Pip info */}
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span>Pip size: <span className="font-mono text-slate-300">{forexCalc.pipSize}</span></span>
                <span>·</span>
                <span>Pip value: <span className="font-mono text-slate-300">${forexCalc.pipValueUSD}/std lot</span></span>
                <span>·</span>
                <span>Pips at risk: <span className="font-mono text-[#F5A623]">{forexCalc.pips.toFixed(1)}</span></span>
              </div>
              {/* Custom pip value */}
              <div className="flex items-center gap-2">
                <Label className="text-[11px] text-slate-500 whitespace-nowrap">Pip value override:</Label>
                <div className="relative w-28">
                  <span className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-500 text-xs">$</span>
                  <Input
                    type="number"
                    step="0.01"
                    value={customPipValue ?? forexCalc.pipValueUSD}
                    onChange={(e) => setCustomPipValue(parseFloat(e.target.value) || forexCalc.pipValueUSD)}
                    className="pl-5 h-7 text-xs bg-[#080B10] border-slate-700 text-white font-mono"
                  />
                </div>
                {customPipValue !== undefined && (
                  <button
                    onClick={() => setCustomPipValue(undefined)}
                    className="text-[10px] text-slate-500 hover:text-[#60A5FA] transition-colors"
                  >
                    Reset
                  </button>
                )}
              </div>
              {/* Lot grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="bg-slate-900/40 rounded-lg border border-[#60A5FA]/25 p-3 text-center">
                  <div className="text-[10px] text-slate-500 mb-0.5 uppercase">Standard</div>
                  <div className="text-lg font-bold font-mono text-[#60A5FA]">{forexCalc.standardLots.toFixed(2)}</div>
                  <div className="text-[10px] text-slate-600">100k units</div>
                </div>
                <div className="bg-slate-900/40 rounded-lg border border-[#60A5FA]/15 p-3 text-center">
                  <div className="text-[10px] text-slate-500 mb-0.5 uppercase">Mini</div>
                  <div className="text-lg font-bold font-mono text-[#60A5FA]">{forexCalc.miniLots.toFixed(2)}</div>
                  <div className="text-[10px] text-slate-600">10k units</div>
                </div>
                <div className="bg-slate-900/40 rounded-lg border border-[#60A5FA]/10 p-3 text-center">
                  <div className="text-[10px] text-slate-500 mb-0.5 uppercase">Micro</div>
                  <div className="text-lg font-bold font-mono text-[#60A5FA]">{forexCalc.microLots.toFixed(2)}</div>
                  <div className="text-[10px] text-slate-600">1k units</div>
                </div>
                <div className="bg-slate-900/40 rounded-lg border border-[#60A5FA]/5 p-3 text-center">
                  <div className="text-[10px] text-slate-500 mb-0.5 uppercase">Nano</div>
                  <div className="text-lg font-bold font-mono text-[#60A5FA]">{forexCalc.nanolots.toFixed(1)}</div>
                  <div className="text-[10px] text-slate-600">100 units</div>
                </div>
              </div>
            </div>
          ) : stockCalc ? (
            <div className="space-y-3">
              <div className="text-[11px] text-slate-400 font-medium uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-[#60A5FA]" />
                Stock Position Size
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="bg-slate-900/40 rounded-lg border border-[#60A5FA]/25 p-3 text-center">
                  <div className="text-[10px] text-slate-500 mb-0.5 uppercase">Shares</div>
                  <div className="text-lg font-bold font-mono text-[#60A5FA]">{stockCalc.shares.toLocaleString()}</div>
                  <div className="text-[10px] text-slate-600">units</div>
                </div>
                <div className="bg-slate-900/40 rounded-lg border border-[#60A5FA]/15 p-3 text-center">
                  <div className="text-[10px] text-slate-500 mb-0.5 uppercase">Position Value</div>
                  <div className="text-lg font-bold font-mono text-[#60A5FA]">${stockCalc.positionValue.toLocaleString()}</div>
                  <div className="text-[10px] text-slate-600">total cost</div>
                </div>
                <div className="bg-slate-900/40 rounded-lg border border-[#F5A623]/15 p-3 text-center">
                  <div className="text-[10px] text-slate-500 mb-0.5 uppercase">Risk/Share</div>
                  <div className="text-lg font-bold font-mono text-[#F5A623]">${stockCalc.riskPerShare.toFixed(2)}</div>
                  <div className="text-[10px] text-slate-600">per share</div>
                </div>
                <div className="bg-slate-900/40 rounded-lg border border-slate-800 p-3 text-center">
                  <div className="text-[10px] text-slate-500 mb-0.5 uppercase">Margin (25%)</div>
                  <div className="text-lg font-bold font-mono text-slate-400">${stockCalc.marginRequired.toLocaleString()}</div>
                  <div className="text-[10px] text-slate-600">est. required</div>
                </div>
              </div>
            </div>
          ) : null}

          {/* TP2 / TP3 if available */}
          {(setup.takeProfit2 || setup.takeProfit3) && (
            <div className="grid grid-cols-2 gap-2">
              {setup.takeProfit2 && (
                <div className="bg-slate-900/40 rounded-lg border border-[#00FF88]/10 p-2.5 text-center">
                  <div className="text-[10px] text-slate-500 mb-0.5">TP2</div>
                  <div className="text-sm font-mono text-[#00FF88]/80">{setup.takeProfit2.toFixed(decimals)}</div>
                  <div className="text-[10px] text-slate-600 mt-0.5">
                    {risk > 0 ? `${(Math.round(Math.abs(setup.takeProfit2 - setup.entry) / risk * 10) / 10)}R` : "—"}
                  </div>
                </div>
              )}
              {setup.takeProfit3 && (
                <div className="bg-slate-900/40 rounded-lg border border-[#00FF88]/10 p-2.5 text-center">
                  <div className="text-[10px] text-slate-500 mb-0.5">TP3</div>
                  <div className="text-sm font-mono text-[#00FF88]/80">{setup.takeProfit3.toFixed(decimals)}</div>
                  <div className="text-[10px] text-slate-600 mt-0.5">
                    {risk > 0 ? `${(Math.round(Math.abs(setup.takeProfit3 - setup.entry) / risk * 10) / 10)}R` : "—"}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      <TradingViewModal
        isOpen={chartOpen}
        symbol={setup.symbol}
        displaySymbol={setup.displaySymbol}
        assetClass={setup.assetClass === "FUTURES" ? "STOCK" : setup.assetClass}
        timeframe={setup.timeframe}
        onClose={() => setChartOpen(false)}
      />
    </div>
  );
}

// ─── Main Calculator Page ─────────────────────────────────────────────────────

export default function CalculatorPage() {
  const [accountSize, setAccountSize] = useState(10000);
  const [riskPct, setRiskPct] = useState(1);
  const [manualSetup, setManualSetup] = useState<Partial<CalcSetup>>({
    assetClass: "FOREX",
    direction: "LONG",
  });
  const [savedSetups, setSavedSetups] = useState<CalcSetup[]>([]);
  const [showManual, setShowManual] = useState(false);
  const [quickSymbol, setQuickSymbol] = useState("EUR_USD");
  const [quickEntry, setQuickEntry] = useState<number>(0);
  const [quickSL, setQuickSL] = useState<number>(0);
  const [quickPipValue, setQuickPipValue] = useState<number | undefined>(undefined);
  const [showQuickCalc, setShowQuickCalc] = useState(true);

  // Consume any setups pushed from screener cards
  const { pendingSetups, consumeSetups } = useCalculator();
  useEffect(() => {
    if (pendingSetups.length === 0) return;
    const incoming = consumeSetups();
    if (incoming.length === 0) return;
    setSavedSetups((prev) => {
      const existingKeys = new Set(prev.map((s) => `${s.symbol}-${s.timeframe}`));
      const fresh = incoming.filter((s) => !existingKeys.has(`${s.symbol}-${s.timeframe}`));
      return [...fresh, ...prev];
    });
  }, [pendingSetups]);

  const dollarRisk = (accountSize * riskPct) / 100;
  const maxLoss3Trades = dollarRisk * 3;
  const accountPct3 = riskPct * 3;

  const canAddManual =
    manualSetup.displaySymbol &&
    manualSetup.entry &&
    manualSetup.stopLoss &&
    manualSetup.takeProfit &&
    manualSetup.entry !== manualSetup.stopLoss;

  const handleAddManual = () => {
    if (!canAddManual) return;
    const setup: CalcSetup = {
      symbol: manualSetup.symbol || manualSetup.displaySymbol || "",
      displaySymbol: manualSetup.displaySymbol || "",
      assetClass: manualSetup.assetClass || "FOREX",
      direction: manualSetup.direction || "LONG",
      entry: manualSetup.entry!,
      stopLoss: manualSetup.stopLoss!,
      takeProfit: manualSetup.takeProfit!,
      takeProfit2: manualSetup.takeProfit2,
      takeProfit3: manualSetup.takeProfit3,
      rrRatio:
        Math.abs(manualSetup.takeProfit! - manualSetup.entry!) /
        Math.abs(manualSetup.entry! - manualSetup.stopLoss!),
      pattern: "Manual Entry",
      timeframe: "—",
    };
    setSavedSetups((prev) => [setup, ...prev]);
    setManualSetup({ assetClass: "FOREX", direction: "LONG" });
    setShowManual(false);
  };

  const quickCalcValid = quickEntry > 0 && quickSL > 0 && quickEntry !== quickSL;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Calculator className="w-5 h-5 text-[#F5A623]" />
            Position Size Calculator
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Lot sizes, pip values, and dollar risk — for every setup
          </p>
        </div>
      </div>

      {/* Account Settings */}
      <div className="bg-[#0D1117] rounded-xl border border-slate-800 p-4">
        <div className="text-xs text-slate-400 font-medium uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <DollarSign className="w-3.5 h-3.5 text-[#F5A623]" />
          Account Settings
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Account Size */}
          <div>
            <Label className="text-xs text-slate-400 mb-1 block">Account Size (USD)</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm">$</span>
              <Input
                type="number"
                value={accountSize}
                onChange={(e) => setAccountSize(Math.max(0, parseFloat(e.target.value) || 0))}
                className="pl-7 h-9 bg-[#080B10] border-slate-700 text-white font-mono"
              />
            </div>
          </div>

          {/* Risk % */}
          <div>
            <Label className="text-xs text-slate-400 mb-1 block">Risk Per Trade (%)</Label>
            <div className="relative">
              <Input
                type="number"
                step="0.1"
                min="0.1"
                max="10"
                value={riskPct}
                onChange={(e) => setRiskPct(Math.max(0.1, Math.min(10, parseFloat(e.target.value) || 1)))}
                className="pr-7 h-9 bg-[#080B10] border-slate-700 text-white font-mono"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm">%</span>
            </div>
            <div className="flex gap-1 mt-1.5">
              {[0.5, 1, 1.5, 2].map((v) => (
                <button
                  key={v}
                  onClick={() => setRiskPct(v)}
                  className={cn(
                    "flex-1 text-[10px] py-0.5 rounded border transition-all",
                    riskPct === v
                      ? "bg-[#F5A623]/10 border-[#F5A623]/30 text-[#F5A623]"
                      : "border-slate-700 text-slate-500 hover:text-slate-300"
                  )}
                >
                  {v}%
                </button>
              ))}
            </div>
          </div>

          {/* Dollar Risk */}
          <ResultCard
            label="Dollar Risk / Trade"
            value={`$${dollarRisk.toFixed(2)}`}
            sub={`${riskPct}% of $${accountSize.toLocaleString()}`}
            color="text-[#FF3B5C]"
            icon={AlertTriangle}
          />

          {/* Max 3-trade drawdown */}
          <ResultCard
            label="Max 3-Trade Drawdown"
            value={`$${maxLoss3Trades.toFixed(2)}`}
            sub={`${accountPct3}% of account`}
            color={accountPct3 > 6 ? "text-[#FF3B5C]" : "text-[#F5A623]"}
            icon={Shield}
          />
        </div>

        {riskPct > 2 && (
          <div className="mt-3 flex items-start gap-2 bg-[#FF3B5C]/5 border border-[#FF3B5C]/20 rounded-lg px-3 py-2">
            <AlertTriangle className="w-3.5 h-3.5 text-[#FF3B5C] mt-0.5 flex-shrink-0" />
            <p className="text-xs text-[#FF3B5C]/80">
              Risking more than 2% per trade increases drawdown risk significantly. Consider reducing to 1–2% for long-term capital preservation.
            </p>
          </div>
        )}
      </div>

      {/* Quick Forex Lot Size Calculator */}
      <div className="bg-[#0D1117] rounded-xl border border-slate-800 overflow-hidden">
        <button
          onClick={() => setShowQuickCalc(!showQuickCalc)}
          className="w-full flex items-center justify-between px-4 py-3 hover:bg-slate-800/20 transition-colors"
        >
          <div className="flex items-center gap-2 text-sm font-medium text-slate-300">
            <Zap className="w-4 h-4 text-[#60A5FA]" />
            Quick Forex Lot Size Calculator
          </div>
          {showQuickCalc ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
        </button>
        {showQuickCalc && (
          <div className="px-4 pb-4 border-t border-slate-800/60 pt-4 space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <Label className="text-xs text-slate-400 mb-1 block">Forex Pair</Label>
                <Input
                  value={quickSymbol}
                  onChange={(e) => setQuickSymbol(e.target.value)}
                  placeholder="EUR_USD or EUR/USD"
                  className="h-8 text-sm bg-[#080B10] border-slate-700 text-white font-mono"
                />
              </div>
              <div>
                <Label className="text-xs text-slate-400 mb-1 block">Entry Price</Label>
                <Input
                  type="number"
                  step="any"
                  value={quickEntry || ""}
                  onChange={(e) => setQuickEntry(parseFloat(e.target.value) || 0)}
                  placeholder="1.08500"
                  className="h-8 text-sm bg-[#080B10] border-slate-700 text-white font-mono"
                />
              </div>
              <div>
                <Label className="text-xs text-slate-400 mb-1 block">Stop Loss</Label>
                <Input
                  type="number"
                  step="any"
                  value={quickSL || ""}
                  onChange={(e) => setQuickSL(parseFloat(e.target.value) || 0)}
                  placeholder="1.08200"
                  className="h-8 text-sm bg-[#080B10] border-slate-700 text-white font-mono"
                />
              </div>
            </div>
            {quickCalcValid && (
              <LotSizeBreakdown
                symbol={quickSymbol}
                accountSize={accountSize}
                riskPct={riskPct}
                entry={quickEntry}
                stopLoss={quickSL}
                customPipValue={quickPipValue}
                onPipValueChange={setQuickPipValue}
              />
            )}
            {!quickCalcValid && (
              <div className="text-center py-4 text-slate-600 text-xs">
                Enter a pair, entry, and stop loss above to see lot sizes instantly
              </div>
            )}
          </div>
        )}
      </div>

      {/* Manual Setup Entry */}
      <div className="bg-[#0D1117] rounded-xl border border-slate-800 overflow-hidden">
        <button
          onClick={() => setShowManual(!showManual)}
          className="w-full flex items-center justify-between px-4 py-3 hover:bg-slate-800/20 transition-colors"
        >
          <div className="flex items-center gap-2 text-sm font-medium text-slate-300">
            <Calculator className="w-4 h-4 text-[#F5A623]" />
            Calculate a Full Setup (Entry / SL / TP)
          </div>
          {showManual ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
        </button>
        {showManual && (
          <div className="px-4 pb-4 border-t border-slate-800/60 pt-4 space-y-3">
            <ManualSetupInput setup={manualSetup} onChange={setManualSetup} />

            {/* Live preview */}
            {manualSetup.entry && manualSetup.stopLoss && manualSetup.entry !== manualSetup.stopLoss && (
              <div className="bg-slate-900/60 rounded-lg border border-slate-800 p-3">
                <div className="text-[11px] text-slate-500 mb-2 uppercase tracking-wider">Live Preview</div>
                {manualSetup.assetClass === "FOREX" || isForexSymbol(manualSetup.symbol || "") ? (
                  (() => {
                    const r = calcForexLotSize(accountSize, riskPct, manualSetup.entry!, manualSetup.stopLoss!, manualSetup.symbol || "EURUSD");
                    return (
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                        <div>
                          <div className="text-[10px] text-slate-500">Dollar Risk</div>
                          <div className="text-sm font-mono text-[#FF3B5C] font-bold">${r.dollarRisk.toFixed(2)}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-500">Standard Lots</div>
                          <div className="text-sm font-mono text-[#60A5FA] font-bold">{r.standardLots.toFixed(2)}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-500">Mini Lots</div>
                          <div className="text-sm font-mono text-[#60A5FA] font-bold">{r.miniLots.toFixed(2)}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-500">Pips at Risk</div>
                          <div className="text-sm font-mono text-[#F5A623] font-bold">{r.pips.toFixed(1)}</div>
                        </div>
                      </div>
                    );
                  })()
                ) : (
                  (() => {
                    const r = calcStockShares(accountSize, riskPct, manualSetup.entry!, manualSetup.stopLoss!);
                    return (
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                        <div>
                          <div className="text-[10px] text-slate-500">Dollar Risk</div>
                          <div className="text-sm font-mono text-[#FF3B5C] font-bold">${r.dollarRisk.toFixed(2)}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-500">Shares</div>
                          <div className="text-sm font-mono text-[#60A5FA] font-bold">{r.shares}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-500">Position Value</div>
                          <div className="text-sm font-mono text-[#60A5FA] font-bold">${r.positionValue.toLocaleString()}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-500">Risk/Share</div>
                          <div className="text-sm font-mono text-[#F5A623] font-bold">${r.riskPerShare.toFixed(2)}</div>
                        </div>
                      </div>
                    );
                  })()
                )}
              </div>
            )}

            <div className="flex justify-end">
              <Button
                onClick={handleAddManual}
                disabled={!canAddManual}
                size="sm"
                className="bg-[#60A5FA]/10 border border-[#60A5FA]/30 text-[#60A5FA] hover:bg-[#60A5FA]/20 text-xs h-8"
              >
                <Calculator className="w-3.5 h-3.5 mr-1.5" />
                Add to Calculator
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Saved Setups */}
      {savedSetups.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-medium text-slate-300 flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-[#60A5FA]" />
              Calculated Setups
              <Badge variant="outline" className="text-[10px] border-slate-700 text-slate-400">
                {savedSetups.length}
              </Badge>
            </h2>
            <button
              onClick={() => setSavedSetups([])}
              className="text-xs text-slate-600 hover:text-slate-400 transition-colors"
            >
              Clear all
            </button>
          </div>

          {/* Summary row */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-[#0D1117] rounded-lg border border-slate-800 p-3 text-center">
              <div className="text-[10px] text-slate-500 mb-1">TOTAL DOLLAR RISK</div>
              <div className="text-lg font-bold font-mono text-[#FF3B5C]">
                ${(savedSetups.length * dollarRisk).toFixed(2)}
              </div>
              <div className="text-[10px] text-slate-600 mt-0.5">
                {(savedSetups.length * riskPct).toFixed(1)}% of account
              </div>
            </div>
            <div className="bg-[#0D1117] rounded-lg border border-slate-800 p-3 text-center">
              <div className="text-[10px] text-slate-500 mb-1">AVG R:R RATIO</div>
              <div className="text-lg font-bold font-mono text-[#F5A623]">
                {(savedSetups.reduce((sum, s) => sum + s.rrRatio, 0) / savedSetups.length).toFixed(1)}:1
              </div>
            </div>
            <div className="bg-[#0D1117] rounded-lg border border-slate-800 p-3 text-center">
              <div className="text-[10px] text-slate-500 mb-1">SETUPS LOADED</div>
              <div className="text-lg font-bold font-mono text-[#60A5FA]">{savedSetups.length}</div>
            </div>
          </div>

          {savedSetups.map((setup, i) => (
            <div key={i} className="relative">
              <SetupCalcCard setup={setup} accountSize={accountSize} riskPct={riskPct} />
              <button
                onClick={() => setSavedSetups((prev) => prev.filter((_, idx) => idx !== i))}
                className="absolute top-3 right-10 text-slate-600 hover:text-[#FF3B5C] text-xs transition-colors"
                title="Remove"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Empty state */}
      {savedSetups.length === 0 && (
        <div className="text-center py-12 bg-[#0D1117] rounded-xl border border-slate-800">
          <Calculator className="w-10 h-10 text-slate-700 mx-auto mb-3" />
          <p className="text-slate-500 text-sm font-medium">No setups calculated yet</p>
          <p className="text-slate-600 text-xs mt-1 max-w-sm mx-auto">
            Use the Quick Lot Calc above, enter a custom setup, or push setups from the screeners to auto-calculate position sizes.
          </p>
          <div className="flex items-center justify-center gap-2 mt-4">
            <Info className="w-3.5 h-3.5 text-slate-600" />
            <span className="text-[11px] text-slate-600">
              Account size and risk % apply to all calculations
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

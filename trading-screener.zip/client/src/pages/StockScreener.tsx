import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  TrendingUp, TrendingDown, RefreshCw, BookOpen,
  ChevronDown, ChevronUp, AlertCircle, Loader2,
  Search, SlidersHorizontal, Zap, Star, Activity, Filter, BarChart2, Bell,
  Calculator as CalcIcon, Eye, CheckCircle, XCircle, MinusCircle,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import TradingViewModal from "@/components/TradingViewModal";
import { useCalculator } from "@/contexts/CalculatorContext";
import SymbolManager from "@/components/SymbolManager";

type SetupType = "ALL" | "CALL" | "PUT";
type QualityFilter = "ALL" | "PREMIUM" | "STRONG" | "DEVELOPING";
type Timeframe = "15m" | "30m" | "1H" | "4H" | "Daily";
type ScanMode = "ema" | "pa";

interface PaSignal {
  signalType: string;
  direction: string;
  strength: string;
  tags: string[];
  keyLevel?: number;
  rangeHigh?: number;
  rangeLow?: number;
  trendBars?: number;
  bodyRatio?: number;
  volumeRatio?: number;
}

interface PaResult {
  id: string;
  symbol: string;
  displaySymbol: string;
  sector?: string;
  currentPrice: number;
  dominantDirection: string;
  overallStrength: string;
  atr: number;
  avgVolume: number;
  signals: PaSignal[];
  timeframe: string;
  scannedAt: string;
}

interface ScreenerSetup {
  id: string;
  symbol: string;
  displaySymbol: string;
  assetClass: "STOCK" | "FOREX";
  setupType: "CALL" | "PUT" | "LONG" | "SHORT";
  quality: "PREMIUM" | "STRONG" | "DEVELOPING";
  pattern: string;
  timeframe: string;
  currentPrice: number;
  levels: {
    entry: number;
    stopLoss: number;
    takeProfit: number;
    takeProfit2: number;
    takeProfit3: number;
  };
  rrRatio: number;
  confluences: string[];
  sector?: string;
  ema20?: number;
  ema50?: number;
  earningsDate?: string;
  scannedAt: string;
  // Final-build enhanced fields
  structureBias?: string;
  structureScore?: number;
  locationTag?: string;
  locationScore?: number;
  roomToMove?: string;
  roomScore?: number;
  timingState?: string;
  setupQuality?: string;
  finalTradeScore?: number;
  reason?: string;
  distanceToSupport?: number;
  distanceToResistance?: number;
  support20?: number;
  resistance20?: number;
  rsi14?: number;
  relVolume?: number;
  bestScore?: number;
  callScore?: number;
  putScore?: number;
}

interface StockScreenerProps {
  onPushToJournal: (setup: ScreenerSetup) => void;
  pushedIds: Set<string>;
  autoPush: boolean;
  onSwitchToWatchlist?: () => void;
}

const qualityConfig = {
  PREMIUM: { color: "text-[#F5A623]", bg: "bg-[#F5A623]/10", border: "border-[#F5A623]/30", label: "PREMIUM", glow: "shadow-[0_0_12px_rgba(245,166,35,0.15)]" },
  STRONG: { color: "text-[#60A5FA]", bg: "bg-[#60A5FA]/10", border: "border-[#60A5FA]/30", label: "STRONG", glow: "" },
  DEVELOPING: { color: "text-slate-400", bg: "bg-slate-800/40", border: "border-slate-700", label: "DEVELOPING", glow: "" },
};

const OUTCOME_CONFIG = {
  WIN:       { color: "text-[#00FF88]", activeBg: "bg-[#00FF88]/15 border-[#00FF88]/40", icon: CheckCircle,  label: "WIN" },
  LOSS:      { color: "text-[#FF3B5C]", activeBg: "bg-[#FF3B5C]/15 border-[#FF3B5C]/40", icon: XCircle,     label: "LOSS" },
  BREAKEVEN: { color: "text-[#F5A623]", activeBg: "bg-[#F5A623]/15 border-[#F5A623]/40", icon: MinusCircle, label: "BE" },
} as const;

function SetupCard({
  setup, onPush, isPushed, onViewChart, onSetAlert, onCalculate, onAddToWatchlist,
  currentOutcome, onMarkOutcome, isMarkingOutcome, isAuthenticated,
}: {
  setup: ScreenerSetup;
  onPush: () => void;
  isPushed: boolean;
  onViewChart: () => void;
  onSetAlert: () => void;
  onCalculate: () => void;
  onAddToWatchlist: () => void;
  currentOutcome: string | null;
  onMarkOutcome: (outcome: "WIN" | "LOSS" | "BREAKEVEN" | "PENDING") => void;
  isMarkingOutcome: boolean;
  isAuthenticated: boolean;
}) {
  const [expanded, setExpanded] = useState(false);
  const isCall = setup.setupType === "CALL";
  const qc = qualityConfig[setup.quality];
  const risk = Math.abs(setup.levels.entry - setup.levels.stopLoss);
  const rr2 = risk > 0 ? (Math.abs(setup.levels.takeProfit2 - setup.levels.entry) / risk).toFixed(1) : "0";
  const rr3 = risk > 0 ? (Math.abs(setup.levels.takeProfit3 - setup.levels.entry) / risk).toFixed(1) : "0";
  const fmt = (n: number) => n > 100 ? n.toFixed(2) : n.toFixed(4);

  return (
    <div className={cn("rounded-xl border bg-[#0D1117] overflow-hidden transition-all duration-200", qc.border, qc.glow)}>
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0", isCall ? "bg-[#00FF88]/10" : "bg-[#FF3B5C]/10")}>
              {isCall ? <TrendingUp className="w-4 h-4 text-[#00FF88]" /> : <TrendingDown className="w-4 h-4 text-[#FF3B5C]" />}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={onViewChart}
                  className="font-mono font-bold text-white text-base hover:text-[#60A5FA] transition-colors underline-offset-2 hover:underline"
                  title="View chart"
                >
                  {setup.symbol}
                </button>
                <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border", qc.bg, qc.border, qc.color)}>⚡ {qc.label}</Badge>
                <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border", isCall ? "border-[#00FF88]/30 text-[#00FF88] bg-[#00FF88]/5" : "border-[#FF3B5C]/30 text-[#FF3B5C] bg-[#FF3B5C]/5")}>{setup.setupType}</Badge>
                <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-slate-700 text-slate-400">{setup.timeframe}</Badge>
                {setup.earningsDate && (
                  <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-amber-500/40 text-amber-400 bg-amber-500/5" title={`Earnings report: ${setup.earningsDate}`}>
                    ⚠ EARNINGS {setup.earningsDate}
                  </Badge>
                )}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">{setup.pattern}</div>
              {setup.sector && <div className="text-[10px] text-slate-600 mt-0.5">{setup.sector}</div>}
              {/* Final-build inline badges */}
              {(setup.timingState || setup.setupQuality || setup.finalTradeScore != null) && (
                <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                  {setup.timingState && (
                    <span className={cn(
                      "text-[9px] px-1.5 py-0.5 rounded font-bold font-mono uppercase border",
                      setup.timingState === "READY" ? "bg-[#00FF88]/10 border-[#00FF88]/30 text-[#00FF88]" :
                      setup.timingState === "WATCH" ? "bg-[#60A5FA]/10 border-[#60A5FA]/30 text-[#60A5FA]" :
                      setup.timingState === "EARLY" ? "bg-[#F5A623]/10 border-[#F5A623]/30 text-[#F5A623]" :
                      "bg-[#FF3B5C]/10 border-[#FF3B5C]/30 text-[#FF3B5C]"
                    )}>{setup.timingState}</span>
                  )}
                  {setup.setupQuality && (
                    <span className={cn(
                      "text-[9px] px-1.5 py-0.5 rounded font-bold font-mono border",
                      setup.setupQuality === "A" ? "bg-[#00FF88]/10 border-[#00FF88]/30 text-[#00FF88]" :
                      setup.setupQuality === "B" ? "bg-[#60A5FA]/10 border-[#60A5FA]/30 text-[#60A5FA]" :
                      "bg-slate-800 border-slate-700 text-slate-400"
                    )}>Grade {setup.setupQuality}</span>
                  )}
                  {setup.finalTradeScore != null && (
                    <span className={cn(
                      "text-[9px] px-1.5 py-0.5 rounded font-mono border",
                      setup.finalTradeScore >= 80 ? "bg-[#00FF88]/10 border-[#00FF88]/30 text-[#00FF88]" :
                      setup.finalTradeScore >= 65 ? "bg-[#60A5FA]/10 border-[#60A5FA]/30 text-[#60A5FA]" :
                      "bg-[#F5A623]/10 border-[#F5A623]/30 text-[#F5A623]"
                    )}>Score {setup.finalTradeScore}</span>
                  )}
                </div>
              )}
            </div>
          </div>
          <div className="text-right flex-shrink-0">
            <div className={cn("text-lg font-mono font-bold", setup.rrRatio >= 3 ? "text-[#00FF88]" : setup.rrRatio >= 2 ? "text-[#60A5FA]" : "text-slate-400")}>{setup.rrRatio.toFixed(1)}:1</div>
            <div className="text-[10px] text-slate-600 font-mono">RR Ratio</div>
          </div>
        </div>

        <div className="mt-2 mb-3">
          <span className="text-[10px] text-slate-600 font-mono">Price: </span>
          <span className="text-xs font-mono text-slate-300">{fmt(setup.currentPrice)}</span>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-3">
          <div className="bg-[#080B10] rounded-lg p-2.5 border border-slate-800">
            <div className="text-[10px] text-slate-600 uppercase font-mono mb-1">Entry</div>
            <div className="font-mono font-semibold text-white text-sm">{fmt(setup.levels.entry)}</div>
          </div>
          <div className="bg-[#080B10] rounded-lg p-2.5 border border-[#FF3B5C]/20">
            <div className="text-[10px] text-[#FF3B5C]/60 uppercase font-mono mb-1">Stop Loss</div>
            <div className="font-mono font-semibold text-[#FF3B5C] text-sm">{fmt(setup.levels.stopLoss)}</div>
          </div>
          <div className="bg-[#080B10] rounded-lg p-2.5 border border-[#00FF88]/20">
            <div className="text-[10px] text-[#00FF88]/60 uppercase font-mono mb-1">TP1 (2:1)</div>
            <div className="font-mono font-semibold text-[#00FF88] text-sm">{fmt(setup.levels.takeProfit)}</div>
          </div>
        </div>

        <div className="mt-3 space-y-2">
          {/* Outcome buttons — only shown when authenticated */}
          {isAuthenticated && (
            <div className="flex items-center gap-1">
              <span className="text-[10px] text-slate-600 mr-1 font-mono">Outcome:</span>
              {(["WIN", "LOSS", "BREAKEVEN"] as const).map((o) => {
                const cfg = OUTCOME_CONFIG[o];
                const Icon = cfg.icon;
                const isActive = currentOutcome === o;
                return (
                  <button
                    key={o}
                    disabled={isMarkingOutcome}
                    onClick={() => onMarkOutcome(isActive ? "PENDING" : o)}
                    title={isActive ? `Click to clear ${o}` : `Mark as ${o}`}
                    className={cn(
                      "flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium border transition-all",
                      isActive
                        ? cfg.activeBg + " " + cfg.color
                        : "bg-transparent border-slate-800 text-slate-600 hover:border-slate-700 hover:text-slate-400"
                    )}
                  >
                    <Icon className="w-3 h-3" />
                    {cfg.label}
                  </button>
                );
              })}
            </div>
          )}

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setExpanded(!expanded)}
              className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-300 transition-colors"
            >
              {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              {expanded ? "Less" : "More details"}
            </button>
            <Button size="sm" variant="outline" onClick={onViewChart}            className="text-xs h-7 px-2 border border-[#60A5FA]/30 text-[#60A5FA] hover:bg-[#60A5FA]/10 transition-all">
              <BarChart2 className="w-3 h-3 mr-1" />
              Chart
            </Button>
            <Button size="sm" variant="outline" onClick={onCalculate}
              className="text-xs h-7 px-2 border border-[#34D399]/30 text-[#34D399] hover:bg-[#34D399]/10 transition-all">
              <CalcIcon className="w-3 h-3 mr-1" />
              Calc
            </Button>
            <Button size="sm" variant="outline" onClick={onAddToWatchlist}
              className="text-xs h-7 px-2 border border-[#60A5FA]/30 text-[#60A5FA] hover:bg-[#60A5FA]/10 transition-all">
              <Eye className="w-3 h-3 mr-1" />
              Watch
            </Button>
            <Button size="sm" variant="outline" onClick={onSetAlert}
              className="text-xs h-7 px-2 border border-[#F87171]/30 text-[#F87171] hover:bg-[#F87171]/10 transition-all">
              <Bell className="w-3 h-3 mr-1" />
              Alert
            </Button>
            <Button size="sm" variant="outline" onClick={onPush} disabled={isPushed}
              className={cn("text-xs h-7 px-2 border transition-all", isPushed ? "border-slate-700 text-slate-600 cursor-not-allowed" : "border-[#F5A623]/30 text-[#F5A623] hover:bg-[#F5A623]/10")}>
              <BookOpen className="w-3 h-3 mr-1" />
              {isPushed ? "Journaled" : "Push"}
            </Button>
          </div>
        </div>
      </div>

      {expanded && (
        <div className="border-t border-slate-800 p-4 space-y-3 bg-[#080B10]/50">
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-[#080B10] rounded-lg p-2.5 border border-[#00FF88]/10">
              <div className="text-[10px] text-[#00FF88]/50 uppercase font-mono mb-1">TP2 ({rr2}:1)</div>
              <div className="font-mono font-semibold text-[#00FF88]/80 text-sm">{fmt(setup.levels.takeProfit2)}</div>
            </div>
            <div className="bg-[#080B10] rounded-lg p-2.5 border border-[#00FF88]/10">
              <div className="text-[10px] text-[#00FF88]/50 uppercase font-mono mb-1">TP3 ({rr3}:1)</div>
              <div className="font-mono font-semibold text-[#00FF88]/80 text-sm">{fmt(setup.levels.takeProfit3)}</div>
            </div>
          </div>
          {(setup.ema20 != null || setup.ema50 != null) && (
            <div className="grid grid-cols-2 gap-2">
              {setup.ema20 != null && (
                <div className="bg-[#080B10] rounded-lg p-2.5 border border-[#60A5FA]/20">
                  <div className="text-[10px] text-[#60A5FA]/50 uppercase font-mono mb-1">20 EMA</div>
                  <div className="font-mono font-semibold text-[#60A5FA] text-sm">{fmt(setup.ema20)}</div>
                  {setup.ema20 != null && (
                    <div className="text-[10px] text-slate-600 mt-0.5 font-mono">
                      {setup.setupType === "CALL" ? `+${((setup.currentPrice - setup.ema20) / setup.ema20 * 100).toFixed(2)}% above` : `${((setup.currentPrice - setup.ema20) / setup.ema20 * 100).toFixed(2)}% below`}
                    </div>
                  )}
                </div>
              )}
              {setup.ema50 != null && (
                <div className="bg-[#080B10] rounded-lg p-2.5 border border-[#A78BFA]/20">
                  <div className="text-[10px] text-[#A78BFA]/50 uppercase font-mono mb-1">50 EMA</div>
                  <div className="font-mono font-semibold text-[#A78BFA] text-sm">{fmt(setup.ema50)}</div>
                  {setup.ema20 != null && setup.ema50 != null && (
                    <div className="text-[10px] text-slate-600 mt-0.5 font-mono">
                      {setup.ema20 > setup.ema50 ? `20 EMA +${((setup.ema20 - setup.ema50) / setup.ema50 * 100).toFixed(2)}% above` : `20 EMA ${((setup.ema20 - setup.ema50) / setup.ema50 * 100).toFixed(2)}% below`}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
          {setup.confluences.length > 0 && (
            <div>
              <div className="text-[10px] text-slate-600 uppercase font-mono mb-2">Confluences</div>
              <div className="flex flex-wrap gap-1.5">
                {setup.confluences.map((c, i) => (
                  <span
                    key={i}
                    className={`text-[10px] px-2 py-0.5 rounded-full border ${
                      c === "Volume Surge"
                        ? "bg-[#00FF88]/10 text-[#00FF88] border-[#00FF88]/30"
                        : "bg-slate-800 text-slate-400 border-slate-700"
                    }`}
                  >{c}</span>
                ))}
              </div>
            </div>
          )}
          {/* Final-build enhanced fields */}
          {(setup.structureBias || setup.timingState || setup.finalTradeScore != null) && (
            <div className="space-y-2">
              {/* Score + Quality row */}
              {(setup.finalTradeScore != null || setup.setupQuality) && (
                <div className="flex items-center gap-2 flex-wrap">
                  {setup.finalTradeScore != null && (
                    <div className="flex items-center gap-1.5 bg-[#0D1117] border border-slate-800 rounded-lg px-2.5 py-1.5">
                      <span className="text-[10px] text-slate-500 font-mono uppercase">Score</span>
                      <span className={cn(
                        "text-sm font-mono font-bold",
                        setup.finalTradeScore >= 80 ? "text-[#00FF88]" : setup.finalTradeScore >= 65 ? "text-[#60A5FA]" : "text-[#F5A623]"
                      )}>{setup.finalTradeScore}</span>
                    </div>
                  )}
                  {setup.setupQuality && (
                    <div className={cn(
                      "flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-bold font-mono",
                      setup.setupQuality === "A" ? "bg-[#00FF88]/10 border-[#00FF88]/30 text-[#00FF88]" :
                      setup.setupQuality === "B" ? "bg-[#60A5FA]/10 border-[#60A5FA]/30 text-[#60A5FA]" :
                      "bg-slate-800 border-slate-700 text-slate-400"
                    )}>Grade {setup.setupQuality}</div>
                  )}
                  {setup.timingState && (
                    <div className={cn(
                      "flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-[10px] font-bold font-mono uppercase tracking-wide",
                      setup.timingState === "READY" ? "bg-[#00FF88]/10 border-[#00FF88]/30 text-[#00FF88]" :
                      setup.timingState === "WATCH" ? "bg-[#60A5FA]/10 border-[#60A5FA]/30 text-[#60A5FA]" :
                      setup.timingState === "EARLY" ? "bg-[#F5A623]/10 border-[#F5A623]/30 text-[#F5A623]" :
                      "bg-[#FF3B5C]/10 border-[#FF3B5C]/30 text-[#FF3B5C]"
                    )}>{setup.timingState}</div>
                  )}
                </div>
              )}
              {/* Structure / Location / Room row */}
              {(setup.structureBias || setup.locationTag || setup.roomToMove) && (
                <div className="grid grid-cols-3 gap-1.5">
                  {setup.structureBias && (
                    <div className="bg-[#080B10] rounded-lg p-2 border border-slate-800">
                      <div className="text-[9px] text-slate-600 uppercase font-mono mb-0.5">Structure</div>
                      <div className={cn(
                        "text-[10px] font-semibold font-mono leading-tight",
                        setup.structureBias === "Bullish Structure" ? "text-[#00FF88]" :
                        setup.structureBias === "Bearish Structure" ? "text-[#FF3B5C]" : "text-slate-400"
                      )}>{setup.structureBias.replace(" Structure", "")}</div>
                    </div>
                  )}
                  {setup.locationTag && (
                    <div className="bg-[#080B10] rounded-lg p-2 border border-slate-800">
                      <div className="text-[9px] text-slate-600 uppercase font-mono mb-0.5">Location</div>
                      <div className={cn(
                        "text-[10px] font-semibold font-mono leading-tight",
                        setup.locationTag === "Near Support" ? "text-[#00FF88]" :
                        setup.locationTag === "Near Resistance" ? "text-[#FF3B5C]" :
                        setup.locationTag === "Mid Range" ? "text-[#60A5FA]" : "text-slate-400"
                      )}>{setup.locationTag}</div>
                    </div>
                  )}
                  {setup.roomToMove && (
                    <div className="bg-[#080B10] rounded-lg p-2 border border-slate-800">
                      <div className="text-[9px] text-slate-600 uppercase font-mono mb-0.5">Room</div>
                      <div className={cn(
                        "text-[10px] font-semibold font-mono leading-tight",
                        setup.roomToMove === "Good Room" ? "text-[#00FF88]" :
                        setup.roomToMove === "Limited Room" ? "text-[#F5A623]" :
                        setup.roomToMove === "Poor Room" ? "text-[#FF3B5C]" : "text-slate-400"
                      )}>{setup.roomToMove}</div>
                    </div>
                  )}
                </div>
              )}
              {/* S/R levels + RSI + RelVol */}
              {(setup.support20 != null || setup.resistance20 != null || setup.rsi14 != null || setup.relVolume != null) && (
                <div className="grid grid-cols-4 gap-1.5">
                  {setup.support20 != null && (
                    <div className="bg-[#080B10] rounded-lg p-2 border border-[#00FF88]/10">
                      <div className="text-[9px] text-[#00FF88]/40 uppercase font-mono mb-0.5">Support</div>
                      <div className="text-[10px] font-mono text-[#00FF88]/80">{setup.support20.toFixed(2)}</div>
                      {setup.distanceToSupport != null && <div className="text-[9px] text-slate-600 font-mono">{setup.distanceToSupport.toFixed(1)}% away</div>}
                    </div>
                  )}
                  {setup.resistance20 != null && (
                    <div className="bg-[#080B10] rounded-lg p-2 border border-[#FF3B5C]/10">
                      <div className="text-[9px] text-[#FF3B5C]/40 uppercase font-mono mb-0.5">Resist</div>
                      <div className="text-[10px] font-mono text-[#FF3B5C]/80">{setup.resistance20.toFixed(2)}</div>
                      {setup.distanceToResistance != null && <div className="text-[9px] text-slate-600 font-mono">{setup.distanceToResistance.toFixed(1)}% away</div>}
                    </div>
                  )}
                  {setup.rsi14 != null && (
                    <div className="bg-[#080B10] rounded-lg p-2 border border-slate-800">
                      <div className="text-[9px] text-slate-600 uppercase font-mono mb-0.5">RSI 14</div>
                      <div className={cn(
                        "text-[10px] font-mono font-semibold",
                        setup.rsi14 >= 70 ? "text-[#FF3B5C]" : setup.rsi14 <= 30 ? "text-[#00FF88]" : "text-slate-300"
                      )}>{setup.rsi14.toFixed(1)}</div>
                    </div>
                  )}
                  {setup.relVolume != null && (
                    <div className="bg-[#080B10] rounded-lg p-2 border border-slate-800">
                      <div className="text-[9px] text-slate-600 uppercase font-mono mb-0.5">Rel Vol</div>
                      <div className={cn(
                        "text-[10px] font-mono font-semibold",
                        setup.relVolume >= 2 ? "text-[#00FF88]" : setup.relVolume >= 1.2 ? "text-[#60A5FA]" : "text-slate-400"
                      )}>{setup.relVolume.toFixed(2)}x</div>
                    </div>
                  )}
                </div>
              )}
              {/* Reason */}
              {setup.reason && (
                <div className="bg-[#080B10] rounded-lg p-2.5 border border-slate-800">
                  <div className="text-[9px] text-slate-600 uppercase font-mono mb-1">Setup Reason</div>
                  <div className="text-[10px] text-slate-400 leading-relaxed">{setup.reason}</div>
                </div>
              )}
            </div>
          )}
          <div className="text-[10px] text-slate-700 font-mono">Scanned: {new Date(setup.scannedAt).toLocaleTimeString()} · Live data via Yahoo Finance</div>
        </div>
      )}
    </div>
  );
}

const signalTypeConfig: Record<string, { color: string; bg: string; border: string; label: string }> = {
  MOMENTUM:  { color: "text-[#F5A623]", bg: "bg-[#F5A623]/10", border: "border-[#F5A623]/30", label: "Momentum" },
  KEY_LEVEL: { color: "text-[#60A5FA]", bg: "bg-[#60A5FA]/10", border: "border-[#60A5FA]/30", label: "Key Level" },
  BREAKOUT:  { color: "text-[#A78BFA]", bg: "bg-[#A78BFA]/10", border: "border-[#A78BFA]/30", label: "Breakout" },
  TREND:     { color: "text-[#00FF88]", bg: "bg-[#00FF88]/10", border: "border-[#00FF88]/30", label: "Trend" },
};

function PaResultCard({ result, onViewChart }: { result: PaResult; onViewChart: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const isBull = result.dominantDirection === "BULLISH";
  const isBear = result.dominantDirection === "BEARISH";
  const strengthColor = result.overallStrength === "STRONG" ? "text-[#00FF88]" : result.overallStrength === "MODERATE" ? "text-[#F5A623]" : "text-slate-400";

  return (
    <div className={cn(
      "bg-[#0D1117] border rounded-xl overflow-hidden transition-all",
      isBull ? "border-[#00FF88]/20" : isBear ? "border-[#FF3B5C]/20" : "border-slate-800"
    )}>
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className={cn(
              "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0",
              isBull ? "bg-[#00FF88]/10" : isBear ? "bg-[#FF3B5C]/10" : "bg-slate-800"
            )}>
              {isBull ? <TrendingUp className="w-4 h-4 text-[#00FF88]" /> : isBear ? <TrendingDown className="w-4 h-4 text-[#FF3B5C]" /> : <Activity className="w-4 h-4 text-slate-400" />}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-white text-sm">{result.displaySymbol}</span>
                {result.sector && <span className="text-[10px] text-slate-500 font-mono">{result.sector}</span>}
              </div>
              <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                <span className={cn("text-[10px] font-bold uppercase tracking-wider", isBull ? "text-[#00FF88]" : isBear ? "text-[#FF3B5C]" : "text-slate-400")}>
                  {result.dominantDirection}
                </span>
                <span className="text-slate-700">·</span>
                <span className={cn("text-[10px] font-mono font-bold", strengthColor)}>{result.overallStrength}</span>
                <span className="text-slate-700">·</span>
                <span className="text-[10px] text-slate-500 font-mono">{result.signals.length} signal{result.signals.length !== 1 ? "s" : ""}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <span className="text-sm font-mono font-bold text-white">${result.currentPrice.toFixed(2)}</span>
            <button onClick={onViewChart} className="p-1.5 rounded-md text-slate-500 hover:text-[#60A5FA] hover:bg-[#60A5FA]/10 transition-all" title="View Chart">
              <BarChart2 className="w-3.5 h-3.5" />
            </button>
            <button onClick={() => setExpanded(!expanded)} className="p-1.5 rounded-md text-slate-500 hover:text-white hover:bg-slate-700/40 transition-all">
              {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Signal pills */}
        <div className="flex flex-wrap gap-1.5 mt-3">
          {result.signals.map((sig, i) => {
            const cfg = signalTypeConfig[sig.signalType] ?? { color: "text-slate-400", bg: "bg-slate-800", border: "border-slate-700", label: sig.signalType };
            return (
              <span key={i} className={cn("text-[10px] px-2 py-0.5 rounded-full border font-medium", cfg.color, cfg.bg, cfg.border)}>
                {cfg.label}
              </span>
            );
          })}
        </div>
      </div>

      {/* Expanded detail */}
      {expanded && (
        <div className="border-t border-slate-800 p-4 space-y-3">
          {result.signals.map((sig, i) => {
            const cfg = signalTypeConfig[sig.signalType] ?? { color: "text-slate-400", bg: "bg-slate-800", border: "border-slate-700", label: sig.signalType };
            return (
              <div key={i} className={cn("rounded-lg border p-3", cfg.bg, cfg.border)}>
                <div className="flex items-center justify-between mb-2">
                  <span className={cn("text-xs font-bold", cfg.color)}>{cfg.label}</span>
                  <div className="flex items-center gap-2">
                    <span className={cn("text-[10px] font-mono", sig.direction === "BULLISH" ? "text-[#00FF88]" : sig.direction === "BEARISH" ? "text-[#FF3B5C]" : "text-slate-400")}>{sig.direction}</span>
                    <span className={cn("text-[10px] font-mono font-bold", sig.strength === "STRONG" ? "text-[#00FF88]" : sig.strength === "MODERATE" ? "text-[#F5A623]" : "text-slate-500")}>{sig.strength}</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {sig.tags.map((tag, j) => (
                    <span key={j} className="text-[10px] px-1.5 py-0.5 rounded bg-black/30 text-slate-400 border border-slate-700/50">{tag}</span>
                  ))}
                </div>
                {sig.keyLevel !== undefined && (
                  <div className="mt-2 text-[10px] text-slate-400 font-mono">Key Level: <span className="text-white">${sig.keyLevel.toFixed(2)}</span></div>
                )}
                {sig.rangeHigh !== undefined && sig.rangeLow !== undefined && (
                  <div className="mt-2 text-[10px] text-slate-400 font-mono">Range: <span className="text-white">${sig.rangeLow.toFixed(2)} – ${sig.rangeHigh.toFixed(2)}</span></div>
                )}
                {sig.volumeRatio !== undefined && (
                  <div className="mt-1 text-[10px] text-slate-400 font-mono">Volume: <span className="text-white">{sig.volumeRatio.toFixed(2)}×</span> avg</div>
                )}
              </div>
            );
          })}
          <div className="grid grid-cols-2 gap-2 mt-1">
            <div className="bg-slate-800/40 rounded-lg p-2 text-center">
              <div className="text-[10px] text-slate-500 mb-0.5">ATR</div>
              <div className="text-xs font-mono text-white">${result.atr.toFixed(2)}</div>
            </div>
            <div className="bg-slate-800/40 rounded-lg p-2 text-center">
              <div className="text-[10px] text-slate-500 mb-0.5">Timeframe</div>
              <div className="text-xs font-mono text-white">{result.timeframe}</div>
            </div>
          </div>
          <div className="text-[10px] text-slate-700 font-mono">Scanned: {new Date(result.scannedAt).toLocaleTimeString()} · Price action analysis</div>
        </div>
      )}
    </div>
  );
}

export default function StockScreener({ onPushToJournal, pushedIds, autoPush, onSwitchToWatchlist }: StockScreenerProps) {
  const [timeframe, setTimeframe] = useState<Timeframe>("Daily");
  const [scanMode, setScanMode] = useState<ScanMode>("ema");
  const [filterType, setFilterType] = useState<SetupType>("ALL");
  const [filterQuality, setFilterQuality] = useState<QualityFilter>("ALL");
  const [search, setSearch] = useState("");
  const [autoPushedIds, setAutoPushedIds] = useState<Set<string>>(new Set());
  const [chartSetup, setChartSetup] = useState<ScreenerSetup | null>(null);
  const { isAuthenticated } = useAuth();
  const utils = trpc.useUtils();

  // Fetch existing outcomes for all journal entries so we can show them on setup cards
  const outcomesQuery = trpc.journal.outcomes.useQuery(undefined, {
    enabled: isAuthenticated,
    staleTime: 60_000,
  });
  // The outcomes procedure returns Record<setupId, outcome> directly
  const outcomeMap: Record<string, string | null> = outcomesQuery.data ?? {};

  const markOutcomeMutation = trpc.journal.markOutcome.useMutation({
    onMutate: async (vars) => {
      // Cancel any in-flight outcomes queries
      await utils.journal.outcomes.cancel();
      // Snapshot the previous value for rollback
      const previous = utils.journal.outcomes.getData();
      // Optimistically update the cache
      utils.journal.outcomes.setData(undefined, (old) => ({
        ...(old ?? {}),
        [vars.setupId]: vars.outcome,
      }));
      return { previous };
    },
    onError: (e, _vars, ctx) => {
      // Roll back on error
      if (ctx?.previous !== undefined) {
        utils.journal.outcomes.setData(undefined, ctx.previous);
      }
      toast.error(e.message);
    },
    onSuccess: (_result, vars) => {
      const label = vars.outcome === "PENDING" ? "cleared" : vars.outcome;
      toast.success(`Outcome marked: ${label}`);
    },
    onSettled: () => {
      utils.journal.outcomes.invalidate();
      utils.journal.list.invalidate();
    },
  });

  const createAlert = trpc.alerts.create.useMutation({
    onSuccess: () => toast.success("Alert set! You'll be notified when price approaches entry."),
    onError: (e) => toast.error(e.message),
  });

  const handleSetAlert = (setup: ScreenerSetup) => {
    if (!isAuthenticated) {
      toast.error("Please log in to set alerts", {
        action: { label: "Log In", onClick: () => { window.location.assign(getLoginUrl()); } },
      });
      return;
    }
    createAlert.mutate({
      symbol: setup.symbol,
      displaySymbol: setup.displaySymbol,
      assetClass: "STOCK",
      direction: setup.setupType,
      targetPrice: setup.levels.entry,
      currentPrice: setup.currentPrice,
      proximityPct: 0.5,
      timeframe: setup.timeframe,
      pattern: setup.pattern,
    });
  };

  const { pushToCalculator } = useCalculator();

  const handleCalculate = (setup: ScreenerSetup) => {
    pushToCalculator({
      symbol: setup.symbol,
      displaySymbol: setup.displaySymbol,
      assetClass: "STOCK",
      direction: setup.setupType as "CALL" | "PUT",
      entry: setup.levels.entry,
      stopLoss: setup.levels.stopLoss,
      takeProfit: setup.levels.takeProfit,
      takeProfit2: setup.levels.takeProfit2,
      takeProfit3: setup.levels.takeProfit3,
      rrRatio: setup.rrRatio,
      pattern: setup.pattern,
      timeframe: setup.timeframe,
    });
    toast.success(`${setup.displaySymbol} sent to Calculator`, {
      description: "Switch to the Calc tab to view position sizing",
      action: { label: "Go to Calc", onClick: () => {} },
    });
  };

  const addToWatchlist = trpc.watchlist.create.useMutation({
    onSuccess: (result, vars) => {
      if (result.duplicate) {
        toast.warning(`${vars.displaySymbol} already on Watchlist`, {
          description: `${vars.displaySymbol} (${vars.timeframe}) is already being watched.`,
          action: { label: "View in Watch tab", onClick: () => onSwitchToWatchlist?.() },
        });
      } else {
        toast.success(`${vars.displaySymbol} added to Watchlist`, {
          description: `Entry: ${vars.keyLevel1} · SL: ${vars.keyLevel2} · TP: ${vars.keyLevel3}`,
        });
      }
    },
    onError: (e) => toast.error(e.message),
  });

  const handleAddToWatchlist = (setup: ScreenerSetup) => {
    if (!isAuthenticated) {
      toast.error("Please log in to use Watchlist", {
        action: { label: "Log In", onClick: () => { window.location.assign(getLoginUrl()); } },
      });
      return;
    }
    const bias = setup.setupType === "CALL" ? "BULLISH" : "BEARISH";
    addToWatchlist.mutate({
      symbol: setup.symbol,
      displaySymbol: setup.displaySymbol,
      assetClass: "STOCK",
      timeframe: setup.timeframe,
      bias,
      notes: `${setup.pattern} — Entry: ${setup.levels.entry} | SL: ${setup.levels.stopLoss} | TP: ${setup.levels.takeProfit}`,
      keyLevel1: String(setup.levels.entry),
      keyLevel1Label: "Entry",
      keyLevel2: String(setup.levels.stopLoss),
      keyLevel2Label: "Stop Loss",
      keyLevel3: String(setup.levels.takeProfit),
      keyLevel3Label: "Take Profit",
      tags: [setup.pattern, setup.setupType, setup.quality],
    });
  };

  // Track cache warm state in local state so we can use it in the query options
  const [emaCacheWarm, setEmaCacheWarm] = useState(false);
  const [paCacheWarm, setPaCacheWarm] = useState(false);

  // Reset warm state whenever timeframe changes so polling resumes for the new timeframe
  useEffect(() => {
    setEmaCacheWarm(false);
    setPaCacheWarm(false);
  }, [timeframe]);

  const emaQuery = trpc.screener.stocks.useQuery(
    { timeframe },
    {
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000,
      enabled: scanMode === "ema",
      // Poll every 30s while cache is warming so results appear as symbols finish loading
      refetchInterval: scanMode === "ema" && !emaCacheWarm ? 30_000 : false,
    }
  );

  const paQuery = trpc.screener.stocksPriceAction.useQuery(
    { timeframe },
    {
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000,
      enabled: scanMode === "pa",
      refetchInterval: scanMode === "pa" && !paCacheWarm ? 30_000 : false,
    }
  );

  // Sync warm state from query responses
  useEffect(() => { if (emaQuery.data?.cacheWarm) setEmaCacheWarm(true); }, [emaQuery.data]);
  useEffect(() => { if (paQuery.data?.cacheWarm) setPaCacheWarm(true); }, [paQuery.data]);

  const data = scanMode === "ema" ? emaQuery.data : undefined;
  const paData = scanMode === "pa" ? paQuery.data : undefined;
  const isLoading = scanMode === "ema" ? emaQuery.isLoading : paQuery.isLoading;
  const isFetching = scanMode === "ema" ? emaQuery.isFetching : paQuery.isFetching;
  const error = scanMode === "ema" ? emaQuery.error : paQuery.error;
  const refetch = scanMode === "ema" ? emaQuery.refetch : paQuery.refetch;

  const setups = data?.setups ?? [];
  const paResults = paData?.results ?? [];
  const cachedSymbols = data?.cachedSymbols ?? paData?.cachedSymbols ?? 0;
  const totalSymbols = data?.totalSymbols ?? paData?.totalSymbols ?? 0;
  const cacheWarm = data?.cacheWarm ?? paData?.cacheWarm ?? false;

  useEffect(() => {
    if (!autoPush || !data?.setups) return;
    const premiumSetups = data.setups.filter((s) => s.quality === "PREMIUM");
    for (const setup of premiumSetups) {
      if (!pushedIds.has(setup.id) && !autoPushedIds.has(setup.id)) {
        onPushToJournal(setup as unknown as ScreenerSetup);
        setAutoPushedIds((prev) => new Set(Array.from(prev).concat(setup.id)));
        toast.success(`Auto-pushed ${setup.symbol} ${setup.setupType} to journal`);
      }
    }
  }, [autoPush, data]);

  useEffect(() => {
    if (data && !isLoading && scanMode === "ema") {
      toast.success(`Scan complete — ${data.setups.length} setups found`, {
        description: `${data.setups.filter(s => s.quality === "PREMIUM").length} premium, ${data.setups.filter(s => s.quality === "STRONG").length} strong`,
      });
    }
  }, [data]);

  useEffect(() => {
    if (paData && !isLoading && scanMode === "pa") {
      const strongCount = paData.results.filter(r => r.overallStrength === "STRONG").length;
      toast.success(`Price action scan — ${paData.results.length} signals found`, {
        description: `${strongCount} strong, ${paData.results.length - strongCount} moderate/weak`,
      });
    }
  }, [paData]);

  const filtered = setups.filter((s) => {
    if (filterType !== "ALL" && s.setupType !== filterType) return false;
    if (filterQuality !== "ALL" && s.quality !== filterQuality) return false;
    if (search && !s.symbol.toLowerCase().includes(search.toLowerCase()) && !s.pattern.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const premiumCount = setups.filter((s) => s.quality === "PREMIUM").length;
  const strongCount = setups.filter((s) => s.quality === "STRONG").length;
  const callCount = setups.filter((s) => s.setupType === "CALL").length;
  const putCount = setups.filter((s) => s.setupType === "PUT").length;

  return (
    <div className="flex flex-col h-full space-y-4">
      {/* TradingView Chart Modal */}
      {chartSetup && (
        <TradingViewModal
          symbol={chartSetup.symbol}
          displaySymbol={chartSetup.displaySymbol}
          timeframe={chartSetup.timeframe}
          assetClass={chartSetup.assetClass}
          isOpen={true}
          onClose={() => setChartSetup(null)}
        />
      )}

      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-xl border border-slate-800" style={{ minHeight: 110 }}>
        <div className="absolute inset-0 bg-cover bg-center opacity-20" style={{ backgroundImage: `url(https://d2xsxph8kpxj0f.cloudfront.net/310519663485819244/6HDX6MZMMiuXiLTEXJkkHb/trading-stocks-bg-muuVeeQMaZVoY2PcLNCCWF.webp)` }} />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A0D12] via-[#0A0D12]/80 to-transparent" />
        <div className="relative z-10 p-5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 rounded-full bg-[#00FF88] animate-pulse" />
              <span className="text-[11px] text-[#00FF88] font-mono uppercase tracking-widest">Live Stock Scanner</span>
            </div>
            <h2 className="text-xl font-bold text-white">Stock Options Screener</h2>
            <p className="text-slate-400 text-sm mt-0.5">
            {scanMode === "ema" ? "EMA Pullback + Momentum · 20/50 EMA trend filter · Real market data" : "Price Action · Momentum · Key Levels · Breakouts · Trend · Real market data"}
          </p>
          </div>
          <div className="flex items-center gap-2">
            {scanMode === "ema" && data && (
              <span className="text-xs font-mono hidden sm:flex items-center gap-1.5">
                {data.cacheWarm ? (
                  <>
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00FF88] inline-block" />
                    <span className="text-[#00FF88]/70">
                      {data.cacheAgeMs < 60000
                        ? "Live data"
                        : `Data ${Math.round(data.cacheAgeMs / 60000)}m old`}
                    </span>
                  </>
                ) : (
                  <>
                    <span className="w-1.5 h-1.5 rounded-full bg-[#F5A623] animate-pulse inline-block" />
                    <span className="text-[#F5A623]/70">Warming cache…</span>
                  </>
                )}
              </span>
            )}
            {/* Scan mode toggle */}
            <div className="flex items-center bg-[#0D1117] border border-slate-700 rounded-lg p-0.5">
              <button
                onClick={() => setScanMode("ema")}
                className={cn("px-3 py-1.5 rounded-md text-xs font-medium transition-all",
                  scanMode === "ema" ? "bg-[#00FF88]/15 text-[#00FF88] border border-[#00FF88]/30" : "text-slate-500 hover:text-slate-300"
                )}
              >
                EMA Pullback
              </button>
              <button
                onClick={() => setScanMode("pa")}
                className={cn("px-3 py-1.5 rounded-md text-xs font-medium transition-all",
                  scanMode === "pa" ? "bg-[#60A5FA]/15 text-[#60A5FA] border border-[#60A5FA]/30" : "text-slate-500 hover:text-slate-300"
                )}
              >
                Price Action
              </button>
            </div>
            <SymbolManager assetClass="stock" onSymbolsChanged={() => refetch()} />
            <Button onClick={() => refetch()} disabled={isFetching} variant="outline" size="sm" className="bg-[#00FF88]/10 border border-[#00FF88]/30 text-[#00FF88] hover:bg-[#00FF88]/20">
              <RefreshCw className={cn("w-4 h-4 mr-2", isFetching && "animate-spin")} />
              {isFetching ? "Scanning..." : "Rescan"}
            </Button>
          </div>
        </div>
      </div>

      {/* Stats */}
      {scanMode === "ema" ? (
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {[
            { label: "Total", value: setups.length, color: "text-white", icon: null },
            { label: "Premium", value: premiumCount, color: "text-[#F5A623]", icon: <Zap className="w-3 h-3" /> },
            { label: "Strong", value: strongCount, color: "text-[#60A5FA]", icon: <Star className="w-3 h-3" /> },
            { label: "Developing", value: setups.length - premiumCount - strongCount, color: "text-slate-400", icon: <Activity className="w-3 h-3" /> },
            { label: "Calls", value: callCount, color: "text-[#00FF88]", icon: <TrendingUp className="w-3 h-3" /> },
            { label: "Puts", value: putCount, color: "text-[#FF3B5C]", icon: <TrendingDown className="w-3 h-3" /> },
          ].map((stat) => (
            <div key={stat.label} className="bg-[#0D1117] border border-slate-800 rounded-lg p-3 text-center">
              <div className={cn("text-xl font-bold font-mono", stat.color)}>{isLoading ? "—" : stat.value}</div>
              <div className="text-[10px] text-slate-500 flex items-center justify-center gap-1 mt-0.5">{stat.icon}{stat.label}</div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
          {[
            { label: "Total", value: paResults.length, color: "text-white" },
            { label: "Strong", value: paResults.filter(r => r.overallStrength === "STRONG").length, color: "text-[#00FF88]" },
            { label: "Bullish", value: paResults.filter(r => r.dominantDirection === "BULLISH").length, color: "text-[#00FF88]" },
            { label: "Bearish", value: paResults.filter(r => r.dominantDirection === "BEARISH").length, color: "text-[#FF3B5C]" },
          ].map((stat) => (
            <div key={stat.label} className="bg-[#0D1117] border border-slate-800 rounded-lg p-3 text-center">
              <div className={cn("text-xl font-bold font-mono", stat.color)}>{isLoading ? "—" : stat.value}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">{stat.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[180px] max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search symbol..."
            className="w-full pl-8 h-8 text-xs bg-[#0D1117] border border-slate-800 rounded-lg text-white placeholder:text-slate-600 focus:outline-none focus:border-slate-600 pr-3" />
        </div>
        <div className="flex items-center gap-1 bg-[#0D1117] border border-slate-800 rounded-lg p-1">
          {(["15m", "30m", "1H", "4H", "Daily"] as Timeframe[]).map((tf) => (
            <button key={tf} onClick={() => setTimeframe(tf)} className={cn("px-2.5 py-1 rounded-md text-xs font-mono transition-all", timeframe === tf ? "bg-slate-700 text-white" : "text-slate-500 hover:text-slate-300")}>{tf}</button>
          ))}
        </div>
        {scanMode === "ema" && (
          <>
            <div className="flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-slate-500" />
              {(["ALL", "CALL", "PUT"] as SetupType[]).map((f) => (
                <button key={f} onClick={() => setFilterType(f)} className={cn("px-3 py-1 rounded-md text-xs font-medium border transition-all",
                  filterType === f ? f === "CALL" ? "bg-[#00FF88]/15 border-[#00FF88]/40 text-[#00FF88]" : f === "PUT" ? "bg-[#FF3B5C]/15 border-[#FF3B5C]/40 text-[#FF3B5C]" : "bg-slate-700 border-slate-600 text-white"
                  : "bg-transparent border-slate-800 text-slate-500 hover:border-slate-700 hover:text-slate-400")}>{f}</button>
              ))}
            </div>
            <div className="flex items-center gap-1.5">
              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500" />
              {(["ALL", "PREMIUM", "STRONG", "DEVELOPING"] as QualityFilter[]).map((q) => (
                <button key={q} onClick={() => setFilterQuality(q)} className={cn("px-3 py-1 rounded-md text-xs font-medium border transition-all",
                  filterQuality === q ? q === "PREMIUM" ? "bg-[#F5A623]/15 border-[#F5A623]/40 text-[#F5A623]" : q === "STRONG" ? "bg-[#60A5FA]/15 border-[#60A5FA]/40 text-[#60A5FA]" : "bg-slate-700 border-slate-600 text-white"
                  : "bg-transparent border-slate-800 text-slate-500 hover:border-slate-700 hover:text-slate-400")}>                  {q === "ALL" ? "ALL" : q.charAt(0) + q.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Results */}
      {scanMode === "pa" && !isLoading && !error && (
        <>
          {paResults.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 gap-3">
              <Activity className="w-8 h-8 text-slate-600" />
              <div className="text-slate-400 text-sm">No price action signals detected</div>
              <div className="text-slate-600 text-xs text-center max-w-sm">Try a shorter timeframe (4H or 1H) for more signals, or rescan.</div>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500">Showing <span className="text-white font-mono">{paResults.filter(r => !search || r.symbol.toLowerCase().includes(search.toLowerCase())).length}</span> signals · raw price action</span>
              </div>
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-3 pb-4">
                {paResults
                  .filter(r => !search || r.symbol.toLowerCase().includes(search.toLowerCase()))
                  .map((result) => (
                    <PaResultCard
                      key={result.id}
                      result={result}
                      onViewChart={() => setChartSetup({ ...result, assetClass: "STOCK", setupType: "CALL", quality: "STRONG", pattern: "", levels: { entry: 0, stopLoss: 0, takeProfit: 0, takeProfit2: 0, takeProfit3: 0 }, rrRatio: 0, confluences: [], scannedAt: result.scannedAt } as ScreenerSetup)}
                    />
                  ))}
              </div>
            </>
          )}
        </>
      )}
      {scanMode === "pa" && isLoading && (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-full border-2 border-[#60A5FA]/20 animate-ping absolute inset-0" />
            <div className="w-16 h-16 rounded-full border-2 border-[#60A5FA]/40 flex items-center justify-center">
              <Loader2 className="w-6 h-6 text-[#60A5FA] animate-spin" />
            </div>
          </div>
          <div className="text-center">
            <p className="text-[#60A5FA] font-mono text-sm">READING PRICE ACTION...</p>
            <p className="text-slate-500 text-xs mt-1">Detecting momentum · key levels · breakouts · trends</p>
          </div>
        </div>
      )}
      {scanMode === "ema" && isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-full border-2 border-[#00FF88]/20 animate-ping absolute inset-0" />
            <div className="w-16 h-16 rounded-full border-2 border-[#00FF88]/40 flex items-center justify-center">
              <Loader2 className="w-6 h-6 text-[#00FF88] animate-spin" />
            </div>
          </div>
          <div className="text-center">
            <p className="text-[#00FF88] font-mono text-sm">SCANNING MARKETS...</p>
            <p className="text-slate-500 text-xs mt-1">Fetching live data · Detecting EMA pullback setups</p>
          </div>
        </div>
      ) : error ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <AlertCircle className="w-8 h-8 text-[#FF3B5C]" />
          <div className="text-slate-400 text-sm">Error loading market data</div>
          <div className="text-slate-600 text-xs font-mono max-w-sm text-center">{error.message}</div>
          <Button onClick={() => refetch()} variant="outline" size="sm" className="border-slate-700 text-slate-400 mt-2">Retry</Button>
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          {!cacheWarm && cachedSymbols < totalSymbols ? (
            <>
              <div className="relative">
                <div className="w-14 h-14 rounded-full border-2 border-amber-500/20 animate-ping absolute inset-0" />
                <div className="w-14 h-14 rounded-full border-2 border-amber-500/30 flex items-center justify-center">
                  <Loader2 className="w-5 h-5 text-amber-400 animate-spin" />
                </div>
              </div>
              <div className="text-amber-400 text-sm font-mono">WARMING CACHE…</div>
              <div className="text-slate-500 text-xs text-center max-w-xs">
                Loading market data for {totalSymbols} symbols via Polygon.io.<br />
                <span className="text-amber-400/70 font-mono">{cachedSymbols}/{totalSymbols}</span> symbols ready · checking every 30s
              </div>
              <div className="w-48 h-1.5 rounded-full bg-slate-800 overflow-hidden mt-1">
                <div
                  className="h-full rounded-full bg-amber-500/60 transition-all duration-500"
                  style={{ width: totalSymbols > 0 ? `${Math.round((cachedSymbols / totalSymbols) * 100)}%` : "0%" }}
                />
              </div>
              <Button onClick={() => refetch()} variant="outline" size="sm" className="border-amber-500/30 text-amber-400 mt-1">Check Now</Button>
            </>
          ) : (
            <>
              <SlidersHorizontal className="w-8 h-8 text-slate-600" />
              <div className="text-slate-400 text-sm">No setups found</div>
              <div className="text-slate-600 text-xs text-center max-w-sm">
                {setups.length === 0 ? "No EMA pullback setups detected on this timeframe. Try Daily or 4H for best results." : "No setups match your filters."}
              </div>
            </>
          )}
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Showing <span className="text-white font-mono">{filtered.length}</span> setups · real data from Polygon.io</span>
            {autoPush && <Badge variant="outline" className="text-[10px] border-[#F5A623]/30 text-[#F5A623] bg-[#F5A623]/5"><Zap className="w-2.5 h-2.5 mr-1" />Auto-push ON</Badge>}
          </div>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-3 pb-4">
            {filtered.map((setup) => (
              <SetupCard
                key={setup.id}
                setup={setup as unknown as ScreenerSetup}
                onPush={() => onPushToJournal(setup as unknown as ScreenerSetup)}
                isPushed={pushedIds.has(setup.id)}
                onViewChart={() => setChartSetup(setup as unknown as ScreenerSetup)}
                onSetAlert={() => handleSetAlert(setup as unknown as ScreenerSetup)}
                onCalculate={() => handleCalculate(setup as unknown as ScreenerSetup)}
                onAddToWatchlist={() => handleAddToWatchlist(setup as unknown as ScreenerSetup)}
                currentOutcome={outcomeMap[setup.id] ?? null}
                onMarkOutcome={(outcome) => markOutcomeMutation.mutate({
                  setupId: setup.id,
                  outcome,
                  symbol: setup.symbol,
                  assetClass: "STOCK",
                  setupType: setup.setupType as "CALL" | "PUT",
                  quality: setup.quality as "PREMIUM" | "STRONG" | "DEVELOPING",
                  pattern: setup.pattern,
                  timeframe: setup.timeframe,
                  levels: setup.levels as { entry: number; stopLoss: number; takeProfit: number },
                  rrRatio: setup.rrRatio,
                  confluences: (setup.confluences ?? []) as string[],
                })}
                isMarkingOutcome={markOutcomeMutation.isPending}
                isAuthenticated={isAuthenticated}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

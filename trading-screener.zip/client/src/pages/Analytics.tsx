/**
 * Performance Analytics Page
 * Aggregates journal data into charts and stats:
 * - Win rate, total P&L, avg RR
 * - Equity curve (cumulative P&L over time)
 * - Monthly performance bar chart
 * - Pattern breakdown table
 * - Asset class breakdown
 */

import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Cell, ReferenceLine,
} from "recharts";
import {
  TrendingUp, TrendingDown, Target, Award, BarChart3,
  Loader2, BookOpen, Activity,
} from "lucide-react";
import { cn } from "@/lib/utils";

// Custom tooltip for equity curve
function EquityTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  const cumPnl = payload[0]?.value ?? 0;
  const pnl = payload[1]?.value ?? 0;
  return (
    <div className="bg-[#0D1117] border border-slate-700 rounded-lg p-3 text-xs font-mono shadow-xl">
      <div className="text-slate-400 mb-1">{label}</div>
      <div className={cn("font-bold", cumPnl >= 0 ? "text-[#00FF88]" : "text-[#FF3B5C]")}>
        Equity: {cumPnl >= 0 ? "+" : ""}{cumPnl.toFixed(2)}
      </div>
      <div className={cn("text-xs", pnl >= 0 ? "text-[#00FF88]/70" : "text-[#FF3B5C]/70")}>
        Trade P&L: {pnl >= 0 ? "+" : ""}{pnl.toFixed(2)}
      </div>
    </div>
  );
}

function MonthlyTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  const pnl = payload[0]?.value ?? 0;
  return (
    <div className="bg-[#0D1117] border border-slate-700 rounded-lg p-3 text-xs font-mono shadow-xl">
      <div className="text-slate-400 mb-1">{label}</div>
      <div className={cn("font-bold", pnl >= 0 ? "text-[#00FF88]" : "text-[#FF3B5C]")}>
        P&L: {pnl >= 0 ? "+" : ""}{pnl.toFixed(2)}
      </div>
      <div className="text-slate-500">Trades: {payload[0]?.payload?.total ?? 0}</div>
    </div>
  );
}

function StatCard({ label, value, sub, color, icon: Icon }: {
  label: string; value: string; sub?: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-[#0D1117] border border-slate-800 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs text-slate-500 uppercase font-mono">{label}</span>
        <div className={cn("w-7 h-7 rounded-lg flex items-center justify-center", `bg-${color}/10`)}>
          <Icon className={cn("w-3.5 h-3.5", `text-${color}`)} />
        </div>
      </div>
      <div className={cn("text-2xl font-bold font-mono", color)}>{value}</div>
      {sub && <div className="text-xs text-slate-600 mt-1">{sub}</div>}
    </div>
  );
}

export default function Analytics() {
  const { isAuthenticated, loading } = useAuth();

  const { data, isLoading } = trpc.analytics.summary.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (loading || isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-[#60A5FA] animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <BarChart3 className="w-12 h-12 text-slate-600" />
        <div className="text-center">
          <h3 className="text-white font-semibold mb-1">Sign in to view Analytics</h3>
          <p className="text-slate-500 text-sm">Your performance data syncs across all devices</p>
        </div>
        <Button
          onClick={() => window.location.assign(getLoginUrl())}
          className="bg-[#60A5FA] text-black hover:bg-[#60A5FA]/90"
        >
          Log In
        </Button>
      </div>
    );
  }

  if (!data || data.total === 0) {
    return (
      <div className="flex flex-col space-y-4">
        {/* Header */}
        <div className="relative overflow-hidden rounded-xl border border-slate-800" style={{ minHeight: 100 }}>
          <div className="absolute inset-0 bg-gradient-to-r from-[#0A0D12] to-[#0D1117]" />
          <div className="relative z-10 p-5">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 rounded-full bg-[#60A5FA] animate-pulse" />
              <span className="text-[11px] text-[#60A5FA] font-mono uppercase tracking-widest">Performance Dashboard</span>
            </div>
            <h2 className="text-xl font-bold text-white">Analytics</h2>
            <p className="text-slate-400 text-sm mt-0.5">Win rate · Equity curve · Pattern breakdown · Monthly P&L</p>
          </div>
        </div>
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <BookOpen className="w-10 h-10 text-slate-700" />
          <div className="text-slate-400 text-sm">No journal data yet</div>
          <div className="text-slate-600 text-xs text-center max-w-sm">
            Push setups to your journal and mark them as WIN/LOSS to start tracking your performance.
          </div>
        </div>
      </div>
    );
  }

  const {
    total, wins, losses, breakevens, pending,
    winRate, totalPnl, avgRR,
    equityCurve, patternBreakdown, assetBreakdown, monthlyPerformance,
    timeframeBreakdown, strategyBreakdown,
  } = data;

  return (
    <div className="flex flex-col space-y-5">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl border border-slate-800" style={{ minHeight: 100 }}>
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A0D12] to-[#0D1117]" />
        <div className="relative z-10 p-5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 rounded-full bg-[#60A5FA] animate-pulse" />
              <span className="text-[11px] text-[#60A5FA] font-mono uppercase tracking-widest">Performance Dashboard</span>
            </div>
            <h2 className="text-xl font-bold text-white">Analytics</h2>
            <p className="text-slate-400 text-sm mt-0.5">Based on {total} journal {total === 1 ? "entry" : "entries"}</p>
          </div>
          <div className="hidden sm:flex items-center gap-4">
            <div className="text-center">
              <div className={cn("text-2xl font-bold font-mono", winRate >= 50 ? "text-[#00FF88]" : "text-[#FF3B5C]")}>
                {winRate.toFixed(0)}%
              </div>
              <div className="text-[10px] text-slate-500">Win Rate</div>
            </div>
            <div className="text-center">
              <div className={cn("text-2xl font-bold font-mono", totalPnl >= 0 ? "text-[#00FF88]" : "text-[#FF3B5C]")}>
                {totalPnl >= 0 ? "+" : ""}{totalPnl.toFixed(2)}
              </div>
              <div className="text-[10px] text-slate-500">Total P&L</div>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-[#0D1117] border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-500 uppercase font-mono mb-2">Win Rate</div>
          <div className={cn("text-2xl font-bold font-mono", winRate >= 50 ? "text-[#00FF88]" : "text-[#FF3B5C]")}>
            {winRate.toFixed(1)}%
          </div>
          <div className="text-xs text-slate-600 mt-1">{wins}W / {losses}L / {breakevens}BE</div>
          <div className="mt-2 w-full bg-slate-800 rounded-full h-1.5">
            <div
              className={cn("h-full rounded-full", winRate >= 50 ? "bg-[#00FF88]" : "bg-[#FF3B5C]")}
              style={{ width: `${Math.min(100, winRate)}%` }}
            />
          </div>
        </div>
        <div className="bg-[#0D1117] border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-500 uppercase font-mono mb-2">Total P&L</div>
          <div className={cn("text-2xl font-bold font-mono", totalPnl >= 0 ? "text-[#00FF88]" : "text-[#FF3B5C]")}>
            {totalPnl >= 0 ? "+" : ""}{totalPnl.toFixed(2)}
          </div>
          <div className="text-xs text-slate-600 mt-1">{total} total trades</div>
        </div>
        <div className="bg-[#0D1117] border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-500 uppercase font-mono mb-2">Avg RR Planned</div>
          <div className="text-2xl font-bold font-mono text-[#60A5FA]">{avgRR.toFixed(2)}:1</div>
          <div className="text-xs text-slate-600 mt-1">across all setups</div>
        </div>
        <div className="bg-[#0D1117] border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-500 uppercase font-mono mb-2">Pending</div>
          <div className="text-2xl font-bold font-mono text-[#F5A623]">{pending}</div>
          <div className="text-xs text-slate-600 mt-1">open / unresolved</div>
        </div>
      </div>

      {/* Equity Curve */}
      {equityCurve.length > 1 && (
        <div className="bg-[#0D1117] border border-slate-800 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-4 h-4 text-[#60A5FA]" />
            <h3 className="text-sm font-semibold text-white">Equity Curve</h3>
            <span className="text-xs text-slate-500">Cumulative P&L over time</span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={equityCurve} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00FF88" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#00FF88" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="equityGradientNeg" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#FF3B5C" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#FF3B5C" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="date" tick={{ fill: "#475569", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#475569", fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip content={<EquityTooltip />} />
              <ReferenceLine y={0} stroke="#475569" strokeDasharray="3 3" />
              <Area
                type="monotone"
                dataKey="cumPnl"
                stroke="#00FF88"
                strokeWidth={2}
                fill="url(#equityGradient)"
                dot={false}
              />
              <Area
                type="monotone"
                dataKey="pnl"
                stroke="#60A5FA"
                strokeWidth={1}
                fill="none"
                dot={false}
                strokeDasharray="3 3"
              />
            </AreaChart>
          </ResponsiveContainer>
          <div className="flex items-center gap-4 mt-2 justify-end">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-0.5 bg-[#00FF88]" />
              <span className="text-[10px] text-slate-500">Cumulative P&L</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-0.5 bg-[#60A5FA] border-dashed" style={{ borderTop: "1px dashed #60A5FA", background: "none" }} />
              <span className="text-[10px] text-slate-500">Trade P&L</span>
            </div>
          </div>
        </div>
      )}

      {/* Monthly Performance */}
      {monthlyPerformance.length > 0 && (
        <div className="bg-[#0D1117] border border-slate-800 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 className="w-4 h-4 text-[#F5A623]" />
            <h3 className="text-sm font-semibold text-white">Monthly Performance</h3>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={monthlyPerformance} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="month" tick={{ fill: "#475569", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#475569", fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip content={<MonthlyTooltip />} />
              <ReferenceLine y={0} stroke="#475569" />
              <Bar dataKey="pnl" radius={[4, 4, 0, 0]}>
                {monthlyPerformance.map((entry, index) => (
                  <Cell key={index} fill={entry.pnl >= 0 ? "#00FF88" : "#FF3B5C"} fillOpacity={0.8} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Pattern Breakdown */}
        {patternBreakdown.length > 0 && (
          <div className="bg-[#0D1117] border border-slate-800 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-4">
              <Target className="w-4 h-4 text-[#60A5FA]" />
              <h3 className="text-sm font-semibold text-white">Pattern Breakdown</h3>
            </div>
            <div className="space-y-2">
              {patternBreakdown.map((p) => (
                <div key={p.pattern} className="flex items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-slate-300 truncate">{p.pattern}</span>
                      <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                        <span className="text-[10px] text-slate-500 font-mono">{p.total} trades</span>
                        <span className={cn(
                          "text-[10px] font-mono font-bold",
                          p.winRate >= 50 ? "text-[#00FF88]" : "text-[#FF3B5C]"
                        )}>
                          {p.winRate.toFixed(0)}%
                        </span>
                      </div>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5 flex overflow-hidden">
                      <div
                        className="h-full bg-[#00FF88]"
                        style={{ width: `${p.total > 0 ? (p.wins / p.total) * 100 : 0}%` }}
                      />
                      <div
                        className="h-full bg-[#FF3B5C]"
                        style={{ width: `${p.total > 0 ? (p.losses / p.total) * 100 : 0}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Asset Class Breakdown */}
        {assetBreakdown.length > 0 && (
          <div className="bg-[#0D1117] border border-slate-800 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-4">
              <Award className="w-4 h-4 text-[#F5A623]" />
              <h3 className="text-sm font-semibold text-white">Asset Class Breakdown</h3>
            </div>
            <div className="space-y-3">
              {assetBreakdown.map((a) => (
                <div key={a.assetClass} className="bg-[#080B10] rounded-lg p-3 border border-slate-800">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={cn(
                        "text-[10px] border",
                        a.assetClass === "FOREX"
                          ? "border-[#60A5FA]/30 text-[#60A5FA] bg-[#60A5FA]/5"
                          : "border-[#00FF88]/30 text-[#00FF88] bg-[#00FF88]/5"
                      )}>
                        {a.assetClass}
                      </Badge>
                      <span className="text-xs text-slate-400">{a.total} trades</span>
                    </div>
                    <span className={cn(
                      "text-sm font-bold font-mono",
                      a.pnl >= 0 ? "text-[#00FF88]" : "text-[#FF3B5C]"
                    )}>
                      {a.pnl >= 0 ? "+" : ""}{a.pnl.toFixed(2)}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div>
                      <div className="text-sm font-bold font-mono text-[#00FF88]">{a.wins}</div>
                      <div className="text-[10px] text-slate-600">Wins</div>
                    </div>
                    <div>
                      <div className="text-sm font-bold font-mono text-[#FF3B5C]">{a.losses}</div>
                      <div className="text-[10px] text-slate-600">Losses</div>
                    </div>
                    <div>
                      <div className={cn("text-sm font-bold font-mono", a.winRate >= 50 ? "text-[#00FF88]" : "text-[#FF3B5C]")}>
                        {a.winRate.toFixed(0)}%
                      </div>
                      <div className="text-[10px] text-slate-600">Win Rate</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Backtesting Summary: Timeframe & Strategy Breakdown */}
      {((timeframeBreakdown && timeframeBreakdown.length > 0) || (strategyBreakdown && strategyBreakdown.length > 0)) && (
        <div className="bg-[#0D1117] border border-slate-800 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 className="w-4 h-4 text-[#F5A623]" />
            <h3 className="text-sm font-semibold text-white">Backtesting Summary</h3>
            <span className="text-xs text-slate-500">Win rate &amp; avg RR by timeframe and strategy</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {timeframeBreakdown && timeframeBreakdown.length > 0 && (
              <div>
                <div className="text-[10px] text-slate-500 uppercase font-mono mb-3">By Timeframe</div>
                <div className="space-y-2">
                  {timeframeBreakdown.map((tf) => (
                    <div key={tf.timeframe} className="bg-[#080B10] rounded-lg p-3 border border-slate-800">
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-semibold text-white">{tf.timeframe}</span>
                          <span className="text-[10px] text-slate-500">{tf.total} trades</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className={cn("text-xs font-bold font-mono", tf.winRate >= 50 ? "text-[#00FF88]" : "text-[#FF3B5C]")}>
                            {tf.winRate.toFixed(0)}% WR
                          </div>
                          <div className="text-xs font-bold font-mono text-[#60A5FA]">
                            {tf.avgRR.toFixed(1)}:1 RR
                          </div>
                        </div>
                      </div>
                      <div className="w-full bg-slate-800 rounded-full h-1.5 flex overflow-hidden">
                        <div className="h-full bg-[#00FF88]" style={{ width: `${tf.total > 0 ? (tf.wins / tf.total) * 100 : 0}%` }} />
                        <div className="h-full bg-[#FF3B5C]" style={{ width: `${tf.total > 0 ? (tf.losses / tf.total) * 100 : 0}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {strategyBreakdown && strategyBreakdown.length > 0 && (
              <div>
                <div className="text-[10px] text-slate-500 uppercase font-mono mb-3">By Strategy</div>
                <div className="space-y-2">
                  {strategyBreakdown.map((s) => (
                    <div key={s.strategy} className="bg-[#080B10] rounded-lg p-3 border border-slate-800">
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-white">{s.strategy}</span>
                          <span className="text-[10px] text-slate-500">{s.total} trades</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className={cn("text-xs font-bold font-mono", s.winRate >= 50 ? "text-[#00FF88]" : "text-[#FF3B5C]")}>
                            {s.winRate.toFixed(0)}% WR
                          </div>
                          <div className="text-xs font-bold font-mono text-[#60A5FA]">
                            {s.avgRR.toFixed(1)}:1 RR
                          </div>
                        </div>
                      </div>
                      <div className="w-full bg-slate-800 rounded-full h-1.5 flex overflow-hidden">
                        <div className="h-full bg-[#00FF88]" style={{ width: `${s.total > 0 ? (s.wins / s.total) * 100 : 0}%` }} />
                        <div className="h-full bg-[#FF3B5C]" style={{ width: `${s.total > 0 ? (s.losses / s.total) * 100 : 0}%` }} />
                      </div>
                      <div className="flex items-center justify-between mt-1.5">
                        <span className={cn("text-[10px] font-mono", s.pnl >= 0 ? "text-[#00FF88]/70" : "text-[#FF3B5C]/70")}>
                          P&amp;L: {s.pnl >= 0 ? "+" : ""}{s.pnl.toFixed(2)}
                        </span>
                        <span className="text-[10px] text-slate-600 font-mono">{s.wins}W / {s.losses}L</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * Live scan test — validates Oanda forex + Yahoo Finance stock data
 * and the supply/demand analysis engine end-to-end
 */
import { config } from "dotenv";
config();

const OANDA_KEY = process.env.OANDA_API_KEY;
const OANDA_ACCOUNT_TYPE = process.env.OANDA_ACCOUNT_TYPE || "live";
const OANDA_BASE = OANDA_ACCOUNT_TYPE === "live"
  ? "https://api-fxtrade.oanda.com"
  : "https://api-fxpractice.oanda.com";

// ── Test 1: Oanda EUR/USD H4 ─────────────────────────────────────────────────
async function testOanda() {
  console.log("\n=== OANDA FOREX TEST ===");
  const url = `${OANDA_BASE}/v3/instruments/EUR_USD/candles?granularity=H4&count=50&price=M`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${OANDA_KEY}`, "Content-Type": "application/json" },
  });
  if (!res.ok) throw new Error(`Oanda error: ${res.status}`);
  const data = await res.json();
  const candles = data.candles.filter(c => c.complete);
  console.log(`✅ EUR/USD H4: ${candles.length} completed candles`);
  const last = candles[candles.length - 1];
  console.log(`   Last: O=${last.mid.o} H=${last.mid.h} L=${last.mid.l} C=${last.mid.c}`);
  return candles.length;
}

// ── Test 2: Yahoo Finance AAPL Daily ─────────────────────────────────────────
async function testYahoo() {
  console.log("\n=== YAHOO FINANCE STOCK TEST ===");
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/AAPL?interval=1d&range=60d&includePrePost=false`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  let res;
  try {
    res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "application/json",
      },
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timeout);
  }
  if (!res.ok) throw new Error(`Yahoo error: ${res.status}`);
  const data = await res.json();
  const result = data.chart.result[0];
  const candles = result.timestamp.length;
  const lastClose = result.indicators.quote[0].close[candles - 1];
  console.log(`✅ AAPL Daily: ${candles} candles`);
  console.log(`   Last close: $${lastClose.toFixed(2)}`);
  return candles;
}

// ── Test 3: Multiple stocks ───────────────────────────────────────────────────
async function testMultipleStocks() {
  console.log("\n=== MULTI-STOCK TEST (5 symbols) ===");
  const symbols = ["NVDA", "TSLA", "MSFT", "META", "SPY"];
  const results = await Promise.allSettled(
    symbols.map(async (sym) => {
      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${sym}?interval=1d&range=30d&includePrePost=false`;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 12000);
      try {
        const res = await fetch(url, {
          headers: { "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36" },
          signal: controller.signal,
        });
        clearTimeout(timeout);
        if (!res.ok) throw new Error(`${res.status}`);
        const data = await res.json();
        const c = data.chart.result[0].indicators.quote[0].close;
        return { sym, close: c[c.length - 1], ok: true };
      } catch (e) {
        clearTimeout(timeout);
        return { sym, error: e.message, ok: false };
      }
    })
  );
  results.forEach((r) => {
    if (r.status === "fulfilled") {
      const v = r.value;
      if (v.ok) console.log(`✅ ${v.sym}: $${v.close.toFixed(2)}`);
      else console.log(`❌ ${v.sym}: ${v.error}`);
    }
  });
}

// ── Test 4: Oanda multiple pairs ──────────────────────────────────────────────
async function testMultipleForex() {
  console.log("\n=== MULTI-FOREX TEST (5 pairs) ===");
  const pairs = ["EUR_USD", "GBP_USD", "USD_JPY", "AUD_USD", "XAU_USD"];
  const results = await Promise.allSettled(
    pairs.map(async (pair) => {
      const url = `${OANDA_BASE}/v3/instruments/${pair}/candles?granularity=H4&count=10&price=M`;
      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${OANDA_KEY}` },
      });
      if (!res.ok) throw new Error(`${res.status}`);
      const data = await res.json();
      const completed = data.candles.filter(c => c.complete);
      const last = completed[completed.length - 1];
      return { pair, close: last?.mid?.c, count: completed.length };
    })
  );
  results.forEach((r) => {
    if (r.status === "fulfilled") console.log(`✅ ${r.value.pair}: ${r.value.count} candles, last C=${r.value.close}`);
    else console.log(`❌ ${r.reason}`);
  });
}

// ── Run all tests ─────────────────────────────────────────────────────────────
(async () => {
  console.log("🔍 PremiumScan Live Data Tests");
  console.log("================================");
  try {
    await testOanda();
    await testYahoo();
    await testMultipleStocks();
    await testMultipleForex();
    console.log("\n✅ All live data tests passed!");
  } catch (err) {
    console.error("\n❌ Test failed:", err.message);
    process.exit(1);
  }
})();
